﻿Public Class Splashscreen
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Value += 1
        Lbl_precent.Text = ProgressBar1.Value & " % completing. . ."

        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Timer2.Start()

        End If


        If ProgressBar1.Value = 10 Then

            Lbl_msg.Text = "Loading . . ."

        End If


        If ProgressBar1.Value = 50 Then

            Lbl_msg.Text = "Please be Patient. . ."

        End If


        If ProgressBar1.Value = 85 Then

            Lbl_msg.Text = "Nice! We are ready . . ."

        End If


        If ProgressBar1.Value = 100 Then

            Lbl_msg.Text = "Launching Database . . ."

            ' Form1.Show()
            ' Me.Close()

            Dim logform As New Form1()
            Form1.Show()
            Me.Hide()
        End If



    End Sub

    Private Sub Splashscreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ProgressBar1.Value = 0
        Timer1.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Timer2.Stop()

    End Sub
End Class