﻿
Imports System.Reflection
Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Relational

Public Class ClientForm
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable


    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        Dim home, mrcb As Integer
        Dim Cid As String
        Dim age
        Dim cname, sex, mobile As String
        Dim Nic As String

        Cid = TxtCandidateid.Text
        cname = TxtCandidatename.Text
        Nic = Txtnic.Text
        home = Txthomeno.Text
        sex = CBsex.Text
        mobile = TxtMobileno.Text
        age = Txtage.Text
        mrcb = Txtmrcb.Text


        'empty field validation.
        If (TxtCandidateid.Text = "") Then
            TxtCandidateid.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TxtCandidateid.Focus()
            Return

        End If

        'empty field validation.
        If (TxtCandidatename.Text = "") Then
            TxtCandidatename.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TxtCandidatename.Focus()
            Return

        End If

        'empty field validation.
        If (Txtnic.Text = "") Then
            Txtnic.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Nic", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txtnic.Focus()
            Return

        End If

        'empty field validation.
        If (Txthomeno.Text = "") Then
            Txthomeno.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Home no", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txthomeno.Focus()
            Return

        End If

        'empty field validation.
        If (CBsex.Text = "") Then
            CBsex.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            CBsex.Focus()
            Return

        End If

        'empty field validation.
        If (TxtMobileno.Text = "") Then
            TxtMobileno.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Mobile_No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TxtMobileno.Focus()
            Return

        End If

        'empty field validation.
        If (Txtage.Text = "") Then
            Txtage.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Age", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txtage.Focus()
            Return

        End If


        If age <= 15 OrElse age >= 100 Then ' Adjust the range according to your requirements
            MessageBox.Show("Invalid Age", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If


        If Not (Txtnic.Text.Length = 12) Then
            MessageBox.Show("Invalid NIC format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If



        If Not (TxtMobileno.Text.Length = 10) Then
            MessageBox.Show("Invalid Mobile Number Format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        If Not (Txthomeno.Text.Length = 3) Then
            MessageBox.Show("Invalid Home Number Format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If


        If String.IsNullOrEmpty(TxtCandidatename.Text) OrElse
       String.IsNullOrEmpty(CBsex.Text) Then
            MessageBox.Show("Please fill in all required fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If


        'Insert data to table
        Try
            connectdb()

            Dim quary As String = "INSERT INTO `clientform2` ( `mrcb_no` , `Home_no`, `Candidate_ID`, `Candidate_Name`, `Candidate_Nic`, `Sex`, `Mobile_No`, `Age`) VALUES ( @mrcb_no ,@Home_No, @Candidate_ID, @Candidate_Name, @Candidate_Nic, @Sex, @Mobile_No, @Age)"


            command = New MySqlCommand(quary, conn)

            command.Parameters.AddWithValue("@mrcb_no", Txtmrcb.Text)
            command.Parameters.AddWithValue("@Home_No", Txthomeno.Text)
            command.Parameters.AddWithValue("@Candidate_ID", TxtCandidateid.Text)
            command.Parameters.AddWithValue("@Candidate_Name", TxtCandidatename.Text)
            command.Parameters.AddWithValue("@Candidate_Nic", Txtnic.Text)
            command.Parameters.AddWithValue("@Sex", CBsex.Text)
            command.Parameters.AddWithValue("@Mobile_No", TxtMobileno.Text)
            command.Parameters.AddWithValue("@Age", Txtage.Text)


            Dim result As Integer = command.ExecuteNonQuery()
            If result > 0 Then
                MsgBox("candidate Registered successfully")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error Adding Candidate")


            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try



    End Sub
    Private Sub LoadData()
        Try
            connectdb()
            'connectdb()
            Dim query As String = "SELECT * FROM ict222.clientform2"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            DGVClient.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub ClearInputs()
        ' connectdb()
        Txtmrcb.Clear()
        TxtCandidateid.Clear()
        TxtCandidatename.Clear()
        Txtnic.Clear()
        Txthomeno.Clear()
        'CBsex.Clear()
        TxtMobileno.Clear()
        Txtage.Clear()

    End Sub

    Private Sub ClientForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadData()

        Dim reader3 As MySqlDataReader
        Try
            connectdb()
            Dim query3 As String
            query3 = "select * from ict222.clientform2 "
            command = New MySqlCommand(query3, conn)
            reader3 = command.ExecuteReader
            While reader3.Read
                Dim cid = reader3.GetString("Candidate_ID")
                cbsearch.Items.Add(cid)

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Private Sub filter()
        If cbsearch.Text = "" Then
            MsgBox("enter Candidate ID")
        Else
            Dim connectionstring As String = "server=127.0.0.1;user=root;database=ict222;"
            Using db As New MySqlConnection(connectionstring)
                Try
                    connectdb()
                    Dim query As String = "select * from clientform2 where Candidate_ID like @Candidate_ID"
                    Using adapter As New MySqlDataAdapter(query, conn)
                        adapter.SelectCommand.Parameters.AddWithValue("@Candidate_ID", "%" & cbsearch.Text & "%")

                        Dim ds As New DataSet()
                        adapter.Fill(ds)
                        DGVClient.DataSource = ds.Tables(0)
                    End Using
                Catch ex As Exception
                    MsgBox("error connecting to the database: " & ex.Message)

                Finally
                    conn.Close()
                End Try


            End Using
        End If
        conn.Close()
    End Sub

    Private Sub DGVClient_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVClient.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DGVClient.Rows(e.RowIndex)

            Txtmrcb.Text = row.Cells("mrcb_no").Value.ToString()
            Txthomeno.Text = row.Cells("Home_No").Value.ToString()
            TxtCandidateid.Text = row.Cells("Candidate_ID").Value.ToString()
            TxtCandidatename.Text = row.Cells("Candidate_Name").Value.ToString()
            Txtnic.Text = row.Cells("Candidate_Nic").Value.ToString()
            CBsex.Text = row.Cells("Sex").Value.ToString()
            TxtMobileno.Text = row.Cells("Mobile_No").Value.ToString()
            Txtage.Text = row.Cells("Age").Value.ToString()

        End If
    End Sub



    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles Btnsearch.Click
        filter()
    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click
        Try
            connectdb()

            Dim updateQuery As String = "UPDATE clientform2 SET mrcb_no = @mrcb_no , Home_No = @Home_No, Candidate_Name = @Candidate_Name, Sex = @Sex, Mobile_No = @Mobile_No, Age = @Age WHERE Candidate_ID = @Candidate_ID"
            command = New MySqlCommand(updateQuery, conn)

            command.Parameters.AddWithValue("@mrcb_no", Txtmrcb.Text)
            command.Parameters.AddWithValue("@Home_No", Txthomeno.Text)
            command.Parameters.AddWithValue("@Candidate_Name", TxtCandidatename.Text)
            command.Parameters.AddWithValue("@Candidate_Nic", Txtnic.Text)
            command.Parameters.AddWithValue("@Sex", CBsex.Text)
            command.Parameters.AddWithValue("@Mobile_No", TxtMobileno.Text)
            command.Parameters.AddWithValue("@Age", Txtage.Text)
            command.Parameters.AddWithValue("@Candidate_ID", TxtCandidateid.Text)

            Dim result As Integer = command.ExecuteNonQuery()

            If result > 0 Then
                MsgBox("Candidate updated successfully!")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error updating Candidate")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        LoadData()
    End Sub



    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this Candidate ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Try
                connectdb()


                Dim deleteQuery As String = "DELETE  FROM clientform2 WHERE Candidate_ID = @Candidate_ID"
                command = New MySqlCommand(deleteQuery, conn)

                command.Parameters.AddWithValue("@mrcb_no", Txtmrcb.Text)
                command.Parameters.AddWithValue("@Home_No", Txthomeno.Text)
                command.Parameters.AddWithValue("@Candidate_ID", TxtCandidateid.Text)
                command.Parameters.AddWithValue("@Candidate_Name", TxtCandidatename.Text)
                command.Parameters.AddWithValue("@Candidate_Nic", Txtnic.Text)
                command.Parameters.AddWithValue("@Sex", CBsex.Text)
                command.Parameters.AddWithValue("@Mobile_No", TxtMobileno.Text)
                command.Parameters.AddWithValue("@Age", Txtage.Text)


                Dim deleteResult As Integer = command.ExecuteNonQuery()

                If deleteResult > 0 Then
                    MsgBox("Candidate deleted successfully!")
                    ClearInputs()
                    LoadData()
                Else
                    MsgBox("Error deleting candidate")
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                conn.Close()
            End Try

        End If
        conn.Close()
        LoadData()



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim c As New Form3()
        Form3.Show()
        Me.Hide()
    End Sub



    Private Sub Btnloaddata_Click(sender As Object, e As EventArgs) Handles Btnloaddata.Click

        Dim SDA As New MySqlDataAdapter
        Dim dbdataset As New DataTable
        Dim bsource As New BindingSource
        Try
            connectdb()
            Dim query As String = "select *  from ict222.clientform2"
            command = New MySqlCommand(query, conn)
            SDA.SelectCommand = command
            SDA.Fill(dbdataset)
            bsource.DataSource = dbdataset
            DGVClient.DataSource = bsource
            SDA.Update(dbdataset)
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub ClientForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The Form ?", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub TxtCandidateid_TextChanged(sender As Object, e As EventArgs) Handles TxtCandidateid.TextChanged

        TxtCandidateid.BackColor = Color.Silver
    End Sub

    Private Sub TxtCandidatename_TextChanged(sender As Object, e As EventArgs) Handles TxtCandidatename.TextChanged
        TxtCandidatename.BackColor = Color.Silver
    End Sub

    Private Sub Txtnic_TextChanged(sender As Object, e As EventArgs) Handles Txtnic.TextChanged
        Txtnic.BackColor = Color.Silver
    End Sub

    Private Sub Txthomeno_TextChanged(sender As Object, e As EventArgs) Handles Txthomeno.TextChanged
        Txthomeno.BackColor = Color.Silver
    End Sub


    Private Sub TxtMobileno_TextChanged(sender As Object, e As EventArgs) Handles TxtMobileno.TextChanged
        TxtMobileno.BackColor = Color.Silver
    End Sub

    Private Sub Txtage_TextChanged(sender As Object, e As EventArgs) Handles Txtage.TextChanged
        Txtage.BackColor = Color.Silver
    End Sub

    Private Sub cbsearch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbsearch.SelectedIndexChanged

        Dim reader2 As MySqlDataReader
        Try
            connectdb()
            Dim query2 As String
            query2 = "select * from ict222.clientform2 where Candidate_ID = '" & cbsearch.Text & "' "
            command = New MySqlCommand(query2, conn)
            reader2 = command.ExecuteReader
            While reader2.Read
                Txtmrcb.Text = reader2.GetString("mrcb_no")
                Txthomeno.Text = reader2.GetString("Home_No")
                TxtCandidateid.Text = reader2.GetString("Candidate_ID")
                TxtCandidatename.Text = reader2.GetString("Candidate_Name")
                CBsex.Text = reader2.GetString("Sex")
                TxtMobileno.Text = reader2.GetString("Mobile_No")
                Txtage.Text = reader2.GetInt32("age")
                Txtnic.Text = reader2.GetString("Candidate_Nic")

            End While

            ' conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        For Each tbcontrol As Object In Panel2.Controls
            If TypeOf tbcontrol Is TextBox Then
                tbcontrol.Text = ""
            End If
        Next
    End Sub

    ' Private Sub TxtCandidatename_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCandidatename.KeyPress
    'If Char.IsLetter(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
    '       e.Handled = True
    '      MsgBox("Please enter only letters!", MsgBoxStyle.Critical)
    'only accepts Letters input
    'End If
    'End Sub

    Private Sub TxtMobileno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtMobileno.KeyPress
        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("Please enter only numbers!", MsgBoxStyle.Critical)
            'only accept number inputs
        End If
    End Sub

    Private Sub Txtage_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Txtage.KeyPress
        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
            e.Handled = True
            MsgBox("Please enter only numbers!", MsgBoxStyle.Critical)
            'only accept number inputs
        End If
    End Sub


    'get data to textbox by cel click
    Private Sub DGVClient_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVClient.CellClick
        Dim index As Integer
        index = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DGVClient.Rows(index)

        Txtmrcb.Text = selectedRow.Cells(0).Value.ToString()
        Txthomeno.Text = selectedRow.Cells(1).Value.ToString()
        TxtCandidateid.Text = selectedRow.Cells(2).Value.ToString()
        TxtCandidatename.Text = selectedRow.Cells(3).Value.ToString()
        Txtnic.Text = selectedRow.Cells(4).Value.ToString()
        CBsex.Text = selectedRow.Cells(5).Value.ToString()
        TxtMobileno.Text = selectedRow.Cells(6).Value.ToString()
        Txtage.Text = selectedRow.Cells(7).Value.ToString()
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles Txtmrcb.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Panel4_Paint(sender As Object, e As PaintEventArgs) Handles Panel4.Paint

    End Sub
End Class