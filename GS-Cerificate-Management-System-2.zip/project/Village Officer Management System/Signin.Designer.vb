﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Signin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txtnic = New System.Windows.Forms.TextBox()
        Me.Btnsignin = New System.Windows.Forms.Button()
        Me.Txtfname = New System.Windows.Forms.TextBox()
        Me.Txttp = New System.Windows.Forms.TextBox()
        Me.Txtlname = New System.Windows.Forms.TextBox()
        Me.Btnsignexit = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txtaddress = New System.Windows.Forms.TextBox()
        Me.Txtname = New System.Windows.Forms.TextBox()
        Me.Btncancel = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Pb3 = New System.Windows.Forms.PictureBox()
        Me.Pb4 = New System.Windows.Forms.PictureBox()
        Me.Pb5 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.Pb3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pb5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Txtnic
        '
        Me.Txtnic.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtnic.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtnic.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtnic.Location = New System.Drawing.Point(212, 204)
        Me.Txtnic.Multiline = True
        Me.Txtnic.Name = "Txtnic"
        Me.Txtnic.Size = New System.Drawing.Size(272, 39)
        Me.Txtnic.TabIndex = 2
        '
        'Btnsignin
        '
        Me.Btnsignin.BackColor = System.Drawing.Color.CornflowerBlue
        Me.Btnsignin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnsignin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnsignin.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsignin.Location = New System.Drawing.Point(244, 405)
        Me.Btnsignin.Name = "Btnsignin"
        Me.Btnsignin.Size = New System.Drawing.Size(191, 47)
        Me.Btnsignin.TabIndex = 3
        Me.Btnsignin.Text = "Register"
        Me.Btnsignin.UseVisualStyleBackColor = False
        '
        'Txtfname
        '
        Me.Txtfname.AccessibleDescription = ""
        Me.Txtfname.AccessibleName = ""
        Me.Txtfname.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtfname.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtfname.Location = New System.Drawing.Point(214, 38)
        Me.Txtfname.Multiline = True
        Me.Txtfname.Name = "Txtfname"
        Me.Txtfname.Size = New System.Drawing.Size(272, 40)
        Me.Txtfname.TabIndex = 5
        '
        'Txttp
        '
        Me.Txttp.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txttp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txttp.Location = New System.Drawing.Point(214, 151)
        Me.Txttp.Multiline = True
        Me.Txttp.Name = "Txttp"
        Me.Txttp.Size = New System.Drawing.Size(272, 40)
        Me.Txttp.TabIndex = 6
        '
        'Txtlname
        '
        Me.Txtlname.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtlname.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtlname.Location = New System.Drawing.Point(214, 93)
        Me.Txtlname.Multiline = True
        Me.Txtlname.Name = "Txtlname"
        Me.Txtlname.Size = New System.Drawing.Size(272, 40)
        Me.Txtlname.TabIndex = 7
        '
        'Btnsignexit
        '
        Me.Btnsignexit.BackColor = System.Drawing.Color.Transparent
        Me.Btnsignexit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnsignexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnsignexit.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsignexit.ForeColor = System.Drawing.Color.White
        Me.Btnsignexit.Location = New System.Drawing.Point(691, 30)
        Me.Btnsignexit.Name = "Btnsignexit"
        Me.Btnsignexit.Size = New System.Drawing.Size(105, 54)
        Me.Btnsignexit.TabIndex = 8
        Me.Btnsignexit.Text = "BACK"
        Me.Btnsignexit.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_64__1_
        Me.PictureBox1.Location = New System.Drawing.Point(361, 140)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(92, 75)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(314, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 35)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Create Account"
        '
        'Txtaddress
        '
        Me.Txtaddress.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtaddress.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtaddress.Location = New System.Drawing.Point(212, 262)
        Me.Txtaddress.Multiline = True
        Me.Txtaddress.Name = "Txtaddress"
        Me.Txtaddress.Size = New System.Drawing.Size(272, 45)
        Me.Txtaddress.TabIndex = 11
        '
        'Txtname
        '
        Me.Txtname.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtname.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Txtname.Location = New System.Drawing.Point(211, 327)
        Me.Txtname.Multiline = True
        Me.Txtname.Name = "Txtname"
        Me.Txtname.Size = New System.Drawing.Size(275, 44)
        Me.Txtname.TabIndex = 12
        '
        'Btncancel
        '
        Me.Btncancel.BackColor = System.Drawing.Color.Transparent
        Me.Btncancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btncancel.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btncancel.ForeColor = System.Drawing.Color.White
        Me.Btncancel.Location = New System.Drawing.Point(505, 31)
        Me.Btncancel.Name = "Btncancel"
        Me.Btncancel.Size = New System.Drawing.Size(122, 54)
        Me.Btncancel.TabIndex = 13
        Me.Btncancel.Text = "CANCEL"
        Me.Btncancel.UseVisualStyleBackColor = False
        '
        'Btnclear
        '
        Me.Btnclear.BackColor = System.Drawing.Color.Transparent
        Me.Btnclear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnclear.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnclear.ForeColor = System.Drawing.Color.White
        Me.Btnclear.Location = New System.Drawing.Point(314, 30)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(122, 56)
        Me.Btnclear.TabIndex = 14
        Me.Btnclear.Text = "CLEAR"
        Me.Btnclear.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(202, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(403, 32)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "GRAMA  NILADARI  SYSTEM"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.CornflowerBlue
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.PictureBox5)
        Me.Panel1.Controls.Add(Me.Txtfname)
        Me.Panel1.Controls.Add(Me.Txtlname)
        Me.Panel1.Controls.Add(Me.Txttp)
        Me.Panel1.Controls.Add(Me.Txtnic)
        Me.Panel1.Controls.Add(Me.Txtname)
        Me.Panel1.Controls.Add(Me.Txtaddress)
        Me.Panel1.Controls.Add(Me.Btnsignin)
        Me.Panel1.Location = New System.Drawing.Point(132, 216)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(563, 483)
        Me.Panel1.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(67, 327)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(137, 31)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "User Name:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(99, 276)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 31)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Address:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(110, 212)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 31)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Nic No:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(74, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(130, 31)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Telephone:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(72, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 31)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Last Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(72, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 31)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "First Name:"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_sign_in_64
        Me.PictureBox5.Location = New System.Drawing.Point(169, 405)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(75, 46)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 18
        Me.PictureBox5.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel2.Controls.Add(Me.PictureBox4)
        Me.Panel2.Controls.Add(Me.PictureBox3)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.Btnsignexit)
        Me.Panel2.Controls.Add(Me.Btncancel)
        Me.Panel2.Controls.Add(Me.Btnclear)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 718)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(839, 89)
        Me.Panel2.TabIndex = 17
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_delete
        Me.PictureBox4.Location = New System.Drawing.Point(259, 30)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(58, 54)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 18
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_cancel1
        Me.PictureBox3.Location = New System.Drawing.Point(446, 31)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(61, 54)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 18
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_back_64
        Me.PictureBox2.Location = New System.Drawing.Point(639, 30)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(52, 54)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.DarkBlue
        Me.Panel3.Controls.Add(Me.Pb3)
        Me.Panel3.Controls.Add(Me.Pb4)
        Me.Panel3.Controls.Add(Me.Pb5)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(839, 59)
        Me.Panel3.TabIndex = 18
        '
        'Pb3
        '
        Me.Pb3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_minimize_501
        Me.Pb3.Location = New System.Drawing.Point(684, 4)
        Me.Pb3.Name = "Pb3"
        Me.Pb3.Size = New System.Drawing.Size(52, 51)
        Me.Pb3.TabIndex = 18
        Me.Pb3.TabStop = False
        '
        'Pb4
        '
        Me.Pb4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_maximize_501
        Me.Pb4.Location = New System.Drawing.Point(733, 5)
        Me.Pb4.Name = "Pb4"
        Me.Pb4.Size = New System.Drawing.Size(53, 49)
        Me.Pb4.TabIndex = 19
        Me.Pb4.TabStop = False
        '
        'Pb5
        '
        Me.Pb5.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_close1
        Me.Pb5.Location = New System.Drawing.Point(787, 6)
        Me.Pb5.Name = "Pb5"
        Me.Pb5.Size = New System.Drawing.Size(47, 45)
        Me.Pb5.TabIndex = 20
        Me.Pb5.TabStop = False
        '
        'Signin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SkyBlue
        Me.ClientSize = New System.Drawing.Size(839, 807)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Signin"
        Me.Text = "Signin"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.Pb3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pb5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Txtnic As TextBox
    Friend WithEvents Btnsignin As Button
    Friend WithEvents Txtfname As TextBox
    Friend WithEvents Txttp As TextBox
    Friend WithEvents Txtlname As TextBox
    Friend WithEvents Btnsignexit As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Txtaddress As TextBox
    Friend WithEvents Txtname As TextBox
    Friend WithEvents Btncancel As Button
    Friend WithEvents Btnclear As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Pb3 As PictureBox
    Friend WithEvents Pb4 As PictureBox
    Friend WithEvents Pb5 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
End Class
