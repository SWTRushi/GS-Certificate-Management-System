﻿Module Modulesignin
    Function min_length(ByVal str As String, ByVal length As Integer) As Boolean
        Dim result As Boolean = True
        If str.Length < length Then
            Return True

        End If
        Return False

    End Function

    Function isempty(ByVal str As String) As Boolean
        str = str.Trim
        If String.IsNullOrEmpty(str) Then
            Return True
        End If
        Return False
    End Function

    Function is_unique_user(ByVal str As String) As Boolean
        str = str.Trim
        If String.IsNullOrEmpty(str) Then
        End If
        Return False

    End Function

End Module
