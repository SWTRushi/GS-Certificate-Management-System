﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class choosecertificate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.panelStatus = New System.Windows.Forms.Panel()
        Me.Btncharactercerti = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel2.Controls.Add(Me.panelStatus)
        Me.Panel2.Controls.Add(Me.Btncharactercerti)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1533, 93)
        Me.Panel2.TabIndex = 1
        '
        'panelStatus
        '
        Me.panelStatus.BackColor = System.Drawing.Color.Maroon
        Me.panelStatus.Location = New System.Drawing.Point(7, 2)
        Me.panelStatus.Name = "panelStatus"
        Me.panelStatus.Size = New System.Drawing.Size(10, 84)
        Me.panelStatus.TabIndex = 6
        '
        'Btncharactercerti
        '
        Me.Btncharactercerti.BackColor = System.Drawing.Color.Transparent
        Me.Btncharactercerti.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btncharactercerti.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btncharactercerti.Location = New System.Drawing.Point(4, 2)
        Me.Btncharactercerti.Name = "Btncharactercerti"
        Me.Btncharactercerti.Size = New System.Drawing.Size(258, 81)
        Me.Btncharactercerti.TabIndex = 0
        Me.Btncharactercerti.Text = "Residence And" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Character Certificate"
        Me.Btncharactercerti.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 93)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1533, 737)
        Me.Panel3.TabIndex = 2
        '
        'choosecertificate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1533, 830)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "choosecertificate"
        Me.Text = "choosecertificate"
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Btncharactercerti As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents panelStatus As Panel
End Class
