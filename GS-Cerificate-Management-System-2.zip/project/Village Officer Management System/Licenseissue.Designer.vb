﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Licenseissue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txtlid = New System.Windows.Forms.TextBox()
        Me.Txtlt = New System.Windows.Forms.TextBox()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Btnedit = New System.Windows.Forms.Button()
        Me.Btnback = New System.Windows.Forms.Button()
        Me.DGVL = New System.Windows.Forms.DataGridView()
        CType(Me.DGVL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 94)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "License ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 142)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "License_Type"
        '
        'Txtlid
        '
        Me.Txtlid.Location = New System.Drawing.Point(141, 91)
        Me.Txtlid.Name = "Txtlid"
        Me.Txtlid.Size = New System.Drawing.Size(125, 27)
        Me.Txtlid.TabIndex = 2
        '
        'Txtlt
        '
        Me.Txtlt.Location = New System.Drawing.Point(141, 142)
        Me.Txtlt.Name = "Txtlt"
        Me.Txtlt.Size = New System.Drawing.Size(125, 27)
        Me.Txtlt.TabIndex = 3
        '
        'Btnadd
        '
        Me.Btnadd.Location = New System.Drawing.Point(159, 224)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(94, 29)
        Me.Btnadd.TabIndex = 4
        Me.Btnadd.Text = "ADD RECORD"
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'Btndelete
        '
        Me.Btndelete.Location = New System.Drawing.Point(528, 343)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(94, 29)
        Me.Btndelete.TabIndex = 5
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = True
        '
        'Btnedit
        '
        Me.Btnedit.Location = New System.Drawing.Point(698, 351)
        Me.Btnedit.Name = "Btnedit"
        Me.Btnedit.Size = New System.Drawing.Size(94, 29)
        Me.Btnedit.TabIndex = 6
        Me.Btnedit.Text = "EDIT"
        Me.Btnedit.UseVisualStyleBackColor = True
        '
        'Btnback
        '
        Me.Btnback.Location = New System.Drawing.Point(568, 409)
        Me.Btnback.Name = "Btnback"
        Me.Btnback.Size = New System.Drawing.Size(94, 29)
        Me.Btnback.TabIndex = 7
        Me.Btnback.Text = "BACK"
        Me.Btnback.UseVisualStyleBackColor = True
        '
        'DGVL
        '
        Me.DGVL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVL.Location = New System.Drawing.Point(412, 91)
        Me.DGVL.Name = "DGVL"
        Me.DGVL.RowHeadersWidth = 51
        Me.DGVL.RowTemplate.Height = 29
        Me.DGVL.Size = New System.Drawing.Size(550, 188)
        Me.DGVL.TabIndex = 8
        '
        'Licenseissue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1026, 450)
        Me.Controls.Add(Me.DGVL)
        Me.Controls.Add(Me.Btnback)
        Me.Controls.Add(Me.Btnedit)
        Me.Controls.Add(Me.Btndelete)
        Me.Controls.Add(Me.Btnadd)
        Me.Controls.Add(Me.Txtlt)
        Me.Controls.Add(Me.Txtlid)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Licenseissue"
        Me.Text = "Licenseissue"
        CType(Me.DGVL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Txtlid As TextBox
    Friend WithEvents Txtlt As TextBox
    Friend WithEvents Btnadd As Button
    Friend WithEvents Btndelete As Button
    Friend WithEvents Btnedit As Button
    Friend WithEvents Btnback As Button
    Friend WithEvents DGVL As DataGridView
End Class
