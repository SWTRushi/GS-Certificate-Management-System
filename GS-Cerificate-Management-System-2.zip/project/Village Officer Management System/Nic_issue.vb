﻿Public Class Nic_issue

End Class