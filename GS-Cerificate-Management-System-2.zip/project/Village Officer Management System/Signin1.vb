﻿Imports System.ComponentModel
Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient

Public Class Signin1

    Private Sub Btnsignin_Click(sender As Object, e As EventArgs) Handles Btnsignin.Click
        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim command As New MySqlCommand("INSERT INTO `login`(`first_name`, `last_name`, `email`, `username`, `password`) VALUES (@fn,@ln,@email,@usn,@pass)", conn)
        Dim connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")

        Dim fname As String = Txtfn.Text
        Dim lname As String = Txtln.Text
        Dim uname As String = Txtun.Text
        Dim email As String = Txtemail.Text
        Dim pass As String = Txtpass.Text
        Dim confirmpass As String = Txtcpass.Text

        If fname.Trim() = "" Or lname.Trim() = "" Or uname.Trim() = "" Or email.Trim() = "" Or pass.Trim() = "" Then

            MessageBox.Show("One or more fields are empty", "MISSING DATA!", MessageBoxButtons.OK, MessageBoxIcon.Stop)

        ElseIf Not String.Equals(pass, confirmpass) Then

            MessageBox.Show("Wrong confirmation password", "PASSWORD ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf usernameExist(uname) Then

            MessageBox.Show("This username already exists, Choose another one", "DUPLICATE USERNAME!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

        Else
            'add the new user
            command.Parameters.Add("@fn", MySqlDbType.VarChar).Value = fname
            command.Parameters.Add("@ln", MySqlDbType.VarChar).Value = lname
            command.Parameters.Add("@email", MySqlDbType.VarChar).Value = email
            command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = uname
            command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = pass

            If command.ExecuteNonQuery() = 1 Then

                MessageBox.Show("Registration completed successfully!", "USER ADDED!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                conn.Close()

            Else
                MessageBox.Show("Something happen", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                conn.Close()

            End If
        End If
    End Sub

    'create a function to check if the username already exists
    Public Function usernameExist(ByVal uname As String) As Boolean
        connectdb()
        Dim da As New MySqlDataAdapter()
        Dim dt As New DataTable
        Dim command As New MySqlCommand("SELECT * FROM `login` WHERE `username` = @usn", conn)
        Dim connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")

        command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = uname

        da.SelectCommand = command
        da.Fill(dt)


        ' if the username exist return true

        If dt.Rows.Count > 0 Then

            Return True

            ' if not return false
        Else
            Return False

        End If

    End Function



    Private Sub Btnback_Click(sender As Object, e As EventArgs) Handles Btnback.Click
        Dim log_in As New Form1()
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Txtfn_Enter(sender As Object, e As EventArgs) Handles Txtfn.Enter

        Lblfn.ForeColor = Color.Red

    End Sub

    Private Sub Txtfn_Leave(sender As Object, e As EventArgs) Handles Txtfn.Leave

        Lblfn.ForeColor = Color.Black

    End Sub

    Private Sub Txtln_Enter(sender As Object, e As EventArgs) Handles Txtln.Enter

        Lblln.ForeColor = Color.Red

    End Sub

    Private Sub Txtln_Leave(sender As Object, e As EventArgs) Handles Txtln.Leave

        Lblln.ForeColor = Color.Black
    End Sub

    Private Sub Txtun_Enter(sender As Object, e As EventArgs) Handles Txtun.Enter

        Lblun.ForeColor = Color.Red
    End Sub

    Private Sub Txtun_Leave(sender As Object, e As EventArgs) Handles Txtun.Leave

        Lblun.ForeColor = Color.Black
    End Sub

    Private Sub Txtemail_Enter(sender As Object, e As EventArgs) Handles Txtemail.Enter

        Lble.ForeColor = Color.Red
    End Sub

    Private Sub Txtemail_Leave(sender As Object, e As EventArgs) Handles Txtemail.Leave

        Lble.ForeColor = Color.Black
    End Sub

    Private Sub Txtpass_Enter(sender As Object, e As EventArgs) Handles Txtpass.Enter

        Lblp.ForeColor = Color.Red
    End Sub

    Private Sub Txtpass_Leave(sender As Object, e As EventArgs) Handles Txtpass.Leave

        Lblp.ForeColor = Color.Black
    End Sub

    Private Sub Txtcpass_Enter(sender As Object, e As EventArgs) Handles Txtcpass.Enter

        Lblcp.ForeColor = Color.Red
    End Sub

    Private Sub Txtcpass_Leave(sender As Object, e As EventArgs) Handles Txtcpass.Leave

        Lblcp.ForeColor = Color.Black
    End Sub

    Private Sub Lblcreataccount_MouseEnter(sender As Object, e As EventArgs) Handles Lblaccount.MouseEnter
        Lblaccount.ForeColor = Color.Red
    End Sub

    Private Sub Lblcreataccount_MouseLeave(sender As Object, e As EventArgs) Handles Lblaccount.MouseLeave
        Lblaccount.ForeColor = Color.Blue
    End Sub

    Private Sub Lblaccount_Click(sender As Object, e As EventArgs) Handles Lblaccount.Click
        Me.Hide()
        Dim lform As New Login()
        lform.Show()
    End Sub


    'close
    Private Sub Pbclose_Click(sender As Object, e As EventArgs) Handles Pbclose.Click
        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If
    End Sub

    'maximize
    Private Sub Pbmaximize_Click(sender As Object, e As EventArgs) Handles Pbmaximize.Click
        Me.WindowState = FormWindowState.Maximized
    End Sub

    'minimize
    Private Sub Pbminimize_Click(sender As Object, e As EventArgs) Handles Pbminimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub



    Private Sub Txtemail_Validating(sender As Object, e As CancelEventArgs) Handles Txtemail.Validating
        Dim p As String
        p = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z]*@[0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"

        If Regex.IsMatch(Txtemail.Text, p) Then
            MsgBox("email is valid", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, "validate")

        Else MsgBox("email is not valid", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "Not validate")

        End If
    End Sub
End Class