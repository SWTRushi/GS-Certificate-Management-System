﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Status

Public Class Form1


    Private Sub Btnlogin1_Click(sender As Object, e As EventArgs) Handles Btnlogin1.Click
        Dim log_in As New Login()
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub Btnsignin1_Click(sender As Object, e As EventArgs) Handles Btnsignin1.Click
        Dim log_in As New Signin1()
        Signin1.Show()
        Me.Hide()

    End Sub

    Private Sub Btnexit1_Click(sender As Object, e As EventArgs) Handles Btnexit1.Click
        Dim log_in As New logout()
        logout.Show()
        Me.Hide()

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click

        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
