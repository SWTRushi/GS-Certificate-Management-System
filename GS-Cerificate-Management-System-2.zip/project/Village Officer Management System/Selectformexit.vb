﻿Public Class Selectformexit
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim MENU As New Selectform()
        Selectform.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Result As DialogResult = MessageBox.Show("Are you sure you want to Logout ?", "confermation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If Result = DialogResult.Yes Then
            Me.Hide()
            logout.Show()
        End If
    End Sub

    Private Sub Selectformexit_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Btnlofin_Click(sender As Object, e As EventArgs) Handles Btnlofin.Click
        Dim MENU As New Form1()
        Form1.Show()
        Me.Hide()
    End Sub
End Class