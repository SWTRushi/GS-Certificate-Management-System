﻿Public Class logout

    Private Sub Btnlogout_Click(sender As Object, e As EventArgs) Handles Btnlogout.Click

        Me.Close()

    End Sub

    Private Sub Btnlogoutcancel_Click(sender As Object, e As EventArgs) Handles Btnlogoutcancel.Click

        Dim other_form As New Form1()

        Form1.Show()

        Me.Hide()
    End Sub

    Private Sub logout_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The App", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub Pb_close_Click(sender As Object, e As EventArgs)

        Dim response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If


    End Sub

    Private Sub Pbmaximize_Click(sender As Object, e As EventArgs)

        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub pbminimize_Click(sender As Object, e As EventArgs)

        Me.WindowState = FormWindowState.Minimized
    End Sub

    'Private Sub Pb5_Click(sender As Object, e As EventArgs) Handles Pb5.Click


    ' Dim response As Integer

    '    response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

    ' If response = vbYes Then
    '        Application.ExitThread()

    'End If
    'End Sub
End Class