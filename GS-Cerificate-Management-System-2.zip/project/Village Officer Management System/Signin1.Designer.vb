﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Signin1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lblfn = New System.Windows.Forms.Label()
        Me.Lblp = New System.Windows.Forms.Label()
        Me.Txtfn = New System.Windows.Forms.TextBox()
        Me.Txtpass = New System.Windows.Forms.TextBox()
        Me.Btnsignin = New System.Windows.Forms.Button()
        Me.Btnback = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Lblun = New System.Windows.Forms.Label()
        Me.Lblln = New System.Windows.Forms.Label()
        Me.Lble = New System.Windows.Forms.Label()
        Me.Txtun = New System.Windows.Forms.TextBox()
        Me.Txtln = New System.Windows.Forms.TextBox()
        Me.Txtemail = New System.Windows.Forms.TextBox()
        Me.Txtcpass = New System.Windows.Forms.TextBox()
        Me.Lblcp = New System.Windows.Forms.Label()
        Me.Lblaccount = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Pbminimize = New System.Windows.Forms.PictureBox()
        Me.Pbmaximize = New System.Windows.Forms.PictureBox()
        Me.Pbclose = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Pbminimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbmaximize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbclose, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(726, 166)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(283, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "USER REGISTER"
        '
        'Lblfn
        '
        Me.Lblfn.AutoSize = True
        Me.Lblfn.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblfn.Location = New System.Drawing.Point(496, 240)
        Me.Lblfn.Name = "Lblfn"
        Me.Lblfn.Size = New System.Drawing.Size(175, 32)
        Me.Lblfn.TabIndex = 1
        Me.Lblfn.Text = "* First  Name"
        '
        'Lblp
        '
        Me.Lblp.AutoSize = True
        Me.Lblp.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblp.Location = New System.Drawing.Point(496, 536)
        Me.Lblp.Name = "Lblp"
        Me.Lblp.Size = New System.Drawing.Size(150, 32)
        Me.Lblp.TabIndex = 2
        Me.Lblp.Text = "* Password"
        '
        'Txtfn
        '
        Me.Txtfn.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtfn.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtfn.Location = New System.Drawing.Point(496, 275)
        Me.Txtfn.Multiline = True
        Me.Txtfn.Name = "Txtfn"
        Me.Txtfn.Size = New System.Drawing.Size(347, 42)
        Me.Txtfn.TabIndex = 3
        '
        'Txtpass
        '
        Me.Txtpass.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtpass.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtpass.Location = New System.Drawing.Point(496, 571)
        Me.Txtpass.Multiline = True
        Me.Txtpass.Name = "Txtpass"
        Me.Txtpass.Size = New System.Drawing.Size(347, 42)
        Me.Txtpass.TabIndex = 4
        '
        'Btnsignin
        '
        Me.Btnsignin.BackColor = System.Drawing.Color.Transparent
        Me.Btnsignin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnsignin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnsignin.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsignin.Location = New System.Drawing.Point(711, 653)
        Me.Btnsignin.Name = "Btnsignin"
        Me.Btnsignin.Size = New System.Drawing.Size(293, 60)
        Me.Btnsignin.TabIndex = 5
        Me.Btnsignin.Text = "Register "
        Me.Btnsignin.UseVisualStyleBackColor = False
        '
        'Btnback
        '
        Me.Btnback.BackColor = System.Drawing.Color.Transparent
        Me.Btnback.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnback.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnback.ForeColor = System.Drawing.Color.DimGray
        Me.Btnback.Location = New System.Drawing.Point(1157, 742)
        Me.Btnback.Name = "Btnback"
        Me.Btnback.Size = New System.Drawing.Size(94, 52)
        Me.Btnback.TabIndex = 6
        Me.Btnback.Text = "BACK"
        Me.Btnback.UseVisualStyleBackColor = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_back_642
        Me.PictureBox3.Location = New System.Drawing.Point(1106, 742)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(53, 52)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 13
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_642
        Me.PictureBox1.Location = New System.Drawing.Point(814, 60)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(109, 99)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources._49676211
        Me.PictureBox2.Location = New System.Drawing.Point(-7, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(484, 840)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 20
        Me.PictureBox2.TabStop = False
        '
        'Lblun
        '
        Me.Lblun.AutoSize = True
        Me.Lblun.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblun.Location = New System.Drawing.Point(496, 338)
        Me.Lblun.Name = "Lblun"
        Me.Lblun.Size = New System.Drawing.Size(164, 32)
        Me.Lblun.TabIndex = 21
        Me.Lblun.Text = "* User Name"
        '
        'Lblln
        '
        Me.Lblln.AutoSize = True
        Me.Lblln.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblln.Location = New System.Drawing.Point(909, 240)
        Me.Lblln.Name = "Lblln"
        Me.Lblln.Size = New System.Drawing.Size(170, 32)
        Me.Lblln.TabIndex = 22
        Me.Lblln.Text = "* Last  Name"
        '
        'Lble
        '
        Me.Lble.AutoSize = True
        Me.Lble.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lble.Location = New System.Drawing.Point(496, 438)
        Me.Lble.Name = "Lble"
        Me.Lble.Size = New System.Drawing.Size(106, 32)
        Me.Lble.TabIndex = 23
        Me.Lble.Text = "* Email"
        '
        'Txtun
        '
        Me.Txtun.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtun.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtun.Location = New System.Drawing.Point(496, 373)
        Me.Txtun.Multiline = True
        Me.Txtun.Name = "Txtun"
        Me.Txtun.Size = New System.Drawing.Size(537, 42)
        Me.Txtun.TabIndex = 24
        '
        'Txtln
        '
        Me.Txtln.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtln.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtln.Location = New System.Drawing.Point(909, 275)
        Me.Txtln.Multiline = True
        Me.Txtln.Name = "Txtln"
        Me.Txtln.Size = New System.Drawing.Size(342, 42)
        Me.Txtln.TabIndex = 25
        '
        'Txtemail
        '
        Me.Txtemail.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtemail.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtemail.Location = New System.Drawing.Point(496, 474)
        Me.Txtemail.Multiline = True
        Me.Txtemail.Name = "Txtemail"
        Me.Txtemail.Size = New System.Drawing.Size(537, 42)
        Me.Txtemail.TabIndex = 26
        '
        'Txtcpass
        '
        Me.Txtcpass.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor
        Me.Txtcpass.BackColor = System.Drawing.Color.Gainsboro
        Me.Txtcpass.Location = New System.Drawing.Point(909, 571)
        Me.Txtcpass.Multiline = True
        Me.Txtcpass.Name = "Txtcpass"
        Me.Txtcpass.Size = New System.Drawing.Size(342, 42)
        Me.Txtcpass.TabIndex = 27
        '
        'Lblcp
        '
        Me.Lblcp.AutoSize = True
        Me.Lblcp.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblcp.Location = New System.Drawing.Point(909, 536)
        Me.Lblcp.Name = "Lblcp"
        Me.Lblcp.Size = New System.Drawing.Size(258, 32)
        Me.Lblcp.TabIndex = 28
        Me.Lblcp.Text = "* Confirm Password"
        '
        'Lblaccount
        '
        Me.Lblaccount.AutoSize = True
        Me.Lblaccount.BackColor = System.Drawing.Color.Transparent
        Me.Lblaccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Lblaccount.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Lblaccount.ForeColor = System.Drawing.Color.Navy
        Me.Lblaccount.Location = New System.Drawing.Point(711, 730)
        Me.Lblaccount.Name = "Lblaccount"
        Me.Lblaccount.Size = New System.Drawing.Size(301, 20)
        Me.Lblaccount.TabIndex = 29
        Me.Lblaccount.Text = "Do You Have An Account? Sign In Here"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel1.Controls.Add(Me.Pbminimize)
        Me.Panel1.Controls.Add(Me.Pbmaximize)
        Me.Panel1.Controls.Add(Me.Pbclose)
        Me.Panel1.Location = New System.Drawing.Point(476, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(796, 56)
        Me.Panel1.TabIndex = 30
        '
        'Pbminimize
        '
        Me.Pbminimize.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_minimize_506
        Me.Pbminimize.Location = New System.Drawing.Point(630, 10)
        Me.Pbminimize.Name = "Pbminimize"
        Me.Pbminimize.Size = New System.Drawing.Size(44, 37)
        Me.Pbminimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbminimize.TabIndex = 33
        Me.Pbminimize.TabStop = False
        '
        'Pbmaximize
        '
        Me.Pbmaximize.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_maximize_506
        Me.Pbmaximize.Location = New System.Drawing.Point(680, 10)
        Me.Pbmaximize.Name = "Pbmaximize"
        Me.Pbmaximize.Size = New System.Drawing.Size(44, 37)
        Me.Pbmaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbmaximize.TabIndex = 32
        Me.Pbmaximize.TabStop = False
        '
        'Pbclose
        '
        Me.Pbclose.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_close6
        Me.Pbclose.Location = New System.Drawing.Point(730, 10)
        Me.Pbclose.Name = "Pbclose"
        Me.Pbclose.Size = New System.Drawing.Size(44, 37)
        Me.Pbclose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbclose.TabIndex = 31
        Me.Pbclose.TabStop = False
        '
        'Signin1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.ClientSize = New System.Drawing.Size(1273, 837)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Lblaccount)
        Me.Controls.Add(Me.Lblcp)
        Me.Controls.Add(Me.Txtcpass)
        Me.Controls.Add(Me.Txtemail)
        Me.Controls.Add(Me.Txtln)
        Me.Controls.Add(Me.Txtun)
        Me.Controls.Add(Me.Lble)
        Me.Controls.Add(Me.Lblln)
        Me.Controls.Add(Me.Lblun)
        Me.Controls.Add(Me.Btnback)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Btnsignin)
        Me.Controls.Add(Me.Txtpass)
        Me.Controls.Add(Me.Txtfn)
        Me.Controls.Add(Me.Lblp)
        Me.Controls.Add(Me.Lblfn)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Signin1"
        Me.Text = "Signin1"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.Pbminimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbmaximize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbclose, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Lblfn As Label
    Friend WithEvents Lblp As Label
    Friend WithEvents Txtfn As TextBox
    Friend WithEvents Txtpass As TextBox
    Friend WithEvents Btnsignin As Button
    Friend WithEvents Btnback As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Lblun As Label
    Friend WithEvents Lblln As Label
    Friend WithEvents Lble As Label
    Friend WithEvents Txtun As TextBox
    Friend WithEvents Txtln As TextBox
    Friend WithEvents Txtemail As TextBox
    Friend WithEvents Txtcpass As TextBox
    Friend WithEvents Lblcp As Label
    Friend WithEvents Lblaccount As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Pbminimize As PictureBox
    Friend WithEvents Pbmaximize As PictureBox
    Friend WithEvents Pbclose As PictureBox
End Class
