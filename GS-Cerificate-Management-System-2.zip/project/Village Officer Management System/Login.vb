﻿Imports System.Text
Imports System.Security.Cryptography
Imports MySql.Data.MySqlClient
Public Class Login

    Private Sub Btnlogin_Click(sender As Object, e As EventArgs) Handles Btnlogin.Click

        Dim da As New MySqlDataAdapter
        Dim dt As New DataTable
        Dim command As New MySqlCommand("SELECT  `username`, `password` FROM `login` WHERE `username`= @usn AND `password` = @pass", conn)
        Dim cmd As New MySqlCommand
        Dim connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")


        connectdb()

        command.Parameters.Add("@usn", MySqlDbType.VarChar).Value = Txtun.Text
        command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = Txtpw.Text

        If Txtun.Text.Trim() = "" Or Txtun.Text.Trim.ToLower() = "username" Then

            MessageBox.Show("Enter your username to login", "MISSING USERNAME!", MessageBoxButtons.OK, MessageBoxIcon.Error)


        ElseIf Txtpw.Text.Trim() = "" Or Txtpw.Text.Trim.ToLower() = "password" Then

            MessageBox.Show("Enter your password  to login", "MISSING PASSWORD!", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else

            da.SelectCommand = command
            da.Fill(dt)

            If dt.Rows.Count > 0 Then

                MessageBox.Show("Loging successfully!", "LOGGED!", MessageBoxButtons.OK, MessageBoxIcon.Information)

                Dim mainform As New Form3()
                Form3.Show()
                Me.Hide()

            Else
                MessageBox.Show("This username or/and password doesn't exists!", "LOGGING ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If



        End If
    End Sub

    'show password
    Private Sub Cbrememberme_CheckedChanged(sender As Object, e As EventArgs) Handles Cbrememberme.CheckedChanged

        If Cbrememberme.Checked = False Then
            Txtpw.PasswordChar = "*"
        Else
            Txtpw.PasswordChar = ""

        End If
    End Sub

    Private Sub Btnbackarrow_Click(sender As Object, e As EventArgs) Handles Btnbackarrow.Click
        Dim log_in As New Form1()
        Form1.Show()
        Me.Hide()

    End Sub
    Private Sub Lblcreataccount_MouseEnter(sender As Object, e As EventArgs) Handles Lblcreataccount.MouseEnter

        Lblcreataccount.ForeColor = Color.Red

    End Sub

    Private Sub Lblcreataccount_MouseLeave(sender As Object, e As EventArgs) Handles Lblcreataccount.MouseLeave

        Lblcreataccount.ForeColor = Color.Blue
    End Sub

    'create account
    Private Sub Lblcreataccount_Click(sender As Object, e As EventArgs) Handles Lblcreataccount.Click

        Me.Hide()
        Dim rform As New Signin1()
        rform.Show()
    End Sub

    'close
    Private Sub Pbcloseform_Click(sender As Object, e As EventArgs) Handles Pbcloseform.Click
        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If
    End Sub

    'maximize
    Private Sub Pbmaximize_Click(sender As Object, e As EventArgs) Handles Pbmaximize.Click
        Me.WindowState = FormWindowState.Maximized
    End Sub

    'minimize
    Private Sub Pbminimize_Click(sender As Object, e As EventArgs) Handles Pbminimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub


End Class