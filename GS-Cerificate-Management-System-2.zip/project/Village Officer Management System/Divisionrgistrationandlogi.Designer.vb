﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Divisionrgistrationandlogi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btndarmlogin = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Lbldiviselect = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 77)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 20)
        Me.Label1.TabIndex = 0
        '
        'Btndarmlogin
        '
        Me.Btndarmlogin.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Btndarmlogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btndarmlogin.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btndarmlogin.Location = New System.Drawing.Point(107, 205)
        Me.Btndarmlogin.Name = "Btndarmlogin"
        Me.Btndarmlogin.Size = New System.Drawing.Size(438, 50)
        Me.Btndarmlogin.TabIndex = 2
        Me.Btndarmlogin.Text = "System Login"
        Me.Btndarmlogin.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SkyBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(259, 292)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(133, 55)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Lbldiviselect
        '
        Me.Lbldiviselect.AutoSize = True
        Me.Lbldiviselect.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbldiviselect.ForeColor = System.Drawing.Color.White
        Me.Lbldiviselect.Location = New System.Drawing.Point(144, 77)
        Me.Lbldiviselect.Name = "Lbldiviselect"
        Me.Lbldiviselect.Size = New System.Drawing.Size(373, 35)
        Me.Lbldiviselect.TabIndex = 4
        Me.Lbldiviselect.Text = "SELECT SYSTEM LOGIN"
        '
        'Divisionrgistrationandlogi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SkyBlue
        Me.ClientSize = New System.Drawing.Size(662, 442)
        Me.Controls.Add(Me.Lbldiviselect)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btndarmlogin)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Divisionrgistrationandlogi"
        Me.Text = "Divisionrgistrationandlogi"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Btndarmlogin As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Lbldiviselect As Label
End Class
