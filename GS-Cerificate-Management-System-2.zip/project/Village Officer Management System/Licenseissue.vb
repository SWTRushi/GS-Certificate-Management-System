﻿Imports MySql.Data.MySqlClient

Public Class Licenseissue
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable
    Private Sub Btnadd_Click(sender As Object, e As EventArgs) Handles Btnadd.Click

        Try
            connectdb()

            Dim quary As String = "INSERT INTO `license` ( `License_ID` , `License_Type`) VALUES (@License_ID, @License_Type)"


            command = New MySqlCommand(quary, conn)

            command.Parameters.AddWithValue("@License_ID", Txtlid.Text)
            command.Parameters.AddWithValue("@License_Type", Txtlt.Text)


            Dim result As Integer = command.ExecuteNonQuery()
            If result > 0 Then
                MsgBox("License Registered successfully!")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error Adding License!")


            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try
    End Sub

    Private Sub LoadData()
        Try
            connectdb()
            'connectdb()
            Dim query As String = "SELECT * FROM license"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            DGVL.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub ClearInputs()
        ' connectdb()
        Txtlid.Clear()
        Txtlt.Clear()


    End Sub

    Private Sub Licenseissue_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Private Sub DGVL_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVL.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DGVL.Rows(e.RowIndex)
            Txtlid.Text = row.Cells("License_ID").Value.ToString()
            Txtlt.Text = row.Cells("License_Type").Value.ToString()


        End If
    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click

        Try
            connectdb()

            Dim updateQuery As String = "UPDATE license SET License_Type WHERE License_ID = @License_ID"
            command = New MySqlCommand(updateQuery, conn)

            command.Parameters.AddWithValue("@License_Type", Txtlt.Text)
            command.Parameters.AddWithValue("@License_ID", Txtlid.Text)

            Dim result As Integer = command.ExecuteNonQuery()

            If result > 0 Then
                MsgBox("License name updated successfully!")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error updating License Name !")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        LoadData()
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click


        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this License?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Try
                connectdb()


                Dim deleteQuery As String = "DELETE FROM license WHERE License_ID = @License_ID"
                command = New MySqlCommand(deleteQuery, conn)

                command.Parameters.AddWithValue("@License_ID", Txtlid.Text)
                command.Parameters.AddWithValue("@License_Type", Txtlt.Text)



                Dim deleteResult As Integer = command.ExecuteNonQuery()

                If deleteResult > 0 Then
                    MsgBox("License deleted successfully!")
                    ClearInputs()
                    LoadData()
                Else
                    MsgBox("Error deleting License !")
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                conn.Close()
            End Try

        End If
        conn.Close()
        LoadData()
    End Sub
End Class