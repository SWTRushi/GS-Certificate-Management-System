﻿'Public Class Officialdetails
'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
'Dim other_form As New candidatedetails()

'   other_form.Show()

'Me.Hide()
'End Sub

'Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

'Dim other_form As New Scholarshipdetails()

'   other_form.Show()

'Me.Hide()
'End Sub

'    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

'    Dim other_form As New certificatedetails()

'       other_form.Show()

'   Me.Hide()
'  End Sub

'  Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click


'show the previous form 
'     Userselectionform.Show()

'close the current form 

' Me.Close()
'End Sub
'End Class