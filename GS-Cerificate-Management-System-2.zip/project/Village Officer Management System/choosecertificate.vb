﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Status
Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Asn1.Ocsp
Imports Org.BouncyCastle.Crypto.Tls

Public Class choosecertificate
    Private Sub Btncharactercerti_Click(sender As Object, e As EventArgs) Handles Btncharactercerti.Click

        panelStatus.Height = Btncharactercerti.Height
        panelStatus.Top = Btncharactercerti.Top

        With charactor_certificate
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(charactor_certificate)
            .BringToFront()
            .Show()
        End With
    End Sub



End Class