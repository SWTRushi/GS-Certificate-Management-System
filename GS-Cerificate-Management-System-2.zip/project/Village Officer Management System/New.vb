﻿Imports MySql.Data.MySqlClient

Module Newmodule
    Public Function executenonquery(query As String) As Boolean
        Try

            Dim command As New MySqlCommand(query, conn)
            command.ExecuteNonQuery()
            Return True


        Catch ex As Exception
            MessageBox.Show("error executing query:" & ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False

        End Try
    End Function

    Public Function executequery(query As String) As DataTable
        Try

            Dim datatable As New DataTable()
            Dim adapter As New MySqlDataAdapter(query, conn)
            adapter.Fill(datatable)
            Return datatable

        Catch ex As Exception
            MessageBox.Show("error executing query:" & ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing

        End Try
    End Function

    ' Public Function executereader(query As String) As DataTable
    'Try
    '       connectdb()
    'Dim datatable As New DataTable()
    'Dim adapter As New MySqlDataAdapter(query, conn)
    '       adapter.Fill(datatable)
    'Return datatable

    'Catch ex As Exception
    '       MessageBox.Show("error executing query:" & ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    'Return Nothing
    '       conn.Close()
    'End Try

    'End Function
End Module

