﻿Imports System.Drawing.Printing
Public Class charactor_certificate
    Dim WithEvents pd As New PrintDocument
    Dim ppd As New PrintPreviewDialog
    Dim longpaper As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ppd.Document = Pdoc
        ppd.ShowDialog()
    End Sub
    Private Sub charactor_certificate_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'set the background color
        ' Replace these hexadecimal color values with the ones you've chosen from coolors.co
        Dim color1 As Color = ColorTranslator.FromHtml("#DCDCDD")
        Dim color2 As Color = ColorTranslator.FromHtml("#FFC300")
        Dim color3 As Color = ColorTranslator.FromHtml("#DAF7A6")
        Dim color4 As Color = ColorTranslator.FromHtml("#9AECDB")
        Dim color5 As Color = ColorTranslator.FromHtml("#5BC0EB")

        ' You can then use these colors in your VB.NET application
        Me.BackColor = color1

    End Sub

    Private Sub PrintPreviewDialog1_Load(sender As Object, e As EventArgs) Handles PrintPreviewDialog1.Load

        Dim pagesetup As New PageSettings
        pagesetup.PaperSize = New PaperSize("custom", 250, 500)
        pd.DefaultPageSettings = pagesetup

    End Sub

    Private Sub Pdoc_PrintPage(sender As Object, e As PrintPageEventArgs) Handles Pdoc.PrintPage
        'FONT STYLE
        Dim f8 As New Font("calibri", 14, FontStyle.Regular)
        Dim f10 As New Font("calibri", 16, FontStyle.Bold)
        Dim f10b As New Font("calibri", 15, FontStyle.Bold)
        Dim f14 As New Font("calibri", 18, FontStyle.Bold)

        'MARGIN
        Dim leftmargin As Integer = pd.DefaultPageSettings.Margins.Left
        Dim centermargin As Integer = pd.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = pd.DefaultPageSettings.PaperSize.Width

        'FONT ALLIGNMENT
        Dim right As New StringFormat
        Dim center As New StringFormat
        right.Alignment = StringAlignment.Far
        center.Alignment = StringAlignment.Center



        Dim topic As String = Label1.Text

        Dim topic2 As String = Label22.Text

        Dim informationaboutapplicant As String = Label6.Text

        Dim otherinfo As String = Label28.Text

        Dim certindex As String = Txtindex.Text

        Dim district As String = Label2.Text
        Dim district2 As String = Txtdsd.Text

        Dim gramaNiladhariDivision As String = Label3.Text
        Dim gramaNiladhariNumber As String = Txtdn.Text

        Dim knownToGramaNiladhari As String = Label4.Text
        Dim knownToGramaNiladhari2 As String = cb3.Text

        Dim sinceWhen As String = Label5.Text
        Dim sinceWhen2 As String = Txtdate1.Text

        Dim name As String = Label7.Text
        Dim name2 As String = Txt8.Text

        Dim sex As String = Label8.Text
        Dim sex2 As String = cb9.Text

        Dim age As String = Label9.Text
        Dim age2 As String = Txt16.Text

        Dim civilStatus As String = Label10.Text
        Dim civilStatus2 As String = cbcivil.Text

        Dim srilankan As String = Label11.Text
        Dim srilankan2 As String = cb15.Text

        Dim religion As String = Label12.Text
        Dim religion2 As String = cb10.Text

        Dim occupation As String = Label13.Text
        Dim occupation2 As String = Txt17.Text

        Dim periodOfResidence As String = Label14.Text
        Dim periodOfResidence2 As String = txt18.Text

        Dim nicNumber As String = Label15.Text
        Dim nicNumber2 As String = Txt11.Text

        Dim fatherName As String = Label16.Text
        Dim fatherName2 As String = Txt12.Text

        Dim purpose As String = Label17.Text
        Dim purpose2 As String = Txt13.Text

        Dim convicted As String = Label19.Text
        Dim convicted2 As String = cb5.Text

        Dim character As String = Label20.Text
        Dim character2 As String = Txt6.Text

        Dim text As String = Txt7.Text

        Dim certify1 As String = txtcertify1.Text
        Dim certify2 As String = txtcertify2.Text

        Dim applicantsign As String = Label18.Text
        Dim gssign As String = Label23.Text

        Dim d1 As String = Label24.Text
        Dim d2 As String = Label26.Text
        ' Dim sign1 As String = Label25.Text
        Dim sign2 As String = Label27.Text

        Dim certificate As String = certificate



        e.Graphics.DrawString(topic, f14, Brushes.Black, centermargin, 5, center)

        e.Graphics.DrawString(topic2, f8, Brushes.Black, centermargin, 40, center)

        e.Graphics.DrawString(certindex, f8, Brushes.Black, rightmargin, 11, right)


        e.Graphics.DrawString(district, f10b, Brushes.Black, 20, 100)
        e.Graphics.DrawString(district2, f8, Brushes.Black, 430, 100)

        e.Graphics.DrawString(gramaNiladhariDivision, f10b, Brushes.Black, 20, 140)
        e.Graphics.DrawString(gramaNiladhariNumber, f8, Brushes.Black, 430, 140)

        e.Graphics.DrawString(knownToGramaNiladhari, f10b, Brushes.Black, 20, 180)
        e.Graphics.DrawString(knownToGramaNiladhari2, f8, Brushes.Black, 590, 180)

        e.Graphics.DrawString(sinceWhen, f10b, Brushes.Black, 20, 220)
        e.Graphics.DrawString(sinceWhen2, f8, Brushes.Black, 430, 220)

        e.Graphics.DrawString(informationaboutapplicant, f10, Brushes.Black, 20, 260)

        e.Graphics.DrawString(name, f10b, Brushes.Black, 40, 300)
        e.Graphics.DrawString(name2, f8, Brushes.Black, 430, 300)


        e.Graphics.DrawString(sex, f10b, Brushes.Black, 40, 340)
        e.Graphics.DrawString(sex2, f8, Brushes.Black, 430, 340)

        e.Graphics.DrawString(religion, f10b, Brushes.Black, 40, 380)
        e.Graphics.DrawString(religion2, f8, Brushes.Black, 430, 380)

        e.Graphics.DrawString(nicNumber, f10b, Brushes.Black, 40, 420)
        e.Graphics.DrawString(nicNumber2, f8, Brushes.Black, 430, 420)

        e.Graphics.DrawString(age, f10b, Brushes.Black, 40, 460)
        e.Graphics.DrawString(age2, f8, Brushes.Black, 430, 460)

        e.Graphics.DrawString(fatherName, f10b, Brushes.Black, 40, 500)
        e.Graphics.DrawString(fatherName2, f8, Brushes.Black, 430, 500)


        e.Graphics.DrawString(civilStatus, f10b, Brushes.Black, 40, 540)
        e.Graphics.DrawString(civilStatus2, f8, Brushes.Black, 430, 540)

        e.Graphics.DrawString(srilankan, f10b, Brushes.Black, 40, 580)
        e.Graphics.DrawString(srilankan2, f8, Brushes.Black, 430, 580)

        e.Graphics.DrawString(occupation, f10b, Brushes.Black, 40, 620)
        e.Graphics.DrawString(occupation2, f8, Brushes.Black, 430, 620)

        e.Graphics.DrawString(periodOfResidence, f10b, Brushes.Black, 40, 660)
        e.Graphics.DrawString(periodOfResidence2, f8, Brushes.Black, 430, 660)

        e.Graphics.DrawString(applicantsign, f10b, Brushes.Black, 570, 680)



        e.Graphics.DrawString(otherinfo, f10b, Brushes.Black, 20, 720)

        e.Graphics.DrawString(convicted, f10b, Brushes.Black, 40, 760)
        e.Graphics.DrawString(convicted2, f8, Brushes.Black, 585, 760)

        e.Graphics.DrawString(character, f10b, Brushes.Black, 40, 800)
        e.Graphics.DrawString(character2, f8, Brushes.Black, 430, 800)

        e.Graphics.DrawString(text, f10b, Brushes.Black, 30, 850)

        e.Graphics.DrawString(certify1, f8, Brushes.Black, 410, 900)

        e.Graphics.DrawString(certify2, f8, Brushes.Black, 300, 952)


        e.Graphics.DrawString(gssign, f10b, Brushes.Black, 520, 980)

        e.Graphics.DrawString(d1, f10b, Brushes.Black, 30, 1000)

        'e.Graphics.DrawString(sign1, f10b, Brushes.Black, 480, 1020)

        e.Graphics.DrawString(d2, f10b, Brushes.Black, 30, 1060)

        e.Graphics.DrawString(sign2, f10b, Brushes.Black, 530, 1070)

    End Sub

    Private Sub Txt7_TextChanged(sender As Object, e As EventArgs) Handles Txt7.TextChanged

    End Sub
End Class
