﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Btngeneratecertificate = New System.Windows.Forms.Button()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Btn_about = New System.Windows.Forms.Button()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.panelStatus = New System.Windows.Forms.Panel()
        Me.Btn_issue = New System.Windows.Forms.Button()
        Me.Btn_payment = New System.Windows.Forms.Button()
        Me.Btn_certificate = New System.Windows.Forms.Button()
        Me.Btn_resident = New System.Windows.Forms.Button()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Btn_logout = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Pb4 = New System.Windows.Forms.PictureBox()
        Me.Pb2 = New System.Windows.Forms.PictureBox()
        Me.Pb3 = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.Pb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pb3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkRed
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(316, 1024)
        Me.Panel1.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel5.Controls.Add(Me.PictureBox8)
        Me.Panel5.Controls.Add(Me.Btngeneratecertificate)
        Me.Panel5.Controls.Add(Me.PictureBox7)
        Me.Panel5.Controls.Add(Me.PictureBox2)
        Me.Panel5.Controls.Add(Me.PictureBox6)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Controls.Add(Me.PictureBox5)
        Me.Panel5.Controls.Add(Me.PictureBox1)
        Me.Panel5.Controls.Add(Me.PictureBox4)
        Me.Panel5.Controls.Add(Me.Btn_about)
        Me.Panel5.Controls.Add(Me.PictureBox3)
        Me.Panel5.Controls.Add(Me.panelStatus)
        Me.Panel5.Controls.Add(Me.Btn_issue)
        Me.Panel5.Controls.Add(Me.Btn_payment)
        Me.Panel5.Controls.Add(Me.Btn_certificate)
        Me.Panel5.Controls.Add(Me.Btn_resident)
        Me.Panel5.Controls.Add(Me.Btn_Home)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(382, 1024)
        Me.Panel5.TabIndex = 1
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_register_48
        Me.PictureBox8.Location = New System.Drawing.Point(21, 654)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(61, 92)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 11
        Me.PictureBox8.TabStop = False
        '
        'Btngeneratecertificate
        '
        Me.Btngeneratecertificate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btngeneratecertificate.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btngeneratecertificate.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btngeneratecertificate.Location = New System.Drawing.Point(12, 654)
        Me.Btngeneratecertificate.Name = "Btngeneratecertificate"
        Me.Btngeneratecertificate.Size = New System.Drawing.Size(298, 92)
        Me.Btngeneratecertificate.TabIndex = 10
        Me.Btngeneratecertificate.Text = "   GENERATE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "   CHARACTER " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "   CERTIFICATE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Btngeneratecertificate.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_about_us_94
        Me.PictureBox7.Location = New System.Drawing.Point(21, 763)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(64, 62)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 4
        Me.PictureBox7.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_home_64
        Me.PictureBox2.Location = New System.Drawing.Point(21, 150)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(60, 63)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_register_48
        Me.PictureBox6.Location = New System.Drawing.Point(20, 543)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(61, 92)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(-4, 102)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(328, 29)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "SYSTEM ADMINISTRATOR"
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_payment_60
        Me.PictureBox5.Location = New System.Drawing.Point(21, 423)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(60, 96)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 2
        Me.PictureBox5.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_64
        Me.PictureBox1.Location = New System.Drawing.Point(94, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(112, 96)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_form_48
        Me.PictureBox4.Location = New System.Drawing.Point(20, 328)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(61, 62)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 1
        Me.PictureBox4.TabStop = False
        '
        'Btn_about
        '
        Me.Btn_about.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_about.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_about.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_about.Location = New System.Drawing.Point(11, 763)
        Me.Btn_about.Name = "Btn_about"
        Me.Btn_about.Size = New System.Drawing.Size(298, 62)
        Me.Btn_about.TabIndex = 6
        Me.Btn_about.Text = "ABOUT US"
        Me.Btn_about.UseVisualStyleBackColor = True
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_64__2_1
        Me.PictureBox3.Location = New System.Drawing.Point(19, 236)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(62, 67)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'panelStatus
        '
        Me.panelStatus.BackColor = System.Drawing.Color.White
        Me.panelStatus.Location = New System.Drawing.Point(12, 150)
        Me.panelStatus.Name = "panelStatus"
        Me.panelStatus.Size = New System.Drawing.Size(10, 61)
        Me.panelStatus.TabIndex = 5
        '
        'Btn_issue
        '
        Me.Btn_issue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_issue.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_issue.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_issue.Location = New System.Drawing.Point(12, 543)
        Me.Btn_issue.Name = "Btn_issue"
        Me.Btn_issue.Size = New System.Drawing.Size(298, 92)
        Me.Btn_issue.TabIndex = 1
        Me.Btn_issue.Text = "  STORE ISSUE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "  CERTIFICATE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    INFORMATION"
        Me.Btn_issue.UseVisualStyleBackColor = True
        '
        'Btn_payment
        '
        Me.Btn_payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_payment.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_payment.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_payment.Location = New System.Drawing.Point(12, 423)
        Me.Btn_payment.Name = "Btn_payment"
        Me.Btn_payment.Size = New System.Drawing.Size(298, 96)
        Me.Btn_payment.TabIndex = 0
        Me.Btn_payment.Text = "      STORE PAYMENT" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    DETAILS AND" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    GENERATE  BARCODE"
        Me.Btn_payment.UseVisualStyleBackColor = True
        '
        'Btn_certificate
        '
        Me.Btn_certificate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_certificate.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_certificate.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_certificate.Location = New System.Drawing.Point(12, 328)
        Me.Btn_certificate.Name = "Btn_certificate"
        Me.Btn_certificate.Size = New System.Drawing.Size(298, 62)
        Me.Btn_certificate.TabIndex = 0
        Me.Btn_certificate.Text = "    CERTIFICATE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "    INFO"
        Me.Btn_certificate.UseVisualStyleBackColor = True
        '
        'Btn_resident
        '
        Me.Btn_resident.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_resident.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_resident.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_resident.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.Btn_resident.Location = New System.Drawing.Point(12, 236)
        Me.Btn_resident.Name = "Btn_resident"
        Me.Btn_resident.Size = New System.Drawing.Size(298, 67)
        Me.Btn_resident.TabIndex = 0
        Me.Btn_resident.Text = "RESIDENT" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " INFO"
        Me.Btn_resident.UseVisualStyleBackColor = True
        '
        'Btn_Home
        '
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Home.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_Home.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Btn_Home.Location = New System.Drawing.Point(12, 150)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(298, 63)
        Me.Btn_Home.TabIndex = 0
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(12, 406)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(298, 45)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "HOME"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(12, 323)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(298, 45)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "HOME"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(12, 234)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(298, 45)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "HOME"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(12, 150)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(298, 45)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "HOME"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Btn_logout
        '
        Me.Btn_logout.BackColor = System.Drawing.Color.Black
        Me.Btn_logout.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_logout.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_logout.ForeColor = System.Drawing.Color.White
        Me.Btn_logout.Location = New System.Drawing.Point(9, 11)
        Me.Btn_logout.Name = "Btn_logout"
        Me.Btn_logout.Size = New System.Drawing.Size(127, 40)
        Me.Btn_logout.TabIndex = 0
        Me.Btn_logout.Text = "LOGOUT"
        Me.Btn_logout.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SlateGray
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Btn_logout)
        Me.Panel2.Controls.Add(Me.Pb4)
        Me.Panel2.Controls.Add(Me.Pb2)
        Me.Panel2.Controls.Add(Me.Pb3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.Panel2.Location = New System.Drawing.Point(316, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1220, 57)
        Me.Panel2.TabIndex = 1
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Black
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(146, 11)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(94, 40)
        Me.Button5.TabIndex = 0
        Me.Button5.Text = "BACK"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Pb4
        '
        Me.Pb4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_close
        Me.Pb4.Location = New System.Drawing.Point(1113, 9)
        Me.Pb4.Name = "Pb4"
        Me.Pb4.Size = New System.Drawing.Size(47, 45)
        Me.Pb4.TabIndex = 3
        Me.Pb4.TabStop = False
        '
        'Pb2
        '
        Me.Pb2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_minimize_50
        Me.Pb2.Location = New System.Drawing.Point(1000, 8)
        Me.Pb2.Name = "Pb2"
        Me.Pb2.Size = New System.Drawing.Size(48, 46)
        Me.Pb2.TabIndex = 1
        Me.Pb2.TabStop = False
        '
        'Pb3
        '
        Me.Pb3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_maximize_50
        Me.Pb3.Location = New System.Drawing.Point(1054, 8)
        Me.Pb3.Name = "Pb3"
        Me.Pb3.Size = New System.Drawing.Size(53, 51)
        Me.Pb3.TabIndex = 2
        Me.Pb3.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(316, 57)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1220, 967)
        Me.Panel3.TabIndex = 2
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1536, 1024)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.Panel1.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.Pb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pb3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents panelStatus As Panel
    Friend WithEvents Btn_issue As Button
    Friend WithEvents Btn_payment As Button
    Friend WithEvents Btn_certificate As Button
    Friend WithEvents Btn_resident As Button
    Friend WithEvents Btn_Home As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Btn_about As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Btn_logout As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Pb4 As PictureBox
    Friend WithEvents Pb2 As PictureBox
    Friend WithEvents Pb3 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Btngeneratecertificate As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox8 As PictureBox
End Class
