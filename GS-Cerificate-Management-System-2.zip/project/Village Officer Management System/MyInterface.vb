﻿Public Class form2
    Private Sub Btn_Home_Click(sender As Object, e As EventArgs) Handles Btn_Home.Click
        PanelStatus.Height = Btn_Home.Height
        PanelStatus.Top = Btn_Home.Top
    End Sub

    Private Sub Btn_resident_Click(sender As Object, e As EventArgs) Handles Btn_resident.Click
        PanelStatus.Height = Btn_resident.Height
        PanelStatus.Top = Btn_resident.Top
    End Sub

    Private Sub Btn_certificate_Click(sender As Object, e As EventArgs) Handles Btn_certificate.Click
        PanelStatus.Height = Btn_certificate.Height
        PanelStatus.Top = Btn_certificate.Top
    End Sub

    Private Sub Btn_issue_Click(sender As Object, e As EventArgs) Handles Btn_issue.Click
        PanelStatus.Height = Btn_issue.Height
        PanelStatus.Top = Btn_issue.Top
    End Sub

    Private Sub Btn_about_Click(sender As Object, e As EventArgs) Handles Btn_about.Click
        PanelStatus.Height = Btn_about.Height
        PanelStatus.Top = Btn_about.Top
    End Sub
End Class