﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ClientForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtCandidateid = New System.Windows.Forms.TextBox()
        Me.TxtCandidatename = New System.Windows.Forms.TextBox()
        Me.TxtMobileno = New System.Windows.Forms.TextBox()
        Me.MySqlCommand1 = New MySql.Data.MySqlClient.MySqlCommand()
        Me.DGVClient = New System.Windows.Forms.DataGridView()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Btnedit = New System.Windows.Forms.Button()
        Me.Txthomeno = New System.Windows.Forms.TextBox()
        Me.Txtage = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Txtnic = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Btnloaddata = New System.Windows.Forms.Button()
        Me.cbsearch = New System.Windows.Forms.ComboBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CBsex = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Txtmrcb = New System.Windows.Forms.TextBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        CType(Me.DGVClient, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(44, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Resident ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(4, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Resident Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(263, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(149, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Home Number"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(107, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Sex"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(48, 232)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Mobile No"
        '
        'TxtCandidateid
        '
        Me.TxtCandidateid.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCandidateid.Location = New System.Drawing.Point(175, 30)
        Me.TxtCandidateid.Multiline = True
        Me.TxtCandidateid.Name = "TxtCandidateid"
        Me.TxtCandidateid.Size = New System.Drawing.Size(272, 33)
        Me.TxtCandidateid.TabIndex = 5
        '
        'TxtCandidatename
        '
        Me.TxtCandidatename.BackColor = System.Drawing.SystemColors.Window
        Me.TxtCandidatename.Location = New System.Drawing.Point(175, 77)
        Me.TxtCandidatename.Multiline = True
        Me.TxtCandidatename.Name = "TxtCandidatename"
        Me.TxtCandidatename.Size = New System.Drawing.Size(272, 35)
        Me.TxtCandidatename.TabIndex = 6
        '
        'TxtMobileno
        '
        Me.TxtMobileno.BackColor = System.Drawing.SystemColors.Window
        Me.TxtMobileno.Location = New System.Drawing.Point(175, 228)
        Me.TxtMobileno.Multiline = True
        Me.TxtMobileno.Name = "TxtMobileno"
        Me.TxtMobileno.Size = New System.Drawing.Size(271, 35)
        Me.TxtMobileno.TabIndex = 9
        '
        'MySqlCommand1
        '
        Me.MySqlCommand1.CacheAge = 0
        Me.MySqlCommand1.Connection = Nothing
        Me.MySqlCommand1.EnableCaching = False
        Me.MySqlCommand1.Transaction = Nothing
        '
        'DGVClient
        '
        Me.DGVClient.BackgroundColor = System.Drawing.Color.Gray
        Me.DGVClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVClient.Location = New System.Drawing.Point(548, 176)
        Me.DGVClient.Name = "DGVClient"
        Me.DGVClient.RowHeadersWidth = 51
        Me.DGVClient.RowTemplate.Height = 29
        Me.DGVClient.Size = New System.Drawing.Size(560, 479)
        Me.DGVClient.TabIndex = 10
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.Color.Transparent
        Me.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnAdd.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.BtnAdd.Location = New System.Drawing.Point(190, 348)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(229, 45)
        Me.BtnAdd.TabIndex = 11
        Me.BtnAdd.Text = "ADD RESIDENT"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.Color.Transparent
        Me.Btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btndelete.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btndelete.ForeColor = System.Drawing.Color.Black
        Me.Btndelete.Location = New System.Drawing.Point(205, 12)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(120, 37)
        Me.Btndelete.TabIndex = 12
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(100, 286)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 25)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Age"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(616, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(142, 31)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Resident ID "
        '
        'Btnsearch
        '
        Me.Btnsearch.BackColor = System.Drawing.Color.Transparent
        Me.Btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnsearch.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsearch.Location = New System.Drawing.Point(877, 47)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(95, 30)
        Me.Btnsearch.TabIndex = 18
        Me.Btnsearch.Text = "Search "
        Me.Btnsearch.UseVisualStyleBackColor = False
        '
        'Btnedit
        '
        Me.Btnedit.BackColor = System.Drawing.Color.Transparent
        Me.Btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnedit.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnedit.ForeColor = System.Drawing.Color.Black
        Me.Btnedit.Location = New System.Drawing.Point(82, 12)
        Me.Btnedit.Name = "Btnedit"
        Me.Btnedit.Size = New System.Drawing.Size(107, 38)
        Me.Btnedit.TabIndex = 19
        Me.Btnedit.Text = "EDIT"
        Me.Btnedit.UseVisualStyleBackColor = False
        '
        'Txthomeno
        '
        Me.Txthomeno.BackColor = System.Drawing.SystemColors.Window
        Me.Txthomeno.Location = New System.Drawing.Point(416, 29)
        Me.Txthomeno.Multiline = True
        Me.Txthomeno.Name = "Txthomeno"
        Me.Txthomeno.Size = New System.Drawing.Size(130, 35)
        Me.Txthomeno.TabIndex = 20
        '
        'Txtage
        '
        Me.Txtage.BackColor = System.Drawing.SystemColors.Window
        Me.Txtage.Location = New System.Drawing.Point(175, 282)
        Me.Txtage.Multiline = True
        Me.Txtage.Name = "Txtage"
        Me.Txtage.Size = New System.Drawing.Size(271, 35)
        Me.Txtage.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(79, 130)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 25)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "NIC No"
        '
        'Txtnic
        '
        Me.Txtnic.BackColor = System.Drawing.SystemColors.Window
        Me.Txtnic.Location = New System.Drawing.Point(175, 130)
        Me.Txtnic.Multiline = True
        Me.Txtnic.Name = "Txtnic"
        Me.Txtnic.Size = New System.Drawing.Size(272, 35)
        Me.Txtnic.TabIndex = 23
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(517, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(111, 37)
        Me.Button1.TabIndex = 24
        Me.Button1.Text = "BACK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(167, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(354, 42)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Resident Information"
        '
        'Btnloaddata
        '
        Me.Btnloaddata.BackColor = System.Drawing.Color.Transparent
        Me.Btnloaddata.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnloaddata.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnloaddata.ForeColor = System.Drawing.Color.Black
        Me.Btnloaddata.Location = New System.Drawing.Point(342, 12)
        Me.Btnloaddata.Name = "Btnloaddata"
        Me.Btnloaddata.Size = New System.Drawing.Size(159, 37)
        Me.Btnloaddata.TabIndex = 27
        Me.Btnloaddata.Text = "LOAD DATA"
        Me.Btnloaddata.UseVisualStyleBackColor = False
        '
        'cbsearch
        '
        Me.cbsearch.FormattingEnabled = True
        Me.cbsearch.Location = New System.Drawing.Point(622, 47)
        Me.cbsearch.Name = "cbsearch"
        Me.cbsearch.Size = New System.Drawing.Size(256, 28)
        Me.cbsearch.TabIndex = 28
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1136, 89)
        Me.Panel1.TabIndex = 29
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_50
        Me.PictureBox1.Location = New System.Drawing.Point(70, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(91, 74)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkGray
        Me.Panel2.Controls.Add(Me.CBsex)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Txtnic)
        Me.Panel2.Controls.Add(Me.TxtCandidateid)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.TxtCandidatename)
        Me.Panel2.Controls.Add(Me.Txtage)
        Me.Panel2.Controls.Add(Me.TxtMobileno)
        Me.Panel2.Controls.Add(Me.BtnAdd)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Location = New System.Drawing.Point(22, 176)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(479, 479)
        Me.Panel2.TabIndex = 30
        '
        'CBsex
        '
        Me.CBsex.BackColor = System.Drawing.SystemColors.Window
        Me.CBsex.FormattingEnabled = True
        Me.CBsex.Items.AddRange(New Object() {"Male", "Female"})
        Me.CBsex.Location = New System.Drawing.Point(175, 182)
        Me.CBsex.Name = "CBsex"
        Me.CBsex.Size = New System.Drawing.Size(272, 28)
        Me.CBsex.TabIndex = 34
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(35, 422)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(412, 40)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "Clear Field"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.SlateGray
        Me.Panel3.Controls.Add(Me.Btnloaddata)
        Me.Panel3.Controls.Add(Me.Btndelete)
        Me.Panel3.Controls.Add(Me.Btnedit)
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 661)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1136, 62)
        Me.Panel3.TabIndex = 31
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_search1
        Me.PictureBox2.Location = New System.Drawing.Point(971, 47)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(31, 32)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 32
        Me.PictureBox2.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(9, 35)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(107, 25)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "MRCB No"
        '
        'Txtmrcb
        '
        Me.Txtmrcb.BackColor = System.Drawing.SystemColors.Window
        Me.Txtmrcb.Location = New System.Drawing.Point(122, 29)
        Me.Txtmrcb.Multiline = True
        Me.Txtmrcb.Name = "Txtmrcb"
        Me.Txtmrcb.Size = New System.Drawing.Size(126, 35)
        Me.Txtmrcb.TabIndex = 30
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.SlateGray
        Me.Panel4.Controls.Add(Me.Txtmrcb)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.PictureBox2)
        Me.Panel4.Controls.Add(Me.Txthomeno)
        Me.Panel4.Controls.Add(Me.cbsearch)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Controls.Add(Me.Btnsearch)
        Me.Panel4.Location = New System.Drawing.Point(0, 86)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1136, 78)
        Me.Panel4.TabIndex = 31
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'ClientForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(1136, 723)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DGVClient)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "ClientForm"
        CType(Me.DGVClient, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TxtCandidateid As TextBox
    Friend WithEvents TxtCandidatename As TextBox
    Friend WithEvents TxtMobileno As TextBox
    Friend WithEvents MySqlCommand1 As MySql.Data.MySqlClient.MySqlCommand
    Friend WithEvents DGVClient As DataGridView
    Friend WithEvents BtnAdd As Button
    Friend WithEvents Btndelete As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Btnsearch As Button
    Friend WithEvents Btnedit As Button
    Friend WithEvents Txthomeno As TextBox
    Friend WithEvents Txtage As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Txtnic As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Btnloaddata As Button
    Friend WithEvents cbsearch As ComboBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Txtmrcb As TextBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents CBsex As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
