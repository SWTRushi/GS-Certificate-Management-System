﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class scholarship
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lblsid = New System.Windows.Forms.Label()
        Me.Lblsname = New System.Windows.Forms.Label()
        Me.Txtsid = New System.Windows.Forms.TextBox()
        Me.Txtsname = New System.Windows.Forms.TextBox()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txts_search = New System.Windows.Forms.TextBox()
        Me.Btnssearch = New System.Windows.Forms.Button()
        Me.DGVs = New System.Windows.Forms.DataGridView()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Btnedit = New System.Windows.Forms.Button()
        CType(Me.DGVs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoEllipsis = True
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Location = New System.Drawing.Point(334, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(311, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Scholarship Registration"
        '
        'Lblsid
        '
        Me.Lblsid.AutoSize = True
        Me.Lblsid.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Lblsid.Location = New System.Drawing.Point(30, 103)
        Me.Lblsid.Name = "Lblsid"
        Me.Lblsid.Size = New System.Drawing.Size(129, 22)
        Me.Lblsid.TabIndex = 1
        Me.Lblsid.Text = "Scholarship ID"
        '
        'Lblsname
        '
        Me.Lblsname.AutoSize = True
        Me.Lblsname.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Lblsname.Location = New System.Drawing.Point(30, 182)
        Me.Lblsname.Name = "Lblsname"
        Me.Lblsname.Size = New System.Drawing.Size(155, 22)
        Me.Lblsname.TabIndex = 2
        Me.Lblsname.Text = "Scholarship Name"
        '
        'Txtsid
        '
        Me.Txtsid.BackColor = System.Drawing.Color.LightBlue
        Me.Txtsid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtsid.Location = New System.Drawing.Point(30, 126)
        Me.Txtsid.Multiline = True
        Me.Txtsid.Name = "Txtsid"
        Me.Txtsid.Size = New System.Drawing.Size(325, 36)
        Me.Txtsid.TabIndex = 8
        '
        'Txtsname
        '
        Me.Txtsname.BackColor = System.Drawing.Color.LightBlue
        Me.Txtsname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtsname.Location = New System.Drawing.Point(30, 205)
        Me.Txtsname.Multiline = True
        Me.Txtsname.Name = "Txtsname"
        Me.Txtsname.Size = New System.Drawing.Size(325, 36)
        Me.Txtsname.TabIndex = 9
        '
        'Btnadd
        '
        Me.Btnadd.BackColor = System.Drawing.Color.PowderBlue
        Me.Btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnadd.Location = New System.Drawing.Point(44, 294)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(247, 33)
        Me.Btnadd.TabIndex = 15
        Me.Btnadd.Text = "ADD RECORD"
        Me.Btnadd.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(429, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(220, 28)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Find Scholarship Details"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(429, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(129, 22)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Scholarship ID"
        '
        'Txts_search
        '
        Me.Txts_search.BackColor = System.Drawing.Color.LightBlue
        Me.Txts_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txts_search.Location = New System.Drawing.Point(564, 124)
        Me.Txts_search.Multiline = True
        Me.Txts_search.Name = "Txts_search"
        Me.Txts_search.Size = New System.Drawing.Size(257, 38)
        Me.Txts_search.TabIndex = 8
        '
        'Btnssearch
        '
        Me.Btnssearch.BackColor = System.Drawing.Color.PowderBlue
        Me.Btnssearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnssearch.Location = New System.Drawing.Point(564, 175)
        Me.Btnssearch.Name = "Btnssearch"
        Me.Btnssearch.Size = New System.Drawing.Size(94, 29)
        Me.Btnssearch.TabIndex = 15
        Me.Btnssearch.Text = "Search"
        Me.Btnssearch.UseVisualStyleBackColor = False
        '
        'DGVs
        '
        Me.DGVs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVs.Location = New System.Drawing.Point(429, 225)
        Me.DGVs.Name = "DGVs"
        Me.DGVs.RowHeadersWidth = 51
        Me.DGVs.RowTemplate.Height = 29
        Me.DGVs.Size = New System.Drawing.Size(693, 270)
        Me.DGVs.TabIndex = 17
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.Color.PowderBlue
        Me.Btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btndelete.Location = New System.Drawing.Point(429, 519)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(94, 35)
        Me.Btndelete.TabIndex = 18
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.PowderBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(1063, 596)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 41)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "BACK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Btnedit
        '
        Me.Btnedit.BackColor = System.Drawing.Color.LightBlue
        Me.Btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnedit.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnedit.Location = New System.Drawing.Point(597, 521)
        Me.Btnedit.Name = "Btnedit"
        Me.Btnedit.Size = New System.Drawing.Size(94, 33)
        Me.Btnedit.TabIndex = 20
        Me.Btnedit.Text = "edit"
        Me.Btnedit.UseVisualStyleBackColor = False
        '
        'scholarship
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.ClientSize = New System.Drawing.Size(1187, 681)
        Me.Controls.Add(Me.Btnedit)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btndelete)
        Me.Controls.Add(Me.DGVs)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Btnssearch)
        Me.Controls.Add(Me.Btnadd)
        Me.Controls.Add(Me.Txtsname)
        Me.Controls.Add(Me.Txts_search)
        Me.Controls.Add(Me.Txtsid)
        Me.Controls.Add(Me.Lblsname)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Lblsid)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "scholarship"
        Me.Text = "scholarship"
        CType(Me.DGVs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Lblsid As Label
    Friend WithEvents Lblsname As Label
    Friend WithEvents Txtsid As TextBox
    Friend WithEvents Txtsname As TextBox
    Friend WithEvents Btnadd As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Txts_search As TextBox
    Friend WithEvents Btnssearch As Button
    Friend WithEvents DGVs As DataGridView
    Friend WithEvents Btndelete As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Btnedit As Button
    ' Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
End Class
