﻿Public Class Divisionrgistrationandlogi
    'Private Sub Btndarm_Click(sender As Object, e As EventArgs) Handles Btndarm.Click

    ' Dim other_form As New Divisionalinfo()

    ' other_form.Show()

    ' Me.Hide()
    'End Sub

    Private Sub Btndarmlogin_Click(sender As Object, e As EventArgs) Handles Btndarmlogin.Click

        Dim other_form As New Userselectionform()

        other_form.Show()

        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim other_form As New logout()

        other_form.Show()

        Me.Hide()
    End Sub

    Private Sub Divisionrgistrationandlogi_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class