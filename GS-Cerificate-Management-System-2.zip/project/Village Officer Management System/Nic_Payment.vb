﻿Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient
Imports MessagingToolkit.QRCode.Codec
Imports MessagingToolkit.QRCode.Codec.Data
Imports MessagingToolkit.Barcode

Public Class Nic_Payment
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable
    Private Sub Nic_Payment_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        LoadData()

        Txtcidd.Enabled = False
        Txtcnamee.Enabled = False
        'Txtcaa.Enabled = False
        Txtchh.Enabled = False
        ' Txtnn.Enabled = False
        Txtcmm.Enabled = False
        'Txtcagee.Enabled = False



        Dim reader2 As MySqlDataReader
        Try
            connectdb()
            Dim query2 As String
            query2 = "select * from ict222.clientform2 "
            command = New MySqlCommand(query2, conn)
            reader2 = command.ExecuteReader
            While reader2.Read
                Dim clientid = reader2.GetString("Candidate_ID")
                Cbidd.Items.Add(clientid)

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub


    Private Sub Cbid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cbidd.SelectedIndexChanged



        Dim reader2 As MySqlDataReader
        Try
            connectdb()
            Dim query2 As String
            query2 = "select * from ict222.clientform2 where Candidate_ID = '" & Cbidd.Text & "' "
            command = New MySqlCommand(query2, conn)
            reader2 = command.ExecuteReader
            While reader2.Read
                Txtcidd.Text = reader2.GetString("Candidate_ID")
                Txtcnamee.Text = reader2.GetString("Candidate_Name")
                Txtchh.Text = reader2.GetString("Home_No")
                Txtcmm.Text = reader2.GetString("Mobile_No")
                'Txtcaa.Text = reader2.GetString("Address")
                'Txtnn.Text = reader2.GetString("Candidate_Nic")
                ' Txtcagee.Text = reader2.GetInt32("age")


            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim READER As MySqlDataReader
        Try
            connectdb()

            Dim query As String = "INSERT INTO ict222. nic_payment (Resident_id , Resident_name, Home_no, Mobile_no, Payment_id , Fees, Date, Bar_code)  VALUES ( '" & Txtcidd.Text & "', '" & Txtcnamee.Text & "', '" & Txtchh.Text & "', '" & Txtcmm.Text & "',  '" & Txtpayid.Text & "', '" & Txtpayfees.Text & "',  '" & DTP_date.Text & "','" & Txtbar.Text & "' )"
            command = New MySqlCommand(query, conn)

            READER = command.ExecuteReader
            MessageBox.Show("Data record saved")

            LoadData()
            ClearInputs()

            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub LoadData()
        Try
            connectdb()
            'connectdb()
            Dim query As String = "SELECT * FROM nic_payment"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            ' da.Fill(dt)
            DGVpayment.DataSource = dt

            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub
    Private Sub ClearInputs()

        Txtcidd.Clear()
        Txtcnamee.Clear()
        ' Txtcaa.Clear()
        Txtchh.Clear()
        'Txtnn.Clear()
        Txtcmm.Clear()
        'Txtcagee.Clear()
        Txtpayid.Clear()
        ' Txtpayreason.Clear()
        Txtpayfees.Clear()
        'Txtbarcode.Clear()
        Txtbar.Clear()


    End Sub

    Private Sub DGVpayment_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVpayment.CellContentClick

        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DGVpayment.Rows(e.RowIndex)

            Txtcidd.Text = row.Cells("Resident_id").Value.ToString()
            Txtcnamee.Text = row.Cells("Resident_name").Value.ToString()
            Txtchh.Text = row.Cells("Home_no").Value.ToString()
            ' Txtcaa.Text = row.Cells("Address").Value.ToString()
            Txtcmm.Text = row.Cells("Mobile_no").Value.ToString()
            'Txtnn.Text = row.Cells("Nic_no").Value.ToString()
            ' Txtcagee.Text = row.Cells("Age").Value.ToString()
            Txtpayid.Text = row.Cells("Payment_id").Value.ToString()
            'Txtpayreason.Text = row.Cells("Reason").Value.ToString()
            Txtpayfees.Text = row.Cells("Fees").Value.ToString()
            DTP_date.Text = row.Cells("Date").Value.ToString()
            Txtbar.Text = row.Cells("barcode").Value.ToString()


        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'LOAD DATA
        Dim SDA2 As New MySqlDataAdapter
        Dim dbdataset2 As New DataTable
        Dim bsource2 As New BindingSource
        Try
            connectdb()
            Dim query As String = "select * from ict222.nic_payment"
            command = New MySqlCommand(query, conn)
            SDA2.SelectCommand = command
            SDA2.Fill(dbdataset2)
            bsource2.DataSource = dbdataset2
            DGVpayment.DataSource = bsource2
            SDA2.Update(dbdataset2)
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            conn.Close()
        End Try
    End Sub

    'get data to textbox by celclick
    Private Sub DGVpayment_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVpayment.CellClick

        Dim index As Integer
        index = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DGVpayment.Rows(index)

        Txtcidd.Text = selectedRow.Cells(0).Value.ToString()
        Txtcnamee.Text = selectedRow.Cells(1).Value.ToString()
        Txtchh.Text = selectedRow.Cells(2).Value.ToString()
        Txtcmm.Text = selectedRow.Cells(3).Value.ToString()
        'Txtcaa.Text = selectedRow.Cells(4).Value.ToString()
        ' Txtnn.Text = selectedRow.Cells(5).Value.ToString()
        ' Txtcagee.Text = selectedRow.Cells(6).Value.ToString()
        Txtpayid.Text = selectedRow.Cells(4).Value.ToString()
        'Txtpayreason.Text = selectedRow.Cells(8).Value.ToString()
        Txtpayfees.Text = selectedRow.Cells(5).Value.ToString()
        DTP_date.Text = selectedRow.Cells(6).Value.ToString()
        Txtbar.Text = selectedRow.Cells(7).Value.ToString()

    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click

        Dim READER4 As MySqlDataReader
        Try
            connectdb()

            Dim query As String = " DELETE FROM  ict222.nic_payment  WHERE  Resident_id = '" & Txtcidd.Text & "' "
            command = New MySqlCommand(query, conn)

            READER4 = command.ExecuteReader
            MessageBox.Show("Data Record Deleted!")

            LoadData()
            ClearInputs()

            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click


        Dim READER4 As MySqlDataReader
        Try
            connectdb()

            Dim query As String = " UPDATE ict222.nic_payment SET Resident_name = '" & Txtcnamee.Text & "', Home_no = '" & Txtchh.Text & "', Mobile_no = '" & Txtcmm.Text & "' ,, payment_id ='" & Txtpayid.Text & "', Fees ='" & Txtpayfees.Text & "', Date ='" & DTP_date.Text & "' , barcode= '" & Txtbar.Text & "'   WHERE Resident_id = '" & Txtcidd.Text & "' "
            command = New MySqlCommand(query, conn)

            READER4 = command.ExecuteReader
            MessageBox.Show("Data Record Updated!")

            LoadData()
            ClearInputs()

            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub



    ' Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    ' Dim Generator As New MessagingToolkit.Barcode.BarcodeEncoder
    '    Generator.BackColor = Color.White
    '   Generator.LabelFont = New Font("Arial", 7, FontStyle.Regular)
    '  Generator.IncludeLabel = True
    ' Generator.CustomLabel = txt_barcode.Text
    'Try
    '       Pic_barcode.Image = New Bitmap(Generator.Encode(MessagingToolkit.Barcode.BarcodeFormat.Code93, txt_barcode.Text))
    'Catch ex As Exception
    'End Try

    'End Sub


    Private Sub Label14_Click(sender As Object, e As EventArgs) Handles Label14.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub
End Class