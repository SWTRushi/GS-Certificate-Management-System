﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Userselectionform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Lblselectionsystem = New System.Windows.Forms.Label()
        Me.Btniodm = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Btnsystemlogexit = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Lblselectionsystem
        '
        Me.Lblselectionsystem.AutoSize = True
        Me.Lblselectionsystem.BackColor = System.Drawing.Color.Transparent
        Me.Lblselectionsystem.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Lblselectionsystem.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lblselectionsystem.Location = New System.Drawing.Point(241, 111)
        Me.Lblselectionsystem.Name = "Lblselectionsystem"
        Me.Lblselectionsystem.Size = New System.Drawing.Size(300, 38)
        Me.Lblselectionsystem.TabIndex = 0
        Me.Lblselectionsystem.Text = "SELECT SYSTEM LOGIN"
        '
        'Btniodm
        '
        Me.Btniodm.BackColor = System.Drawing.Color.PaleVioletRed
        Me.Btniodm.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btniodm.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btniodm.Location = New System.Drawing.Point(162, 223)
        Me.Btniodm.Name = "Btniodm"
        Me.Btniodm.Size = New System.Drawing.Size(459, 48)
        Me.Btniodm.TabIndex = 2
        Me.Btniodm.Text = "Candidate Information"
        Me.Btniodm.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Plum
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(162, 301)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(459, 45)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Certificate Information"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("STCaiyun", 36.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.SeaShell
        Me.Label1.Location = New System.Drawing.Point(289, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 63)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "HELLO!"
        '
        'Btnsystemlogexit
        '
        Me.Btnsystemlogexit.BackColor = System.Drawing.Color.Transparent
        Me.Btnsystemlogexit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Btnsystemlogexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnsystemlogexit.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsystemlogexit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Btnsystemlogexit.Location = New System.Drawing.Point(334, 460)
        Me.Btnsystemlogexit.Name = "Btnsystemlogexit"
        Me.Btnsystemlogexit.Size = New System.Drawing.Size(94, 42)
        Me.Btnsystemlogexit.TabIndex = 5
        Me.Btnsystemlogexit.Text = "EXIT"
        Me.Btnsystemlogexit.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.MediumPurple
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button2.Location = New System.Drawing.Point(162, 379)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(459, 47)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Issue Certificate Information"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Userselectionform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Village_Officer_Management_System.My.Resources.Resources.kaushalya
        Me.ClientSize = New System.Drawing.Size(784, 514)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Btnsystemlogexit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btniodm)
        Me.Controls.Add(Me.Lblselectionsystem)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Userselectionform"
        Me.Text = "Userselectionform"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lblselectionsystem As Label
    Friend WithEvents Btniodm As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Btnsystemlogexit As Button
    Friend WithEvents Button2 As Button

    Private Sub Btniodm_Click(sender As Object, e As EventArgs) Handles Btniodm.Click

    End Sub
End Class
