﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class License
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Tclicense = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Dgvl = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Cbl = New System.Windows.Forms.ComboBox()
        Me.Txtld = New System.Windows.Forms.TextBox()
        Me.Txtla = New System.Windows.Forms.TextBox()
        Me.Txtlc = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Txtli = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Dgvll = New System.Windows.Forms.DataGridView()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Cbln = New System.Windows.Forms.ComboBox()
        Me.Txtldd = New System.Windows.Forms.TextBox()
        Me.Txtlaa = New System.Windows.Forms.TextBox()
        Me.Txtlcc = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Txtlll = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Tclicense.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.Dgvl, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.Dgvll, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label1.Location = New System.Drawing.Point(275, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(352, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ISSUE LICENSE DETAILS"
        '
        'Tclicense
        '
        Me.Tclicense.Controls.Add(Me.TabPage1)
        Me.Tclicense.Controls.Add(Me.TabPage2)
        Me.Tclicense.Location = New System.Drawing.Point(44, 92)
        Me.Tclicense.Name = "Tclicense"
        Me.Tclicense.SelectedIndex = 0
        Me.Tclicense.Size = New System.Drawing.Size(1400, 584)
        Me.Tclicense.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightBlue
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Dgvl)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.Cbl)
        Me.TabPage1.Controls.Add(Me.Txtld)
        Me.TabPage1.Controls.Add(Me.Txtla)
        Me.TabPage1.Controls.Add(Me.Txtlc)
        Me.TabPage1.Controls.Add(Me.TextBox5)
        Me.TabPage1.Controls.Add(Me.Txtli)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1392, 551)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TabPage1"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.LightBlue
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button4.Location = New System.Drawing.Point(672, 404)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(94, 29)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "UPDATE"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LightBlue
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button3.Location = New System.Drawing.Point(527, 404)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(94, 29)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "CLEAR"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LightBlue
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button2.Location = New System.Drawing.Point(592, 120)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 29)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "FIND"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Dgvl
        '
        Me.Dgvl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvl.Location = New System.Drawing.Point(528, 181)
        Me.Dgvl.Name = "Dgvl"
        Me.Dgvl.RowHeadersWidth = 51
        Me.Dgvl.RowTemplate.Height = 29
        Me.Dgvl.Size = New System.Drawing.Size(819, 188)
        Me.Dgvl.TabIndex = 12
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(210, 334)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(258, 42)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "ADD RECORD"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Cbl
        '
        Me.Cbl.BackColor = System.Drawing.Color.PowderBlue
        Me.Cbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cbl.FormattingEnabled = True
        Me.Cbl.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.Cbl.Location = New System.Drawing.Point(210, 277)
        Me.Cbl.Name = "Cbl"
        Me.Cbl.Size = New System.Drawing.Size(258, 28)
        Me.Cbl.TabIndex = 10
        '
        'Txtld
        '
        Me.Txtld.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtld.Location = New System.Drawing.Point(210, 234)
        Me.Txtld.Name = "Txtld"
        Me.Txtld.Size = New System.Drawing.Size(258, 27)
        Me.Txtld.TabIndex = 9
        '
        'Txtla
        '
        Me.Txtla.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtla.Location = New System.Drawing.Point(210, 181)
        Me.Txtla.Name = "Txtla"
        Me.Txtla.Size = New System.Drawing.Size(258, 27)
        Me.Txtla.TabIndex = 8
        '
        'Txtlc
        '
        Me.Txtlc.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtlc.Location = New System.Drawing.Point(210, 129)
        Me.Txtlc.Name = "Txtlc"
        Me.Txtlc.Size = New System.Drawing.Size(258, 27)
        Me.Txtlc.TabIndex = 7
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.PowderBlue
        Me.TextBox5.Location = New System.Drawing.Point(591, 79)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(258, 27)
        Me.TextBox5.TabIndex = 6
        '
        'Txtli
        '
        Me.Txtli.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtli.Location = New System.Drawing.Point(210, 79)
        Me.Txtli.Name = "Txtli"
        Me.Txtli.Size = New System.Drawing.Size(258, 27)
        Me.Txtli.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(64, 286)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 19)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "No Of License"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(64, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(106, 19)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Date Of Issue"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(64, 189)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 19)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(64, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 19)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Candidate Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(528, 87)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(49, 19)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Index"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(64, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 19)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Index"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(290, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(302, 25)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "VALUE CERTIFY LICENSE"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.PowderBlue
        Me.TabPage2.Controls.Add(Me.Button8)
        Me.TabPage2.Controls.Add(Me.Button7)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Controls.Add(Me.Dgvll)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.Cbln)
        Me.TabPage2.Controls.Add(Me.Txtldd)
        Me.TabPage2.Controls.Add(Me.Txtlaa)
        Me.TabPage2.Controls.Add(Me.Txtlcc)
        Me.TabPage2.Controls.Add(Me.TextBox10)
        Me.TabPage2.Controls.Add(Me.Txtlll)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1392, 551)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "TabPage2"
        '
        'Button8
        '
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button8.Location = New System.Drawing.Point(524, 453)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(94, 29)
        Me.Button8.TabIndex = 15
        Me.Button8.Text = "UPDATE"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button7.Location = New System.Drawing.Point(524, 395)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(94, 29)
        Me.Button7.TabIndex = 14
        Me.Button7.Text = "CLEAR"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Times New Roman", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button6.Location = New System.Drawing.Point(588, 124)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(94, 29)
        Me.Button6.TabIndex = 13
        Me.Button6.Text = "FIND"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Dgvll
        '
        Me.Dgvll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvll.Location = New System.Drawing.Point(524, 175)
        Me.Dgvll.Name = "Dgvll"
        Me.Dgvll.RowHeadersWidth = 51
        Me.Dgvll.RowTemplate.Height = 29
        Me.Dgvll.Size = New System.Drawing.Size(370, 188)
        Me.Dgvll.TabIndex = 12
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button5.Location = New System.Drawing.Point(136, 382)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(257, 42)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "ADD RECORD"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Cbln
        '
        Me.Cbln.BackColor = System.Drawing.Color.PowderBlue
        Me.Cbln.FormattingEnabled = True
        Me.Cbln.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.Cbln.Location = New System.Drawing.Point(201, 315)
        Me.Cbln.Name = "Cbln"
        Me.Cbln.Size = New System.Drawing.Size(256, 28)
        Me.Cbln.TabIndex = 10
        '
        'Txtldd
        '
        Me.Txtldd.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtldd.Location = New System.Drawing.Point(201, 261)
        Me.Txtldd.Name = "Txtldd"
        Me.Txtldd.Size = New System.Drawing.Size(256, 27)
        Me.Txtldd.TabIndex = 9
        '
        'Txtlaa
        '
        Me.Txtlaa.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtlaa.Location = New System.Drawing.Point(201, 201)
        Me.Txtlaa.Name = "Txtlaa"
        Me.Txtlaa.Size = New System.Drawing.Size(256, 27)
        Me.Txtlaa.TabIndex = 8
        '
        'Txtlcc
        '
        Me.Txtlcc.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtlcc.Location = New System.Drawing.Point(201, 140)
        Me.Txtlcc.Name = "Txtlcc"
        Me.Txtlcc.Size = New System.Drawing.Size(256, 27)
        Me.Txtlcc.TabIndex = 7
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.PowderBlue
        Me.TextBox10.Location = New System.Drawing.Point(583, 81)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(256, 27)
        Me.TextBox10.TabIndex = 6
        '
        'Txtlll
        '
        Me.Txtlll.BackColor = System.Drawing.Color.PowderBlue
        Me.Txtlll.Location = New System.Drawing.Point(201, 81)
        Me.Txtlll.Name = "Txtlll"
        Me.Txtlll.Size = New System.Drawing.Size(256, 27)
        Me.Txtlll.TabIndex = 6
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(48, 323)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(113, 20)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "No Of license"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(48, 264)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(114, 20)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Date Of Issue"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(48, 204)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(71, 20)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Address"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(48, 147)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(139, 20)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Candidate Name"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(524, 84)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(53, 20)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Index"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(48, 88)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 20)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Index"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(268, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(321, 25)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "SOIL TRANSPORT LICENSE"
        '
        'Button9
        '
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button9.Location = New System.Drawing.Point(776, 691)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(113, 46)
        Me.Button9.TabIndex = 2
        Me.Button9.Text = "BACK"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'License
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ClientSize = New System.Drawing.Size(1456, 740)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Tclicense)
        Me.Controls.Add(Me.Label1)
        Me.Name = "License"
        Me.Text = "License"
        Me.Tclicense.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.Dgvl, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.Dgvll, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Tclicense As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Dgvl As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents Cbl As ComboBox
    Friend WithEvents Txtld As TextBox
    Friend WithEvents Txtla As TextBox
    Friend WithEvents Txtlc As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Txtli As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Button8 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Dgvll As DataGridView
    Friend WithEvents Button5 As Button
    Friend WithEvents Cbln As ComboBox
    Friend WithEvents Txtldd As TextBox
    Friend WithEvents Txtlaa As TextBox
    Friend WithEvents Txtlcc As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Txtlll As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Button9 As Button
End Class
