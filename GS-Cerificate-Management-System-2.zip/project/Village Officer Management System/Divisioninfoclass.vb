﻿
Public Class Scholarshipclass
    Public Property scholarship_id As String
    Public Property scholarship_name As String

    'Public Property candidate_id As Integer
    'Public Property candidate_name As String
    'Public Property year As Integer

End Class

Public Class Client_form

    Public Property mrcb_no As Integer
    Public Property Candidate_ID As String
    Public Property Candidate_Name As String
    Public Property Candidate_Nic As String
    Public Property Home_No As Integer
    Public Property Sex As String
    Public Property Mobile_No As String
    Public Property Age As Integer

End Class
Public Class Certificate_class
    Public Property Certificate_id As String
    Public Property Certificate_Type As String

End Class

Public Class tabcertificate2
    Public Property candidate_id As Integer
    Public Property candidate_name As String
    Public Property address As String
    Public Property age As Integer
    Public Property phone_no As Integer
    Public Property home_id As Integer
    Public Property division_name As String
    Public Property qr_code As Integer
    Public Property amount As Integer
    Public Property total_amount As Integer
    Public Property amount_slip_no As Integer
    Public Property slip_no As Integer
    Public Property send_date As Date
End Class





Public Class license_class
    Public Property License_ID As String
    Public Property License_Type As String

End Class

Public Class all_class
    Public Property Candidate_id As String
    Public Property Candidate_Name As String
    Public Property Candidate_Nic As String
    Public Property Home_No As Integer
    Public Property Address As String
    Public Property Mobile_No As String



    Public Property Age As Integer
    Public Property Certificate_id As String
    Public Property Certificate_type As String
    Public Property Certificate_index As Integer
    Public Property Register_Date As Date
End Class

Public Class users_class
    Public Property First_Name As String
    Public Property Last_Name As String
    Public Property Telephone As String
    Public Property Nic As String
    Public Property Address As String
    Public Property Name As String

End Class

Public Class payment
    Public Property Resident_id As String
    Public Property Resident_name As String
    Public Property Home_no As String
    Public Property Mobile_no As Integer
    Public Property Address As String
    Public Property Nic_no As String
    Public Property Age As Integer
    Public Property Payment_id As Integer
    Public Property Reason As String
    Public Property Fees As Integer
    Public Property pay_Date As Date




End Class

