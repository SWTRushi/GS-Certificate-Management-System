﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btn_resident = New System.Windows.Forms.Button()
        Me.Btn_certificate = New System.Windows.Forms.Button()
        Me.Btn_issue = New System.Windows.Forms.Button()
        Me.Btn_payment = New System.Windows.Forms.Button()
        Me.Btn_about = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PanelStatus = New System.Windows.Forms.Panel()
        Me.Btn_Home = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_resident
        '
        Me.Btn_resident.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_resident.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_resident.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_resident.ForeColor = System.Drawing.Color.White
        Me.Btn_resident.Location = New System.Drawing.Point(12, 218)
        Me.Btn_resident.Name = "Btn_resident"
        Me.Btn_resident.Size = New System.Drawing.Size(306, 42)
        Me.Btn_resident.TabIndex = 0
        Me.Btn_resident.Text = "RESIDENT FORM"
        Me.Btn_resident.UseVisualStyleBackColor = False
        '
        'Btn_certificate
        '
        Me.Btn_certificate.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_certificate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_certificate.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_certificate.ForeColor = System.Drawing.Color.White
        Me.Btn_certificate.Location = New System.Drawing.Point(12, 283)
        Me.Btn_certificate.Name = "Btn_certificate"
        Me.Btn_certificate.Size = New System.Drawing.Size(306, 41)
        Me.Btn_certificate.TabIndex = 0
        Me.Btn_certificate.Text = "CERTIFICATE FORM"
        Me.Btn_certificate.UseVisualStyleBackColor = False
        '
        'Btn_issue
        '
        Me.Btn_issue.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_issue.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_issue.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_issue.ForeColor = System.Drawing.Color.White
        Me.Btn_issue.Location = New System.Drawing.Point(12, 351)
        Me.Btn_issue.Name = "Btn_issue"
        Me.Btn_issue.Size = New System.Drawing.Size(306, 39)
        Me.Btn_issue.TabIndex = 0
        Me.Btn_issue.Text = "ISSUE DETAILS"
        Me.Btn_issue.UseVisualStyleBackColor = False
        '
        'Btn_payment
        '
        Me.Btn_payment.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_payment.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_payment.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_payment.ForeColor = System.Drawing.Color.White
        Me.Btn_payment.Location = New System.Drawing.Point(12, 421)
        Me.Btn_payment.Name = "Btn_payment"
        Me.Btn_payment.Size = New System.Drawing.Size(306, 39)
        Me.Btn_payment.TabIndex = 0
        Me.Btn_payment.Text = "PAYMENT  AND BILLING"
        Me.Btn_payment.UseVisualStyleBackColor = False
        '
        'Btn_about
        '
        Me.Btn_about.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_about.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_about.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_about.ForeColor = System.Drawing.Color.White
        Me.Btn_about.Location = New System.Drawing.Point(12, 489)
        Me.Btn_about.Name = "Btn_about"
        Me.Btn_about.Size = New System.Drawing.Size(306, 40)
        Me.Btn_about.TabIndex = 0
        Me.Btn_about.Text = "ABOUT US"
        Me.Btn_about.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(22, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(268, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "GRAMA NILADHAREE "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(12, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(287, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "MANAGEMENT SYSTEM"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DarkRed
        Me.Panel2.Controls.Add(Me.PanelStatus)
        Me.Panel2.Controls.Add(Me.Btn_Home)
        Me.Panel2.Controls.Add(Me.Btn_about)
        Me.Panel2.Controls.Add(Me.Btn_resident)
        Me.Panel2.Controls.Add(Me.Btn_payment)
        Me.Panel2.Controls.Add(Me.Btn_issue)
        Me.Panel2.Controls.Add(Me.Btn_certificate)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(332, 793)
        Me.Panel2.TabIndex = 5
        '
        'PanelStatus
        '
        Me.PanelStatus.BackColor = System.Drawing.Color.White
        Me.PanelStatus.Location = New System.Drawing.Point(12, 138)
        Me.PanelStatus.Name = "PanelStatus"
        Me.PanelStatus.Size = New System.Drawing.Size(10, 42)
        Me.PanelStatus.TabIndex = 6
        '
        'Btn_Home
        '
        Me.Btn_Home.BackColor = System.Drawing.Color.DarkRed
        Me.Btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Home.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_Home.ForeColor = System.Drawing.Color.White
        Me.Btn_Home.Location = New System.Drawing.Point(12, 140)
        Me.Btn_Home.Name = "Btn_Home"
        Me.Btn_Home.Size = New System.Drawing.Size(306, 42)
        Me.Btn_Home.TabIndex = 5
        Me.Btn_Home.Text = "HOME"
        Me.Btn_Home.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(332, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1221, 51)
        Me.Panel1.TabIndex = 6
        '
        'Panel3
        '
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(332, 736)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1221, 57)
        Me.Panel3.TabIndex = 7
        '
        'Panel4
        '
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(332, 51)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1221, 685)
        Me.Panel4.TabIndex = 8
        '
        'form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1553, 793)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "form2"
        Me.Text = "MyInterface"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Btn_resident As Button
    Friend WithEvents Btn_certificate As Button
    Friend WithEvents Btn_issue As Button
    Friend WithEvents Btn_payment As Button
    Friend WithEvents Btn_about As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PanelStatus As Panel
    Friend WithEvents Btn_Home As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
End Class
