﻿Public Class Aboutus
    Private Sub Aboutus_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class