﻿Public Class Selectform
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim chooses As New ClientForm()
        ClientForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim chooses As New certificate()
        certificate.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim chooses As New All()
        All.Show()
        Me.Hide()
    End Sub

    Private Sub Btnexit_Click(sender As Object, e As EventArgs) Handles Btnexit.Click

        Dim selectform As New Selectformexit()
        Selectformexit.Show()
        Me.Hide()
    End Sub

    Private Sub Selectform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Selectform_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The App", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub
End Class