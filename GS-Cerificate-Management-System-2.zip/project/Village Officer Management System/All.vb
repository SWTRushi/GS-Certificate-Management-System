﻿Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Common
Imports System.Drawing.Text
Imports MySql.Data.common
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI
Imports Mysqlx.XDevAPI.Relational

Public Class All
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable



    Private Sub Btnadd_Click(sender As Object, e As EventArgs) Handles Btnadd.Click


        Try
            connectdb()

            Dim query As String = "INSERT INTO ict222.allcertificate (Home_No, Candidate_ID , Candidate_Name, Candidate_Nic, Mobile_No, Certificate_ID , Certificate_Type, certificate_index, Register_Date) VALUES ('" & Txtch.Text & "',  '" & Txtcid.Text & "', '" & Txtcname.Text & "', '" & Txtn.Text & "', '" & Txtcm.Text & "', '" & Txtcertid.Text & "',  '" & Txtctype.Text & "', '" & Txtci.Text & "',  '" & DTP_regi.Text & "' )"

            command = New MySqlCommand(query, conn)

            command.Parameters.AddWithValue("@Home_No", Txtch.Text)
            command.Parameters.AddWithValue("@Candidate_ID", Txtcid.Text)
            command.Parameters.AddWithValue("@Candidate_Name", Txtcname.Text)
            command.Parameters.AddWithValue("@Candidate_Nic", Txtn.Text)
            command.Parameters.AddWithValue("@Mobile_No", Txtcm.Text)
            command.Parameters.AddWithValue("@Certificate_id", Txtcertid.Text)
            command.Parameters.AddWithValue("@Certificate_Type", Txtctype.Text)
            command.Parameters.AddWithValue("Certificate_index", Txtci.Text)
            command.Parameters.AddWithValue("@Register_Date", DTP_regi.Text)


            Dim result As Integer = command.ExecuteNonQuery()
            If result > 0 Then
                MsgBox("Issue details add successfully")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error Adding details")
                MessageBox.Show("Data record saved")

                LoadData()
                ClearInputs()

                conn.Close()
            End If
        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try



    End Sub

    Private Sub LoadData()
        Try
            connectdb()
            'connectdb()
            Dim query As String = "SELECT * FROM allcertificate"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            ' da.Fill(dt)
            DGVALL.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub ClearInputs()
        ' connectdb()
        'Cbnic.SelectedIndex = -1
        'Cbtype.SelectedIndex = -1
        'Cbcerttype.SelectedIndex = -1
        'Txtci.Clear()
        'Txtcopy.Clear()
        ' DTPd.ResetText()

        Txtcid.Clear()
        Txtcname.Clear()
        'Txtca.Clear()
        Txtch.Clear()
        Txtn.Clear()
        Txtcm.Clear()
        'Txtcage.Clear()
        Txtcertid.Clear()
        Txtctype.Clear()
        Txtci.Clear()




    End Sub

    Private Sub All_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        LoadData()

        Txtcid.Enabled = False
        Txtcname.Enabled = False
        ' Txtca.Enabled = False
        Txtch.Enabled = False
        Txtn.Enabled = False
        Txtcm.Enabled = False
        'Txtcage.Enabled = False
        Txtcertid.Enabled = False
        Txtctype.Enabled = False




        Dim READER1 As MySqlDataReader
        Try
            connectdb()
            Dim query As String
            query = "select *  from ict222.certificate "
            command = New MySqlCommand(query, conn)
            READER1 = command.ExecuteReader
            While READER1.Read
                Dim certificatetype = READER1.GetString("Certificate_Type")
                Cbtype.Items.Add(certificatetype)

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try



        Dim reader2 As MySqlDataReader
        Try
            connectdb()
            Dim query2 As String
            query2 = "select Home_No, Candidate_ID, Candidate_Name, Candidate_Nic, Mobile_No from ict222.clientform2 "
            command = New MySqlCommand(query2, conn)
            reader2 = command.ExecuteReader
            While reader2.Read
                Dim clientid = reader2.GetString("Candidate_ID")
                Cbid.Items.Add(clientid)

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try


        Dim reader3 As MySqlDataReader
        Try
            connectdb()
            Dim query3 As String
            query3 = "select * from ict222.allcertificate "
            command = New MySqlCommand(query3, conn)
            reader3 = command.ExecuteReader
            While reader3.Read
                Dim cid = reader3.GetString("Candidate_ID")
                Cbsearch.Items.Add(cid)

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub filter()
        If Cbsearch.Text = "" Then
            MsgBox("Enter Candidate ID number")
        Else
            Dim connectionstring As String = "server=127.0.0.1;user=root;database=ict222;"
            Using db As New MySqlConnection(connectionstring)
                Try


                    connectdb()
                    Dim query As String = "SELECT * FROM allcertificate WHERE Candidate_ID like @Candidate_ID"
                    Using adapter As New MySqlDataAdapter(query, conn)
                        adapter.SelectCommand.Parameters.AddWithValue("@Candidate_ID", "%" & Cbsearch.Text & "%")

                        Dim ds As New DataSet()
                        adapter.Fill(ds)
                        DGVALL.DataSource = ds.Tables(0)
                    End Using
                Catch ex As Exception
                    MsgBox("error connecting to the database: " & ex.Message)

                Finally
                    conn.Close()
                End Try


            End Using
        End If
        conn.Close()
    End Sub

    Private Sub Btnsearch_Click(sender As Object, e As EventArgs) Handles Btnsearch.Click
        filter()
    End Sub

    Private Sub DGVALL_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVALL.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DGVALL.Rows(e.RowIndex)

            Txtch.Text = row.Cells("Home_No").Value.ToString()
            Txtcid.Text = row.Cells("Candidate_ID").Value.ToString()
            Txtcname.Text = row.Cells("Candidate_Name").Value.ToString()
            Txtn.Text = row.Cells("Candidate_Nic").Value.ToString()

            'Txtca.Text = row.Cells("Address").Value.ToString()
            Txtcm.Text = row.Cells("Mobile_No").Value.ToString()
            ' Txtcage.Text = row.Cells("Age").Value.ToString()
            Txtcertid.Text = row.Cells("Certificate_id").Value.ToString()
            Txtctype.Text = row.Cells("Certificate_Type").Value.ToString()
            Txtci.Text = row.Cells("Certificate_index").Value.ToString()
            DTP_regi.Text = row.Cells("Register_Date").Value.ToString()

        End If
    End Sub




    Private Sub Btnback_Click(sender As Object, e As EventArgs) Handles Btnback.Click
        Dim c As New Form3()
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Cbnic_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cbid.SelectedIndexChanged


        Dim reader2 As MySqlDataReader
        Try
            connectdb()
            Dim query2 As String
            query2 = "SELECT  Home_No, Candidate_ID, Candidate_Name, Mobile_No, Candidate_Nic  from ict222.clientform2 where Candidate_ID = '" & Cbid.Text & "' "
            command = New MySqlCommand(query2, conn)
            reader2 = command.ExecuteReader
            While reader2.Read

                Txtch.Text = reader2.GetString("Home_No")
                Txtcid.Text = reader2.GetString("Candidate_ID")
                Txtcname.Text = reader2.GetString("Candidate_Name")
                'Txtca.Text = reader2.GetString("Address")

                Txtcm.Text = reader2.GetString("Mobile_No")
                'Txtcage.Text = reader2.GetInt32("age")
                Txtn.Text = reader2.GetString("Candidate_Nic")

            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub Cbtype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cbtype.SelectedIndexChanged

        Dim READER As MySqlDataReader
        Try
            connectdb()
            Dim query As String
            query = "select * from ict222.certificate where Certificate_Type = '" & Cbtype.Text & "' "
            command = New MySqlCommand(query, conn)
            READER = command.ExecuteReader
            While READER.Read
                Txtcertid.Text = READER.GetString("Certificate_ID")
                Txtctype.Text = READER.GetString("Certificate_Type")
            End While

            conn.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Btnloaddata_Click(sender As Object, e As EventArgs) Handles Btnloaddata.Click

        Dim SDA2 As New MySqlDataAdapter
        Dim dbdataset2 As New DataTable
        Dim bsource2 As New BindingSource
        Try
            connectdb()
            Dim query As String = "select * from ict222.allcertificate"
            command = New MySqlCommand(query, conn)
            SDA2.SelectCommand = command
            SDA2.Fill(dbdataset2)
            bsource2.DataSource = dbdataset2
            DGVALL.DataSource = bsource2
            SDA2.Update(dbdataset2)
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click

        Dim READER4 As MySqlDataReader
        Try
            connectdb()

            Dim query As String = " DELETE FROM  ict222.allcertificate WHERE  Candidate_ID='" & Txtcid.Text & "' "
            command = New MySqlCommand(query, conn)

            READER4 = command.ExecuteReader
            MessageBox.Show("Data Record Deleted!")

            LoadData()
            ClearInputs()

            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click


        Dim READER4 As MySqlDataReader
        Try
            connectdb()

            Dim query As String = " UPDATE ict222.allcertificate SET  Home_No='" & Txtch.Text & "', Candidate_Name='" & Txtcname.Text & "', Candidate_Nic='" & Txtn.Text & "', Mobile_No='" & Txtcm.Text & "', Certificate_ID='" & Txtcertid.Text & "', Certificate_type= '" & Txtctype.Text & "', certificate_index='" & Txtci.Text & "', Register_Date='" & DTP_regi.Text & "' WHERE Candidate_ID = '" & Txtcid.Text & "' "
            command = New MySqlCommand(query, conn)

            READER4 = command.ExecuteReader
            MessageBox.Show("Data Record Updated!")

            LoadData()
            ClearInputs()

            conn.Close()

        Catch ex As MySqlException
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub All_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The Form ?", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        For Each tbcontrol As Object In Panel1.Controls
            If TypeOf tbcontrol Is TextBox Then
                tbcontrol.Text = ""
            End If
        Next
    End Sub

    'get data to textbox by celclick
    Private Sub DGVALL_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVALL.CellClick

        Dim index As Integer
        index = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DGVALL.Rows(index)

        Txtch.Text = selectedRow.Cells(0).Value.ToString()
        Txtcid.Text = selectedRow.Cells(1).Value.ToString()
        Txtcname.Text = selectedRow.Cells(2).Value.ToString()
        Txtn.Text = selectedRow.Cells(3).Value.ToString()
        ' Txtca.Text = selectedRow.Cells(4).Value.ToString()
        Txtcm.Text = selectedRow.Cells(4).Value.ToString()
        'Txtcage.Text = selectedRow.Cells(6).Value.ToString()
        Txtcertid.Text = selectedRow.Cells(5).Value.ToString()
        Txtctype.Text = selectedRow.Cells(6).Value.ToString()
        Txtci.Text = selectedRow.Cells(7).Value.ToString()
        DTP_regi.Text = selectedRow.Cells(8).Value.ToString()

    End Sub

    'DATE VALIDATION
    Private Sub DTP_regi_ValueChanged(sender As Object, e As EventArgs) Handles DTP_regi.ValueChanged

        Dim selectedDate As DateTime = DTP_regi.Value
        Dim currentDate As DateTime = DateTime.Today

        If selectedDate < currentDate Then
            MessageBox.Show("You cannot select a past date.", "Date Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            DTP_regi.Value = currentDate
        ElseIf selectedDate > currentDate Then
            MessageBox.Show("You cannot select a future date.", "Date Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            DTP_regi.Value = currentDate
        End If

    End Sub
End Class