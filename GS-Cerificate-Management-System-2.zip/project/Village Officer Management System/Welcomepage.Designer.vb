﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Welcomepage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Btnhellouser = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Btnhellouser
        '
        Me.Btnhellouser.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Btnhellouser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Btnhellouser.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnhellouser.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnhellouser.Location = New System.Drawing.Point(768, 542)
        Me.Btnhellouser.Name = "Btnhellouser"
        Me.Btnhellouser.Size = New System.Drawing.Size(148, 89)
        Me.Btnhellouser.TabIndex = 1
        Me.Btnhellouser.Text = "NEXT"
        Me.Btnhellouser.UseVisualStyleBackColor = False
        '
        'Welcomepage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(995, 698)
        Me.Controls.Add(Me.Btnhellouser)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Welcomepage"
        Me.Text = "Welcomepage"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btnhellouser As Button
End Class
