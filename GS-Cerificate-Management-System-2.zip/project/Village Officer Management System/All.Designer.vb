﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class All
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Txtci = New System.Windows.Forms.TextBox()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Btnedit = New System.Windows.Forms.Button()
        Me.Btnback = New System.Windows.Forms.Button()
        Me.DGVALL = New System.Windows.Forms.DataGridView()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btnsearch = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DTP_regi = New System.Windows.Forms.DateTimePicker()
        Me.Cbtype = New System.Windows.Forms.ComboBox()
        Me.Cbid = New System.Windows.Forms.ComboBox()
        Me.Cbsearch = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Txtcid = New System.Windows.Forms.TextBox()
        Me.Txtcname = New System.Windows.Forms.TextBox()
        Me.Txtch = New System.Windows.Forms.TextBox()
        Me.Txtcm = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Txtcertid = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Txtn = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Txtctype = New System.Windows.Forms.TextBox()
        Me.Btnloaddata = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        CType(Me.DGVALL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(45, 65)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Resident ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(485, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(172, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Certificate Type"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(479, 110)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(181, 25)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Certificate Index"
        '
        'Txtci
        '
        Me.Txtci.BackColor = System.Drawing.SystemColors.Window
        Me.Txtci.Location = New System.Drawing.Point(663, 107)
        Me.Txtci.Margin = New System.Windows.Forms.Padding(4)
        Me.Txtci.Multiline = True
        Me.Txtci.Name = "Txtci"
        Me.Txtci.Size = New System.Drawing.Size(307, 36)
        Me.Txtci.TabIndex = 11
        '
        'Btnadd
        '
        Me.Btnadd.BackColor = System.Drawing.Color.Transparent
        Me.Btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnadd.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnadd.ForeColor = System.Drawing.Color.White
        Me.Btnadd.Location = New System.Drawing.Point(406, 298)
        Me.Btnadd.Margin = New System.Windows.Forms.Padding(4)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(301, 56)
        Me.Btnadd.TabIndex = 12
        Me.Btnadd.Text = "ADD RECORD"
        Me.Btnadd.UseVisualStyleBackColor = False
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.Color.SteelBlue
        Me.Btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btndelete.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btndelete.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btndelete.Location = New System.Drawing.Point(1092, 712)
        Me.Btndelete.Margin = New System.Windows.Forms.Padding(4)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(86, 40)
        Me.Btndelete.TabIndex = 13
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'Btnedit
        '
        Me.Btnedit.BackColor = System.Drawing.Color.SteelBlue
        Me.Btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnedit.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnedit.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnedit.Location = New System.Drawing.Point(1089, 772)
        Me.Btnedit.Margin = New System.Windows.Forms.Padding(4)
        Me.Btnedit.Name = "Btnedit"
        Me.Btnedit.Size = New System.Drawing.Size(89, 38)
        Me.Btnedit.TabIndex = 14
        Me.Btnedit.Text = "UPDATE"
        Me.Btnedit.UseVisualStyleBackColor = False
        '
        'Btnback
        '
        Me.Btnback.BackColor = System.Drawing.Color.SteelBlue
        Me.Btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnback.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnback.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnback.Location = New System.Drawing.Point(1089, 588)
        Me.Btnback.Margin = New System.Windows.Forms.Padding(4)
        Me.Btnback.Name = "Btnback"
        Me.Btnback.Size = New System.Drawing.Size(86, 38)
        Me.Btnback.TabIndex = 15
        Me.Btnback.Text = "BACK"
        Me.Btnback.UseVisualStyleBackColor = False
        '
        'DGVALL
        '
        Me.DGVALL.BackgroundColor = System.Drawing.Color.Gray
        Me.DGVALL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVALL.Location = New System.Drawing.Point(8, 610)
        Me.DGVALL.Margin = New System.Windows.Forms.Padding(4)
        Me.DGVALL.Name = "DGVALL"
        Me.DGVALL.RowHeadersWidth = 51
        Me.DGVALL.RowTemplate.Height = 29
        Me.DGVALL.Size = New System.Drawing.Size(1032, 204)
        Me.DGVALL.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(13, 557)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(137, 25)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Search Data"
        '
        'Btnsearch
        '
        Me.Btnsearch.BackColor = System.Drawing.Color.SteelBlue
        Me.Btnsearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnsearch.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnsearch.Location = New System.Drawing.Point(452, 557)
        Me.Btnsearch.Margin = New System.Windows.Forms.Padding(4)
        Me.Btnsearch.Name = "Btnsearch"
        Me.Btnsearch.Size = New System.Drawing.Size(104, 36)
        Me.Btnsearch.TabIndex = 20
        Me.Btnsearch.Text = "SEARCH"
        Me.Btnsearch.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(199, 19)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(470, 38)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Store Issue Certificate Information"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(594, 160)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 25)
        Me.Label7.TabIndex = 35
        Me.Label7.Text = "Date"
        '
        'DTP_regi
        '
        Me.DTP_regi.CustomFormat = "yyyy-MM-dd"
        Me.DTP_regi.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.DTP_regi.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_regi.Location = New System.Drawing.Point(663, 158)
        Me.DTP_regi.Margin = New System.Windows.Forms.Padding(4)
        Me.DTP_regi.Name = "DTP_regi"
        Me.DTP_regi.Size = New System.Drawing.Size(307, 34)
        Me.DTP_regi.TabIndex = 36
        '
        'Cbtype
        '
        Me.Cbtype.BackColor = System.Drawing.SystemColors.Window
        Me.Cbtype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cbtype.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Cbtype.FormattingEnabled = True
        Me.Cbtype.Items.AddRange(New Object() {"income certificate"})
        Me.Cbtype.Location = New System.Drawing.Point(666, 14)
        Me.Cbtype.Name = "Cbtype"
        Me.Cbtype.Size = New System.Drawing.Size(304, 36)
        Me.Cbtype.TabIndex = 37
        '
        'Cbid
        '
        Me.Cbid.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cbid.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Cbid.FormattingEnabled = True
        Me.Cbid.Location = New System.Drawing.Point(189, 16)
        Me.Cbid.Name = "Cbid"
        Me.Cbid.Size = New System.Drawing.Size(263, 36)
        Me.Cbid.TabIndex = 38
        '
        'Cbsearch
        '
        Me.Cbsearch.FormattingEnabled = True
        Me.Cbsearch.Location = New System.Drawing.Point(151, 557)
        Me.Cbsearch.Name = "Cbsearch"
        Me.Cbsearch.Size = New System.Drawing.Size(283, 33)
        Me.Cbsearch.TabIndex = 39
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(44, 20)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(131, 25)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Resident ID"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(102, 236)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(0, 28)
        Me.Label11.TabIndex = 42
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(12, 115)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(164, 25)
        Me.Label12.TabIndex = 43
        Me.Label12.Text = "Resident Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(107, 393)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(0, 25)
        Me.Label14.TabIndex = 45
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.DarkGray
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(72, 19)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(107, 25)
        Me.Label15.TabIndex = 46
        Me.Label15.Text = "Home No"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.DarkGray
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(59, 215)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(116, 25)
        Me.Label16.TabIndex = 47
        Me.Label16.Text = "Mobile No"
        '
        'Txtcid
        '
        Me.Txtcid.BackColor = System.Drawing.SystemColors.Window
        Me.Txtcid.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtcid.Location = New System.Drawing.Point(189, 64)
        Me.Txtcid.Multiline = True
        Me.Txtcid.Name = "Txtcid"
        Me.Txtcid.Size = New System.Drawing.Size(263, 33)
        Me.Txtcid.TabIndex = 49
        '
        'Txtcname
        '
        Me.Txtcname.BackColor = System.Drawing.SystemColors.Window
        Me.Txtcname.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtcname.Location = New System.Drawing.Point(188, 115)
        Me.Txtcname.Multiline = True
        Me.Txtcname.Name = "Txtcname"
        Me.Txtcname.Size = New System.Drawing.Size(263, 28)
        Me.Txtcname.TabIndex = 50
        '
        'Txtch
        '
        Me.Txtch.BackColor = System.Drawing.SystemColors.Window
        Me.Txtch.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtch.Location = New System.Drawing.Point(189, 19)
        Me.Txtch.Multiline = True
        Me.Txtch.Name = "Txtch"
        Me.Txtch.Size = New System.Drawing.Size(263, 27)
        Me.Txtch.TabIndex = 52
        '
        'Txtcm
        '
        Me.Txtcm.BackColor = System.Drawing.SystemColors.Window
        Me.Txtcm.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtcm.Location = New System.Drawing.Point(188, 215)
        Me.Txtcm.Multiline = True
        Me.Txtcm.Name = "Txtcm"
        Me.Txtcm.Size = New System.Drawing.Size(263, 27)
        Me.Txtcm.TabIndex = 53
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(507, 19)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(150, 25)
        Me.Label18.TabIndex = 55
        Me.Label18.Text = "Certificate ID"
        '
        'Txtcertid
        '
        Me.Txtcertid.BackColor = System.Drawing.SystemColors.Window
        Me.Txtcertid.Location = New System.Drawing.Point(663, 16)
        Me.Txtcertid.Name = "Txtcertid"
        Me.Txtcertid.Size = New System.Drawing.Size(304, 31)
        Me.Txtcertid.TabIndex = 56
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(82, 165)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(90, 25)
        Me.Label19.TabIndex = 57
        Me.Label19.Text = "NIC No"
        '
        'Txtn
        '
        Me.Txtn.BackColor = System.Drawing.SystemColors.Window
        Me.Txtn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtn.Location = New System.Drawing.Point(189, 165)
        Me.Txtn.Multiline = True
        Me.Txtn.Name = "Txtn"
        Me.Txtn.Size = New System.Drawing.Size(263, 27)
        Me.Txtn.TabIndex = 58
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(486, 62)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(172, 25)
        Me.Label20.TabIndex = 59
        Me.Label20.Text = "Certificate Type"
        '
        'Txtctype
        '
        Me.Txtctype.BackColor = System.Drawing.SystemColors.Window
        Me.Txtctype.Location = New System.Drawing.Point(663, 59)
        Me.Txtctype.Name = "Txtctype"
        Me.Txtctype.Size = New System.Drawing.Size(307, 31)
        Me.Txtctype.TabIndex = 60
        '
        'Btnloaddata
        '
        Me.Btnloaddata.BackColor = System.Drawing.Color.SteelBlue
        Me.Btnloaddata.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnloaddata.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnloaddata.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btnloaddata.Location = New System.Drawing.Point(1089, 643)
        Me.Btnloaddata.Name = "Btnloaddata"
        Me.Btnloaddata.Size = New System.Drawing.Size(89, 53)
        Me.Btnloaddata.TabIndex = 61
        Me.Btnloaddata.Text = "LOAD DATA"
        Me.Btnloaddata.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_search
        Me.PictureBox1.Location = New System.Drawing.Point(557, 557)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 36)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 62
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_data_load_32
        Me.PictureBox2.Location = New System.Drawing.Point(1050, 643)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(41, 53)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 63
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_back
        Me.PictureBox3.Location = New System.Drawing.Point(1050, 588)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(41, 38)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 64
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_delete1
        Me.PictureBox4.Location = New System.Drawing.Point(1050, 712)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(42, 40)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 65
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_update
        Me.PictureBox5.Location = New System.Drawing.Point(1050, 772)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(42, 38)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 66
        Me.PictureBox5.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkGray
        Me.Panel1.Controls.Add(Me.PictureBox6)
        Me.Panel1.Controls.Add(Me.Txtcname)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Txtcid)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Txtctype)
        Me.Panel1.Controls.Add(Me.Txtn)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Txtch)
        Me.Panel1.Controls.Add(Me.Txtcertid)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Btnadd)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Txtcm)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Txtci)
        Me.Panel1.Controls.Add(Me.DTP_regi)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Location = New System.Drawing.Point(104, 148)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(987, 369)
        Me.Panel1.TabIndex = 67
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_clear_50
        Me.PictureBox6.Location = New System.Drawing.Point(770, 328)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(50, 40)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 70
        Me.PictureBox6.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SteelBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(820, 328)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(166, 40)
        Me.Button1.TabIndex = 69
        Me.Button1.Text = "Clear Field"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightGray
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Cbtype)
        Me.Panel2.Controls.Add(Me.Cbid)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Location = New System.Drawing.Point(104, 87)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(987, 55)
        Me.Panel2.TabIndex = 68
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel3.Controls.Add(Me.PictureBox7)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1213, 81)
        Me.Panel3.TabIndex = 69
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_book_48
        Me.PictureBox7.Location = New System.Drawing.Point(102, 3)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(94, 78)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 34
        Me.PictureBox7.TabStop = False
        '
        'All
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(1213, 849)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Btnloaddata)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Cbsearch)
        Me.Controls.Add(Me.Btnsearch)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.DGVALL)
        Me.Controls.Add(Me.Btnback)
        Me.Controls.Add(Me.Btnedit)
        Me.Controls.Add(Me.Btndelete)
        Me.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "All"
        Me.Text = "All"
        CType(Me.DGVALL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Txtci As TextBox
    Friend WithEvents Btnadd As Button
    Friend WithEvents Btndelete As Button
    Friend WithEvents Btnedit As Button
    Friend WithEvents Btnback As Button
    Friend WithEvents DGVALL As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents Btnsearch As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents DTP_regi As DateTimePicker
    Friend WithEvents Cbtype As ComboBox
    Friend WithEvents Cbid As ComboBox
    Friend WithEvents Cbsearch As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Txtcid As TextBox
    Friend WithEvents Txtcname As TextBox
    Friend WithEvents Txtch As TextBox
    Friend WithEvents Txtcm As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Txtcertid As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Txtn As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Txtctype As TextBox
    Friend WithEvents Btnloaddata As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents PictureBox7 As PictureBox
End Class
