﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Nic_issue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.cb5 = New System.Windows.Forms.ComboBox()
        Me.Txt6 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cb3 = New System.Windows.Forms.ComboBox()
        Me.dtp4 = New System.Windows.Forms.DateTimePicker()
        Me.Txtdn = New System.Windows.Forms.TextBox()
        Me.Txtdsd = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(638, 316)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(0, 20)
        Me.Label21.TabIndex = 6
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.cb5)
        Me.Panel3.Controls.Add(Me.Txt6)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Location = New System.Drawing.Point(12, 261)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(653, 125)
        Me.Panel3.TabIndex = 7
        '
        'cb5
        '
        Me.cb5.FormattingEnabled = True
        Me.cb5.Items.AddRange(New Object() {"Yes", "No"})
        Me.cb5.Location = New System.Drawing.Point(478, 39)
        Me.cb5.Name = "cb5"
        Me.cb5.Size = New System.Drawing.Size(175, 28)
        Me.cb5.TabIndex = 5
        '
        'Txt6
        '
        Me.Txt6.Location = New System.Drawing.Point(178, 89)
        Me.Txt6.Name = "Txt6"
        Me.Txt6.Size = New System.Drawing.Size(475, 27)
        Me.Txt6.TabIndex = 4
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label28.Location = New System.Drawing.Point(10, -8)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(283, 28)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = "Information about Applicant"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(14, 93)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(145, 20)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "His/ Her character:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(14, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(452, 20)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Whether the Applicant has been convicted by a Court of Low"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cb3)
        Me.Panel1.Controls.Add(Me.dtp4)
        Me.Panel1.Controls.Add(Me.Txtdn)
        Me.Panel1.Controls.Add(Me.Txtdsd)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(12, 67)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(653, 158)
        Me.Panel1.TabIndex = 5
        '
        'cb3
        '
        Me.cb3.FormattingEnabled = True
        Me.cb3.Items.AddRange(New Object() {"Yes", "No"})
        Me.cb3.Location = New System.Drawing.Point(463, 86)
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(187, 28)
        Me.cb3.TabIndex = 8
        '
        'dtp4
        '
        Me.dtp4.CustomFormat = "yyyy-MM-dd"
        Me.dtp4.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp4.Location = New System.Drawing.Point(169, 126)
        Me.dtp4.Name = "dtp4"
        Me.dtp4.Size = New System.Drawing.Size(250, 27)
        Me.dtp4.TabIndex = 7
        '
        'Txtdn
        '
        Me.Txtdn.Location = New System.Drawing.Point(332, 49)
        Me.Txtdn.Name = "Txtdn"
        Me.Txtdn.Size = New System.Drawing.Size(321, 27)
        Me.Txtdn.TabIndex = 5
        '
        'Txtdsd
        '
        Me.Txtdsd.Location = New System.Drawing.Point(332, 12)
        Me.Txtdsd.Name = "Txtdsd"
        Me.Txtdsd.Size = New System.Drawing.Size(321, 27)
        Me.Txtdsd.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(10, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(142, 20)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "If So,since when?:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(10, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(447, 20)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Whether Applicant Personally  know to the Grama Niladhari:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(10, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(294, 20)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Grama Niladhari Division And Number:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(14, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(312, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "District And Divisional Secretary Division:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(358, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(748, 31)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Certificate on residence and charactor issued by the Grama Niladhari"
        '
        'Nic_issue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1407, 770)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Nic_issue"
        Me.Text = "Nic_issue"
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label21 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents cb5 As ComboBox
    Friend WithEvents Txt6 As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cb3 As ComboBox
    Friend WithEvents dtp4 As DateTimePicker
    Friend WithEvents Txtdn As TextBox
    Friend WithEvents Txtdsd As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
