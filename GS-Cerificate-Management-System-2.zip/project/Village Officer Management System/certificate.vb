﻿Imports MySql.Data.common
Imports MySql.Data.MySqlClient


Public Class certificate
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222")
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        If (Txtcid.Text = "") Then
            Txtcid.BackColor = Color.LightPink
            MessageBox.Show("Please enter Certificate ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txtcid.Focus()
            Return

        End If

        If (Txtct.Text = "") Then
            Txtct.BackColor = Color.LightPink
            MessageBox.Show("Please enter Resident Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Txtct.Focus()
            Return

        End If


        Try
            connectdb()

            Dim quary As String = "INSERT INTO `certificate` ( `Certificate_ID` , `Certificate_Type`) VALUES (@Certificate_ID, @Certificate_Type)"


            command = New MySqlCommand(quary, conn)

            command.Parameters.AddWithValue("@Certificate_ID", Txtcid.Text)
            command.Parameters.AddWithValue("@Certificate_Type", Txtct.Text)


            Dim result As Integer = command.ExecuteNonQuery()
            If result > 0 Then
                MsgBox("Certificate Registered successfully")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error Adding Certificate")


            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try
    End Sub

    Private Sub LoadData()
        Try
            connectdb()
            'connectdb()
            Dim query As String = "SELECT * FROM certificate"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            DGVCC.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

    End Sub

    Private Sub ClearInputs()
        ' connectdb()
        Txtcid.Clear()
        Txtct.Clear()


    End Sub

    Private Sub certificate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadData()
    End Sub

    Private Sub DGVCC_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVCC.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = Me.DGVCC.Rows(e.RowIndex)
            Txtcid.Text = row.Cells("Certificate_ID").Value.ToString()
            Txtct.Text = row.Cells("Certificate_Type").Value.ToString()


        End If
    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click
        Try
            connectdb()

            Dim updateQuery As String = "UPDATE certificate SET Certificate_Type WHERE Certificate_ID = @Certificate_ID"
            command = New MySqlCommand(updateQuery, conn)

            command.Parameters.AddWithValue("@Certificate_Type", Txtct.Text)
            command.Parameters.AddWithValue("@Certificate_ID", Txtcid.Text)

            Dim result As Integer = command.ExecuteNonQuery()

            If result > 0 Then
                MsgBox("Certificate name updated successfully!")
                ClearInputs()
                LoadData()
            Else
                MsgBox("Error updating Certificate Type !")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        LoadData()
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click


        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this Certificate?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Try
                connectdb()


                Dim deleteQuery As String = "DELETE FROM certificate WHERE Certificate_ID = @Certificate_ID"
                command = New MySqlCommand(deleteQuery, conn)

                command.Parameters.AddWithValue("@Certificate_ID", Txtcid.Text)
                command.Parameters.AddWithValue("@Certificate_Type", Txtct.Text)



                Dim deleteResult As Integer = command.ExecuteNonQuery()

                If deleteResult > 0 Then
                    MsgBox("Certificate deleted successfully!")
                    ClearInputs()
                    LoadData()
                Else
                    MsgBox("Error deleting Certificate !")
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                conn.Close()
            End Try

        End If
        conn.Close()
        LoadData()
    End Sub

    Private Sub Btnback_Click(sender As Object, e As EventArgs) Handles Btnback.Click
        Dim c As New Form3()
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Btnloaddata_Click(sender As Object, e As EventArgs) Handles Btnloaddata.Click

        Dim SDA2 As New MySqlDataAdapter
        Dim dbdataset2 As New DataTable
        Dim bsource2 As New BindingSource
        Try
            connectdb()
            Dim query As String = "select * from ict222.Certificate"
            command = New MySqlCommand(query, conn)
            SDA2.SelectCommand = command
            SDA2.Fill(dbdataset2)
            bsource2.DataSource = dbdataset2
            DGVCC.DataSource = bsource2
            SDA2.Update(dbdataset2)
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub certificate_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The App", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub Txtcid_TextChanged(sender As Object, e As EventArgs) Handles Txtcid.TextChanged
        Txtcid.BackColor = Color.Silver
    End Sub

    Private Sub Txtct_TextChanged(sender As Object, e As EventArgs) Handles Txtct.TextChanged
        Txtct.BackColor = Color.Silver
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        For Each tbcontrol As Object In Panel1.Controls
            If TypeOf tbcontrol Is TextBox Then
                tbcontrol.Text = ""
            End If
        Next
    End Sub

    'get data to textbox by celclick
    Private Sub DGVCC_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVCC.CellClick

        Dim index As Integer
        index = e.RowIndex
        Dim selectedRow As DataGridViewRow
        selectedRow = DGVCC.Rows(index)

        Txtcid.Text = selectedRow.Cells(0).Value.ToString()
        Txtct.Text = selectedRow.Cells(1).Value.ToString()

    End Sub
End Class