﻿Imports Google.Protobuf.WellKnownTypes
Imports MySql.Data.MySqlClient

Module scholarshipModule
    Public command As New MySqlCommand

    Public Function Getscholarshipclass() As List(Of Scholarshipclass)
        Dim scholarship As New List(Of Scholarshipclass)

        Dim q = "SELECT * FROM scholarship"
        Dim command As New MySqlCommand(q, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then
            While result.Read
                scholarship.Add(New Scholarshipclass With {.scholarship_id = result("scholarship_id"), .scholarship_name = result("scholarship_name")})
            End While

        End If
        result.Close()
        Return scholarship
    End Function

    Public Function isemptystr(ByVal input As String) As Boolean
        'conn.Open()
        input = Trim(input)

        If String.IsNullOrEmpty(input) Then
            Return True
        End If
        Return False
    End Function


End Module

Module ClientFormmodule
    Public command As New MySqlCommand
    Public Function getClient_form() As List(Of Client_form)
        Dim C As New List(Of Client_form)
        'conn.Open()
        Dim newc = "SELECT * FROM `clientform2`"
        Dim command As New MySqlCommand(newc, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then


            While result.Read
                C.Add(New Client_form With {.mrcb_no = result("mrcb+no"), .Home_No = result("Home_No"), .Candidate_ID = result("Candidate_ID"), .Candidate_Name = result("Candidate_Name"), .Candidate_Nic = result("Candidate_Nic"), .Sex = result("Sex"), .Mobile_No = result("Mobile_No"), .Age = result("Age")})
            End While

        End If
        result.Close()
        Return C
    End Function

End Module


Module Certificatemodule
    Public command As New MySqlCommand
    Public Function getCertificate_class() As List(Of Certificate_class)
        Dim certi2 As New List(Of Certificate_class)

        ' conn.Open()
        Dim i = "SELECT * FROM certificate"
        Dim command As New MySqlCommand(i, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then
            While result.Read
                certi2.Add(New Certificate_class With {.Certificate_id = result("Certificate_ID"), .Certificate_Type = result("Certificate_Type")})
            End While

        End If
        result.Close()
        Return certi2
    End Function
End Module
Module license1Module
    Public command As New MySqlCommand
    Public Function Getlicense_class() As List(Of license_class)
        Dim license As New List(Of license_class)

        ' conn.Open()
        Dim q = "SELECT * FROM license"
        Dim command As New MySqlCommand(q, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then
            While result.Read
                license.Add(New license_class With {.License_ID = result("License_ID"), .License_Type = result("License_Type")})
            End While

        End If
        result.Close()
        Return license

    End Function

End Module




Module All_module
    Public command As New MySqlCommand
    Public Function getall_class() As List(Of all_class)
        Dim C As New List(Of all_class)
        'conn.Open()
        Dim newc = "SELECT * FROM `allcertificate` "
        Dim command As New MySqlCommand(newc, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then


            While result.Read
                C.Add(New all_class With {.Candidate_id = result("Candidate id"), .Candidate_Name = result("Candidate_Name"), .Candidate_Nic = result("Candidate_Nic"), .Home_No = result("Home_No"), .Address = result("Address"), .Mobile_No = result("Mobile_No"), .Age = result("Age"), .Certificate_id = result("Certificate_id"), .Certificate_type = result("Certificate_Type"), .Certificate_index = result("Certificate_index"), .Register_Date = result("Register_Date")})
            End While


        End If
        result.Close()
        Return C
    End Function

End Module

Module Users_module
    Public cmd As New MySqlCommand
    Public Function getusers_class() As List(Of users_class)
        Dim C As New List(Of users_class)
        'conn.Open()
        Dim newc = "SELECT * FROM `users` "
        Dim command As New MySqlCommand(newc, conn)
        Dim result = cmd.ExecuteReader
        If result.HasRows Then


            While result.Read
                C.Add(New users_class With {.First_Name = result("First_Name"), .Last_Name = result("Last_Name"), .Telephone = result("Telephone"), .Nic = result("Nic"), .Address = result("Address")})
            End While

        End If
        result.Close()
        Return C
    End Function

End Module

Module PaymentModule
    Public command As New MySqlCommand

    Public Function getpayment() As List(Of payment)
        Dim C As New List(Of payment)
        'conn.Open()
        Dim newc = "SELECT * FROM `nic_payment`"
        Dim command As New MySqlCommand(newc, conn)
        Dim result = command.ExecuteReader
        If result.HasRows Then


            While result.Read
                C.Add(New payment With {.Resident_id = result("Resident_id"), .Resident_name = result("Resident_name"), .Home_no = result("Home_no"), .Mobile_no = result("Mobile_no"), .Address = result("Address"), .Nic_no = result("Nic_no"), .Age = result("Age"), .Payment_id = result("Payment_id"), .Reason = result("Reason"), .Fees = result("Fees"), .pay_Date = result("Date")})
            End While

        End If
        result.Close()
        Return C
    End Function


End Module
