﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Txtun = New System.Windows.Forms.TextBox()
        Me.Cbrememberme = New System.Windows.Forms.CheckBox()
        Me.Btnlogin = New System.Windows.Forms.Button()
        Me.Txtpw = New System.Windows.Forms.TextBox()
        Me.Lbluserlogin = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Btnbackarrow = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Pbcloseform = New System.Windows.Forms.PictureBox()
        Me.Pbminimize = New System.Windows.Forms.PictureBox()
        Me.Pbmaximize = New System.Windows.Forms.PictureBox()
        Me.Lblcreataccount = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.Pbcloseform, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbminimize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pbmaximize, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Txtun
        '
        Me.Txtun.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Txtun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtun.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Txtun.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtun.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txtun.Location = New System.Drawing.Point(673, 325)
        Me.Txtun.Multiline = True
        Me.Txtun.Name = "Txtun"
        Me.Txtun.Size = New System.Drawing.Size(317, 46)
        Me.Txtun.TabIndex = 1
        Me.Txtun.UseSystemPasswordChar = True
        '
        'Cbrememberme
        '
        Me.Cbrememberme.AutoSize = True
        Me.Cbrememberme.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Cbrememberme.ForeColor = System.Drawing.Color.Maroon
        Me.Cbrememberme.Location = New System.Drawing.Point(632, 494)
        Me.Cbrememberme.Name = "Cbrememberme"
        Me.Cbrememberme.Size = New System.Drawing.Size(192, 29)
        Me.Cbrememberme.TabIndex = 3
        Me.Cbrememberme.Text = "Show Password"
        Me.Cbrememberme.UseVisualStyleBackColor = True
        '
        'Btnlogin
        '
        Me.Btnlogin.BackColor = System.Drawing.Color.Transparent
        Me.Btnlogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btnlogin.Font = New System.Drawing.Font("Segoe UI Historic", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnlogin.Location = New System.Drawing.Point(753, 556)
        Me.Btnlogin.Name = "Btnlogin"
        Me.Btnlogin.Size = New System.Drawing.Size(187, 65)
        Me.Btnlogin.TabIndex = 4
        Me.Btnlogin.Text = "LOGIN"
        Me.Btnlogin.UseVisualStyleBackColor = False
        '
        'Txtpw
        '
        Me.Txtpw.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Txtpw.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txtpw.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Txtpw.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txtpw.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Txtpw.Location = New System.Drawing.Point(673, 428)
        Me.Txtpw.Multiline = True
        Me.Txtpw.Name = "Txtpw"
        Me.Txtpw.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txtpw.Size = New System.Drawing.Size(317, 48)
        Me.Txtpw.TabIndex = 5
        '
        'Lbluserlogin
        '
        Me.Lbluserlogin.AutoSize = True
        Me.Lbluserlogin.Font = New System.Drawing.Font("Times New Roman", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbluserlogin.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbluserlogin.Location = New System.Drawing.Point(700, 205)
        Me.Lbluserlogin.Name = "Lbluserlogin"
        Me.Lbluserlogin.Size = New System.Drawing.Size(250, 42)
        Me.Lbluserlogin.TabIndex = 6
        Me.Lbluserlogin.Text = "USER LOGIN"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_645
        Me.PictureBox2.Location = New System.Drawing.Point(763, 82)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(109, 104)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_back_641
        Me.PictureBox1.Location = New System.Drawing.Point(1011, 676)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(46, 43)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 9
        Me.PictureBox1.TabStop = False
        '
        'Btnbackarrow
        '
        Me.Btnbackarrow.BackColor = System.Drawing.Color.Transparent
        Me.Btnbackarrow.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnbackarrow.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btnbackarrow.Location = New System.Drawing.Point(1057, 676)
        Me.Btnbackarrow.Name = "Btnbackarrow"
        Me.Btnbackarrow.Size = New System.Drawing.Size(73, 43)
        Me.Btnbackarrow.TabIndex = 10
        Me.Btnbackarrow.Text = "Back"
        Me.Btnbackarrow.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(621, 280)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 32)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "User Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(622, 385)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 32)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Password"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_login_48
        Me.PictureBox3.Location = New System.Drawing.Point(679, 556)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(73, 65)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 15
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_user_321
        Me.PictureBox4.Location = New System.Drawing.Point(632, 325)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(41, 46)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 16
        Me.PictureBox4.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_password_50
        Me.PictureBox5.Location = New System.Drawing.Point(632, 428)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(41, 46)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 17
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Village_Officer_Management_System.My.Resources.Resources._340366_PAPUKD_9861
        Me.PictureBox6.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(501, 731)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 18
        Me.PictureBox6.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Panel1.Controls.Add(Me.Pbcloseform)
        Me.Panel1.Controls.Add(Me.Pbminimize)
        Me.Panel1.Controls.Add(Me.Pbmaximize)
        Me.Panel1.Location = New System.Drawing.Point(502, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(637, 52)
        Me.Panel1.TabIndex = 19
        '
        'Pbcloseform
        '
        Me.Pbcloseform.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_close5
        Me.Pbcloseform.Location = New System.Drawing.Point(582, 3)
        Me.Pbcloseform.Name = "Pbcloseform"
        Me.Pbcloseform.Size = New System.Drawing.Size(50, 44)
        Me.Pbcloseform.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbcloseform.TabIndex = 2
        Me.Pbcloseform.TabStop = False
        '
        'Pbminimize
        '
        Me.Pbminimize.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_minimize_505
        Me.Pbminimize.Location = New System.Drawing.Point(470, 3)
        Me.Pbminimize.Name = "Pbminimize"
        Me.Pbminimize.Size = New System.Drawing.Size(51, 44)
        Me.Pbminimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbminimize.TabIndex = 1
        Me.Pbminimize.TabStop = False
        '
        'Pbmaximize
        '
        Me.Pbmaximize.Image = Global.Village_Officer_Management_System.My.Resources.Resources.icons8_maximize_505
        Me.Pbmaximize.Location = New System.Drawing.Point(526, 3)
        Me.Pbmaximize.Name = "Pbmaximize"
        Me.Pbmaximize.Size = New System.Drawing.Size(51, 44)
        Me.Pbmaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pbmaximize.TabIndex = 0
        Me.Pbmaximize.TabStop = False
        '
        'Lblcreataccount
        '
        Me.Lblcreataccount.AutoSize = True
        Me.Lblcreataccount.BackColor = System.Drawing.Color.Transparent
        Me.Lblcreataccount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Lblcreataccount.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Lblcreataccount.ForeColor = System.Drawing.Color.Navy
        Me.Lblcreataccount.Location = New System.Drawing.Point(651, 641)
        Me.Lblcreataccount.Name = "Lblcreataccount"
        Me.Lblcreataccount.Size = New System.Drawing.Size(347, 20)
        Me.Lblcreataccount.TabIndex = 20
        Me.Lblcreataccount.Text = "Doesn't Have An Account? Create An Account"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Panel2.Location = New System.Drawing.Point(1, 676)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(501, 56)
        Me.Panel2.TabIndex = 21
        '
        'Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.ClientSize = New System.Drawing.Size(1139, 731)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Lblcreataccount)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Btnbackarrow)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Lbluserlogin)
        Me.Controls.Add(Me.Txtpw)
        Me.Controls.Add(Me.Btnlogin)
        Me.Controls.Add(Me.Cbrememberme)
        Me.Controls.Add(Me.Txtun)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Login"
        Me.Text = "Login"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.Pbcloseform, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbminimize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pbmaximize, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Txtun As TextBox
    Friend WithEvents Cbrememberme As CheckBox
    Friend WithEvents Btnlogin As Button
    Friend WithEvents Txtpw As TextBox
    Friend WithEvents Lbluserlogin As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Btnbackarrow As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Pbcloseform As PictureBox
    Friend WithEvents Pbminimize As PictureBox
    Friend WithEvents Pbmaximize As PictureBox
    Friend WithEvents Lblcreataccount As Label
    Friend WithEvents Panel2 As Panel
End Class
