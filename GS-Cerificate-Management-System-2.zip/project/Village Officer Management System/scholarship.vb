﻿Imports System.CodeDom
Imports System.Data.Common
Imports System.Diagnostics.CodeAnalysis
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Common
Imports Org.BouncyCastle.Asn1.Ocsp

Imports Mysqlx.XDevAPI
Imports MySql.Data.common
Imports System.Net.Mime.MediaTypeNames

Public Class scholarship
    Dim da As New MySqlDataAdapter
    Dim dt As New DataTable
    Public command As New MySqlCommand
    Public cmd As New MySqlCommand
    Public refreshsql As MySqlCommand
    Public connectdatabase As New MySqlConnection("host= localhost; user= root; password= ; database= ict222;")

    Private Sub Btnadd_Click(sender As Object, e As EventArgs) Handles Btnadd.Click

        Dim scholarship_id As Integer
        Dim scholarship_name As String

        scholarship_id = Txtsid.Text
        scholarship_name = Txtsname.Text
        'candidate_id = Cbid.Text
        'candi_name = Txtscname.s
        'year = Cbyear.Text


        Try
            connectdb()
            Dim quary As String = "INSERT INTO `scholarship` ( `scholarship_id`, `scholarship_name`) VAlUES (@scholarship_id, @scholarship_name)"


            command = New MySqlCommand(quary, conn)

            command.Parameters.AddWithValue("@scholarship_id", Txtsid.Text)
            command.Parameters.AddWithValue("@scholarship_name", Txtsname.Text)
            'command.Parameters.AddWithValue("@candidate_id", Cbid.Text)
            'command.Parameters.AddWithValue("@candidate_name", candi_name)
            'command.Parameters.AddWithValue("@year", Cbyear.Text)


            Dim result As Integer = command.ExecuteNonQuery()
            If result > 0 Then
                MsgBox("Scholarship Registered successfully")
                ClearInput()
                LoadData()
            Else
                MsgBox("Error Adding Scholarship Registration")


            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()

        End Try

    End Sub
    Private Sub LoadData()
        Try
            connectdb()
            Dim query As String = "SELECT * FROM scholarship"
            cmd = New MySqlCommand(query, conn)
            da.SelectCommand = cmd
            dt.Clear()
            da.Fill(dt)
            DGVs.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub ClearInput()

        Txtsid.Clear()
        Txtsname.Clear()
        ' Cbid.SelectedIndex = -1
        'Cbyear.SelectedIndex = -1
    End Sub



    Private Sub scholarship_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadData()

    End Sub

    Private Sub filter()
        If Txts_search.Text = "" Then
            MsgBox("enter Scholarship_ID")
        Else
            Dim connectionstring As String = "server=127.0.0.1;user=root;database=ict222;"
            Using db As New MySqlConnection(connectionstring)
                Try
                    connectdb()
                    Dim query As String = "SELECT * FROM scholarship WHERE scholarship_ID like @scholarship_ID"
                    Using adapter As New MySqlDataAdapter(query, conn)
                        adapter.SelectCommand.Parameters.AddWithValue("@scholarship_id", "%" & Txts_search.Text & "%")

                        Dim ds As New DataSet()
                        adapter.Fill(ds)
                        DGVs.DataSource = ds.Tables(0)
                    End Using
                Catch ex As Exception
                    MsgBox("error connecting to the database: " & ex.Message)

                Finally
                    conn.Close()
                End Try


            End Using
        End If
        conn.Close()
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles Btndelete.Click

        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this scholarship details ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Try
                connectdb()

                Dim deleteQuery As String = " DELETE FROM scholarship WHERE scholarship_ID=@scholarship_ID "
                command = New MySqlCommand(deleteQuery, conn)

                command.Parameters.AddWithValue("@scholarship_id", Txtsid.Text)
                command.Parameters.AddWithValue("@scholarship_name", Txtsname.Text)
                'command.Parameters.AddWithValue("@candidate_id", Cbid.Text)
                'command.Parameters.AddWithValue("@Year", Cbyear)

                Dim deleteResult As Integer = command.ExecuteNonQuery()

                If deleteResult > 0 Then
                    MsgBox("Scholarship details deleted successfully!")
                    ClearInput()
                    LoadData()
                Else
                    MsgBox("Error deleting scholarship details")
                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                conn.Close()
            End Try
        End If
        conn.Close()
        LoadData()


    End Sub

    Private Sub Btnedit_Click(sender As Object, e As EventArgs) Handles Btnedit.Click

        Try
            connectdb()

            Dim updateQuery As String = "UPDATE scholarship SET scholarship_name=@scholarship_name WHERE scholarship_id=@scholarship_id"
            command = New MySqlCommand(updateQuery, conn)

            command.Parameters.AddWithValue("@scholarship_name", Txtsname.Text)
            ' command.Parameters.AddWithValue("@candidate_id", Cbid.Text)
            'command.Parameters.AddWithValue("@year", Cbyear.Text)
            command.Parameters.AddWithValue("@scholarship_id", Txtsid.Text)


            Dim result As Integer = command.ExecuteNonQuery()

            If result > 0 Then
                MsgBox("Scholarship updated successfully!")
                ClearInput()
                LoadData()
            Else
                MsgBox("Error updating scholarship")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try

        LoadData()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim other_form As New Userselectionform()

        other_form.Show()

        Me.Hide()

    End Sub

    Private Sub Btnssearch_Click(sender As Object, e As EventArgs) Handles Btnssearch.Click
        filter()
    End Sub

    Private Sub DGVs_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVs.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DGVs.Rows(e.RowIndex)
            Txtsid.Text = row.Cells("scholarship_id").Value.ToString()
            Txtsname.Text = row.Cells("scholarship_name").Value.ToString()
            ' Cbid.Text = row.Cells("candidate_id").Value.ToString()
            'Cbyear.Text = row.Cells("year").Value.ToString()


        End If
    End Sub
End Class