﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class certificate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txtcid = New System.Windows.Forms.TextBox()
        Me.Txtct = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Btndelete = New System.Windows.Forms.Button()
        Me.Btnedit = New System.Windows.Forms.Button()
        Me.Btnback = New System.Windows.Forms.Button()
        Me.DGVCC = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Btnloaddata = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        CType(Me.DGVCC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(80, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(150, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Certificate ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(80, 211)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(172, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Certificate Type"
        '
        'Txtcid
        '
        Me.Txtcid.BackColor = System.Drawing.SystemColors.Window
        Me.Txtcid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txtcid.Location = New System.Drawing.Point(38, 151)
        Me.Txtcid.Multiline = True
        Me.Txtcid.Name = "Txtcid"
        Me.Txtcid.Size = New System.Drawing.Size(264, 41)
        Me.Txtcid.TabIndex = 3
        '
        'Txtct
        '
        Me.Txtct.BackColor = System.Drawing.SystemColors.Window
        Me.Txtct.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txtct.Location = New System.Drawing.Point(38, 248)
        Me.Txtct.Multiline = True
        Me.Txtct.Name = "Txtct"
        Me.Txtct.Size = New System.Drawing.Size(264, 41)
        Me.Txtct.TabIndex = 4
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SteelBlue
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(80, 329)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(166, 45)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "ADD DATA"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Btndelete
        '
        Me.Btndelete.BackColor = System.Drawing.Color.Transparent
        Me.Btndelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btndelete.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btndelete.ForeColor = System.Drawing.Color.Black
        Me.Btndelete.Location = New System.Drawing.Point(92, 12)
        Me.Btndelete.Name = "Btndelete"
        Me.Btndelete.Size = New System.Drawing.Size(101, 37)
        Me.Btndelete.TabIndex = 6
        Me.Btndelete.Text = "DELETE"
        Me.Btndelete.UseVisualStyleBackColor = False
        '
        'Btnedit
        '
        Me.Btnedit.BackColor = System.Drawing.Color.Transparent
        Me.Btnedit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnedit.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnedit.ForeColor = System.Drawing.Color.Black
        Me.Btnedit.Location = New System.Drawing.Point(216, 12)
        Me.Btnedit.Name = "Btnedit"
        Me.Btnedit.Size = New System.Drawing.Size(80, 37)
        Me.Btnedit.TabIndex = 7
        Me.Btnedit.Text = "EDIT"
        Me.Btnedit.UseVisualStyleBackColor = False
        '
        'Btnback
        '
        Me.Btnback.BackColor = System.Drawing.Color.Transparent
        Me.Btnback.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnback.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnback.ForeColor = System.Drawing.Color.Black
        Me.Btnback.Location = New System.Drawing.Point(478, 12)
        Me.Btnback.Name = "Btnback"
        Me.Btnback.Size = New System.Drawing.Size(85, 37)
        Me.Btnback.TabIndex = 8
        Me.Btnback.Text = "BACK"
        Me.Btnback.UseVisualStyleBackColor = False
        '
        'DGVCC
        '
        Me.DGVCC.BackgroundColor = System.Drawing.Color.Gray
        Me.DGVCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGVCC.Location = New System.Drawing.Point(376, 33)
        Me.DGVCC.Name = "DGVCC"
        Me.DGVCC.RowHeadersWidth = 51
        Me.DGVCC.RowTemplate.Height = 29
        Me.DGVCC.Size = New System.Drawing.Size(586, 352)
        Me.DGVCC.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(21, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(290, 32)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Certificate Information"
        '
        'Btnloaddata
        '
        Me.Btnloaddata.BackColor = System.Drawing.Color.Transparent
        Me.Btnloaddata.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btnloaddata.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btnloaddata.ForeColor = System.Drawing.Color.Black
        Me.Btnloaddata.Location = New System.Drawing.Point(319, 12)
        Me.Btnloaddata.Name = "Btnloaddata"
        Me.Btnloaddata.Size = New System.Drawing.Size(138, 37)
        Me.Btnloaddata.TabIndex = 12
        Me.Btnloaddata.Text = "LOAD DATA"
        Me.Btnloaddata.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DarkGray
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Txtcid)
        Me.Panel1.Controls.Add(Me.Txtct)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(330, 470)
        Me.Panel1.TabIndex = 13
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button2.ForeColor = System.Drawing.Color.Black
        Me.Button2.Location = New System.Drawing.Point(21, 419)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(281, 39)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "Clear Field"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.SlateGray
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(330, 56)
        Me.Panel2.TabIndex = 13
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.CadetBlue
        Me.Panel4.Controls.Add(Me.Btnback)
        Me.Panel4.Controls.Add(Me.Btnloaddata)
        Me.Panel4.Controls.Add(Me.Btnedit)
        Me.Panel4.Controls.Add(Me.Btndelete)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(330, 409)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(674, 61)
        Me.Panel4.TabIndex = 15
        '
        'certificate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.CadetBlue
        Me.ClientSize = New System.Drawing.Size(1004, 470)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DGVCC)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "certificate"
        Me.Text = "certificate"
        CType(Me.DGVCC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Txtcid As TextBox
    Friend WithEvents Txtct As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Btndelete As Button
    Friend WithEvents Btnedit As Button
    Friend WithEvents Btnback As Button
    Friend WithEvents DGVCC As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents Btnloaddata As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button2 As Button
End Class
