﻿Imports System.Security.Cryptography.Pkcs
Imports Microsoft.VisualBasic.ApplicationServices
Imports MySql.Data.MySqlClient

Public Class Signin
    Public command As MySqlCommand
    Dim db_conn As New MySqlConnection("host = localhost; user=root; password= ; database= ict222")
    Dim cmd As New MySqlCommand
    Dim dt As New DataTable
    Dim da As New MySqlDataAdapter
    Dim dr As MySqlDataReader


    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub Btnsignin_Click(sender As Object, e As EventArgs) Handles Btnsignin.Click


        If String.IsNullOrEmpty(Txtfname.Text) OrElse
       String.IsNullOrEmpty(Txtlname.Text) OrElse
       String.IsNullOrEmpty(Txtaddress.Text) Then
            MessageBox.Show("Please fill in all required fields.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Txtname.Text = ""
        connectdb()

        Dim cmd As New MySqlCommand(" SELECT First_Name FROM users WHERE Nic=@Nic ", conn)


        cmd.Parameters.AddWithValue("@Nic", Txtnic.Text)
        Dim reader As MySqlDataReader

        reader = cmd.ExecuteReader

        If reader.Read Then
            Txtname.Text = reader("First_Name")
        End If
        cmd.Parameters.Clear()

        conn.Close()

        If String.IsNullOrEmpty(Txtname.Text) Then


            Dim fName, lName, add, nic As String

            Dim tel As String
            Dim res As Boolean


            fName = Txtfname.Text
            lName = Txtlname.Text
            tel = Txttp.Text
            nic = Txtnic.Text
            add = Txtaddress.Text



            'If txtnic.Text.Length = 10 OrElse txtnic.Text.Length = 12 Then

            '    MessageBox.Show("Your NIC Is In correct formmat", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'Else

            '    MessageBox.Show("ID Is Not valid", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'End If

            If Not (Txtnic.Text.Length = 10 OrElse Txtnic.Text.Length = 12) Then
                MessageBox.Show("Invalid NIC format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If


            'If txttp.Text.Length = 10 Then

            '    MessageBox.Show("Your telephone number Is In correct format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'Else

            '    MessageBox.Show("Telephone number Is Not valid", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'End If

            If Not (Txttp.Text.Length = 10) Then
                MessageBox.Show("Invalid telephone number format", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If


            If Txtnic.Text.Length = 10 OrElse Txtnic.Text.Length = 12 And Txttp.Text.Length = 10 Then
                Dim signin As New Form1()
                Form1.Show()
                Me.Hide()
            End If



            Try
                connectdb()

                Dim quary As String

                quary = "INSERT INTO `users` (`First_Name`,`Last_Name`,`Telephone`, `Nic`,`Address`) VALUES (@First_Name, @Last_Name, @Telephone, @Nic, @Address)"

                cmd = New MySqlCommand(quary, conn)

                cmd.Parameters.AddWithValue("@First_Name", fName)
                cmd.Parameters.AddWithValue("@Last_Name", lName)
                cmd.Parameters.AddWithValue("@Telephone", tel)
                cmd.Parameters.AddWithValue("@Nic", nic)
                cmd.Parameters.AddWithValue("@Address", add)

                res = cmd.ExecuteNonQuery()

                If res = True And Txtnic.Text.Length = 10 OrElse Txtnic.Text.Length = 12 Then
                    MsgBox("You have registered successfully!")
                    cmd.Parameters.Clear()
                Else
                    MsgBox("Error")
                End If

            Catch ex As Exception

                MsgBox(ex.Message)
            Finally
                conn.Close()

            End Try

            ' Dim sihnin_next As New chooses()
            ' chooses.Show()
            ' Me.Hide()

            Txtfname.Text = ""
            Txtaddress.Text = ""
            Txtlname.Text = ""
            Txtnic.Text = ""
            Txttp.Text = ""
            Txtname.Text = ""
        Else
            MessageBox.Show("Allready signup ")
        End If



    End Sub


    Private Sub Btncancel_Click(sender As Object, e As EventArgs) Handles Btncancel.Click

        Dim result As DialogResult = MessageBox.Show("Aye you sure you want to cancel?", "Confermation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If result = DialogResult.Yes Then
            Dim signin_next As New Form1()
            Form1.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub Btnclear_Click(sender As Object, e As EventArgs) Handles Btnclear.Click
        Txtfname.Text = ""
        Txtaddress.Text = ""
        Txtlname.Text = ""
        Txtnic.Text = ""
        Txttp.Text = ""
        Txtname.Text = ""
    End Sub

    Private Sub Txtaddress_TextChanged(sender As Object, e As EventArgs) Handles Txtaddress.TextChanged

    End Sub

    Private Sub Txtname_TextChanged(sender As Object, e As EventArgs) Handles Txtname.TextChanged

    End Sub

    Private Sub Signin_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The App", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Pb5_Click(sender As Object, e As EventArgs) Handles Pb5.Click

        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If
    End Sub

    Private Sub Pb4_Click(sender As Object, e As EventArgs) Handles Pb4.Click

        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Pb3_Click(sender As Object, e As EventArgs) Handles Pb3.Click

        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Btnsignexit_Click(sender As Object, e As EventArgs) Handles Btnsignexit.Click
        Dim log_in As New Signin1()
        Signin1.Show()
        Me.Hide()
    End Sub
End Class