﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Status
Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Asn1.Ocsp
Imports Org.BouncyCastle.Crypto.Tls

Public Class Form3
    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Btn_Home.Click
        panelStatus.Height = Btn_Home.Height
        panelStatus.Top = Btn_Home.Top

        With Form1
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(Form1)
            .BringToFront()
            .Show()

        End With


    End Sub

    Private Sub Btn_resident_Click(sender As Object, e As EventArgs) Handles Btn_resident.Click
        panelStatus.Height = Btn_resident.Height
        panelStatus.Top = Btn_resident.Top

        With ClientForm
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(ClientForm)
            .BringToFront()
            .Show()

        End With
    End Sub

    Private Sub Btn_certificate_Click(sender As Object, e As EventArgs) Handles Btn_certificate.Click
        panelStatus.Height = Btn_certificate.Height
        panelStatus.Top = Btn_certificate.Top

        With certificate
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(certificate)
            .BringToFront()
            .Show()
        End With
    End Sub

    Private Sub Btn_payment_Click(sender As Object, e As EventArgs) Handles Btn_payment.Click
        panelStatus.Height = Btn_payment.Height
        panelStatus.Top = Btn_payment.Top

        With Nic_Payment
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(Nic_Payment)
            .BringToFront()
            .Show()
        End With
    End Sub

    Private Sub Btn_issue_Click(sender As Object, e As EventArgs) Handles Btn_issue.Click
        panelStatus.Height = Btn_issue.Height
        panelStatus.Top = Btn_issue.Top

        With All
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(All)
            .BringToFront()
            .Show()
        End With
    End Sub

    Private Sub Btn_about_Click(sender As Object, e As EventArgs) Handles Btn_about.Click
        panelStatus.Height = Btn_about.Height
        panelStatus.Top = Btn_about.Top

        With Aboutus
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(Aboutus)
            .BringToFront()
            .Show()
        End With
    End Sub

    Private Sub Form3_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim dialog As DialogResult
        dialog = MessageBox.Show(" Do You Really Want To Close The Form", "Exit", MessageBoxButtons.YesNo)
        If dialog = DialogResult.No Then
            e.Cancel = True

        Else
            Application.ExitThread()

        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Btn_logout.Click
        panelStatus.Height = Btn_logout.Height
        panelStatus.Top = Btn_logout.Top


        Dim c As New logout()
        logout.Show()
        Me.Hide()
    End Sub



    Private Sub Pb4_Click(sender As Object, e As EventArgs) Handles Pb4.Click

        Dim response As Integer

        response = MessageBox.Show("Are you sure want to exit? ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If response = vbYes Then
            Application.ExitThread()

        End If


    End Sub

    Private Sub Pb3_Click(sender As Object, e As EventArgs) Handles Pb3.Click

        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Pb2_Click(sender As Object, e As EventArgs) Handles Pb2.Click
        Me.WindowState = FormWindowState.Normal

    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        panelStatus.Height = Btn_logout.Height
        panelStatus.Top = Btn_logout.Top

        Dim log_in As New Form1()
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Btngeneratecertificate_Click(sender As Object, e As EventArgs) Handles Btngeneratecertificate.Click
        panelStatus.Height = Btngeneratecertificate.Height
        panelStatus.Top = Btngeneratecertificate.Top

        With choosecertificate
            Panel3.Controls.Clear()
            .TopLevel = False
            Panel3.Controls.Add(choosecertificate)
            .BringToFront()
            .Show()
        End With
    End Sub
End Class