﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class charactor_certificate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(charactor_certificate))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Txtdate1 = New System.Windows.Forms.TextBox()
        Me.cb3 = New System.Windows.Forms.ComboBox()
        Me.Txtdn = New System.Windows.Forms.TextBox()
        Me.Txtdsd = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cbcivil = New System.Windows.Forms.ComboBox()
        Me.txt18 = New System.Windows.Forms.TextBox()
        Me.cb15 = New System.Windows.Forms.ComboBox()
        Me.cb10 = New System.Windows.Forms.ComboBox()
        Me.cb9 = New System.Windows.Forms.ComboBox()
        Me.Txt17 = New System.Windows.Forms.TextBox()
        Me.Txt16 = New System.Windows.Forms.TextBox()
        Me.Txt13 = New System.Windows.Forms.TextBox()
        Me.Txt12 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt11 = New System.Windows.Forms.TextBox()
        Me.Txt8 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.cb5 = New System.Windows.Forms.ComboBox()
        Me.Txt6 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.txtcertify2 = New System.Windows.Forms.TextBox()
        Me.txtcertify1 = New System.Windows.Forms.TextBox()
        Me.Txt7 = New System.Windows.Forms.TextBox()
        Me.Txtindex = New System.Windows.Forms.TextBox()
        Me.Pdoc = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(358, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(766, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Certificate On Residence And Character Issued By The Grama Niladhari"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Txtdate1)
        Me.Panel1.Controls.Add(Me.cb3)
        Me.Panel1.Controls.Add(Me.Txtdn)
        Me.Panel1.Controls.Add(Me.Txtdsd)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(12, 99)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(696, 167)
        Me.Panel1.TabIndex = 1
        '
        'Txtdate1
        '
        Me.Txtdate1.Location = New System.Drawing.Point(207, 125)
        Me.Txtdate1.Name = "Txtdate1"
        Me.Txtdate1.Size = New System.Drawing.Size(482, 27)
        Me.Txtdate1.TabIndex = 9
        '
        'cb3
        '
        Me.cb3.FormattingEnabled = True
        Me.cb3.Items.AddRange(New Object() {"Yes", "No"})
        Me.cb3.Location = New System.Drawing.Point(574, 83)
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(115, 28)
        Me.cb3.TabIndex = 8
        '
        'Txtdn
        '
        Me.Txtdn.Location = New System.Drawing.Point(368, 49)
        Me.Txtdn.Name = "Txtdn"
        Me.Txtdn.Size = New System.Drawing.Size(321, 27)
        Me.Txtdn.TabIndex = 5
        '
        'Txtdsd
        '
        Me.Txtdsd.Location = New System.Drawing.Point(414, 13)
        Me.Txtdsd.Name = "Txtdsd"
        Me.Txtdsd.Size = New System.Drawing.Size(275, 27)
        Me.Txtdsd.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(10, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(193, 23)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "4) If So,Since When?:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(10, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(558, 23)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "3) Whether Applicant Personally  Know To The Grama Niladhari:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(10, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(362, 23)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "2) Grama Niladhari Division And Number:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(14, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(387, 23)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "1) District And Divisional Secretary Division:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cbcivil)
        Me.Panel2.Controls.Add(Me.txt18)
        Me.Panel2.Controls.Add(Me.cb15)
        Me.Panel2.Controls.Add(Me.cb10)
        Me.Panel2.Controls.Add(Me.cb9)
        Me.Panel2.Controls.Add(Me.Txt17)
        Me.Panel2.Controls.Add(Me.Txt16)
        Me.Panel2.Controls.Add(Me.Txt13)
        Me.Panel2.Controls.Add(Me.Txt12)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Txt11)
        Me.Panel2.Controls.Add(Me.Txt8)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Location = New System.Drawing.Point(749, 99)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(755, 449)
        Me.Panel2.TabIndex = 2
        '
        'cbcivil
        '
        Me.cbcivil.FormattingEnabled = True
        Me.cbcivil.Items.AddRange(New Object() {"Married", "Unmarried"})
        Me.cbcivil.Location = New System.Drawing.Point(189, 251)
        Me.cbcivil.Name = "cbcivil"
        Me.cbcivil.Size = New System.Drawing.Size(230, 28)
        Me.cbcivil.TabIndex = 27
        '
        'txt18
        '
        Me.txt18.Location = New System.Drawing.Point(296, 388)
        Me.txt18.Name = "txt18"
        Me.txt18.Size = New System.Drawing.Size(322, 27)
        Me.txt18.TabIndex = 26
        '
        'cb15
        '
        Me.cb15.FormattingEnabled = True
        Me.cb15.Items.AddRange(New Object() {"Yes", "No"})
        Me.cb15.Location = New System.Drawing.Point(190, 286)
        Me.cb15.Name = "cb15"
        Me.cb15.Size = New System.Drawing.Size(229, 28)
        Me.cb15.TabIndex = 25
        '
        'cb10
        '
        Me.cb10.FormattingEnabled = True
        Me.cb10.Items.AddRange(New Object() {"Buddhist", "Muslim", "Tamil", "Christian", "Malle"})
        Me.cb10.Location = New System.Drawing.Point(174, 110)
        Me.cb10.Name = "cb10"
        Me.cb10.Size = New System.Drawing.Size(304, 28)
        Me.cb10.TabIndex = 24
        '
        'cb9
        '
        Me.cb9.FormattingEnabled = True
        Me.cb9.Items.AddRange(New Object() {"Male", "Female"})
        Me.cb9.Location = New System.Drawing.Point(174, 68)
        Me.cb9.Name = "cb9"
        Me.cb9.Size = New System.Drawing.Size(304, 28)
        Me.cb9.TabIndex = 23
        '
        'Txt17
        '
        Me.Txt17.Location = New System.Drawing.Point(190, 355)
        Me.Txt17.Name = "Txt17"
        Me.Txt17.Size = New System.Drawing.Size(229, 27)
        Me.Txt17.TabIndex = 22
        '
        'Txt16
        '
        Me.Txt16.Location = New System.Drawing.Point(190, 320)
        Me.Txt16.Name = "Txt16"
        Me.Txt16.Size = New System.Drawing.Size(229, 27)
        Me.Txt16.TabIndex = 21
        '
        'Txt13
        '
        Me.Txt13.Location = New System.Drawing.Point(392, 219)
        Me.Txt13.Name = "Txt13"
        Me.Txt13.Size = New System.Drawing.Size(354, 27)
        Me.Txt13.TabIndex = 18
        '
        'Txt12
        '
        Me.Txt12.Location = New System.Drawing.Point(290, 183)
        Me.Txt12.Name = "Txt12"
        Me.Txt12.Size = New System.Drawing.Size(462, 27)
        Me.Txt12.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(43, -9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(308, 28)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "5) Information about Applicant"
        '
        'Txt11
        '
        Me.Txt11.Location = New System.Drawing.Point(230, 143)
        Me.Txt11.Name = "Txt11"
        Me.Txt11.Size = New System.Drawing.Size(370, 27)
        Me.Txt11.TabIndex = 16
        '
        'Txt8
        '
        Me.Txt8.Location = New System.Drawing.Point(185, 29)
        Me.Txt8.Name = "Txt8"
        Me.Txt8.Size = New System.Drawing.Size(567, 27)
        Me.Txt8.TabIndex = 13
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(622, 415)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(126, 20)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "Usual Signature:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(19, 222)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(369, 20)
        Me.Label17.TabIndex = 11
        Me.Label17.Text = "* Purpose For Which The Certificate Is Required:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label16.Location = New System.Drawing.Point(19, 186)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(271, 20)
        Me.Label16.TabIndex = 10
        Me.Label16.Text = "* Name And Address of The Father:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label15.Location = New System.Drawing.Point(19, 150)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(205, 20)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "* National Identy Card No:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(19, 395)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(271, 20)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "* Period Of Resident In The Village:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(19, 356)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(168, 20)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "* Present Occupation:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(19, 113)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 20)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "* Religion:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(19, 287)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(173, 20)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "* Whether Sri Lankan:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(19, 257)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 20)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "* Civil Status:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(19, 323)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 20)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "* Age:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(19, 74)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 20)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "* Sex:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(19, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(163, 20)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "* Name and Address:"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.cb5)
        Me.Panel3.Controls.Add(Me.Txt6)
        Me.Panel3.Controls.Add(Me.Label28)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Location = New System.Drawing.Point(12, 302)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(696, 125)
        Me.Panel3.TabIndex = 3
        '
        'cb5
        '
        Me.cb5.FormattingEnabled = True
        Me.cb5.Items.AddRange(New Object() {"Yes", "No"})
        Me.cb5.Location = New System.Drawing.Point(534, 39)
        Me.cb5.Name = "cb5"
        Me.cb5.Size = New System.Drawing.Size(159, 28)
        Me.cb5.TabIndex = 5
        '
        'Txt6
        '
        Me.Txt6.Location = New System.Drawing.Point(178, 89)
        Me.Txt6.Name = "Txt6"
        Me.Txt6.Size = New System.Drawing.Size(475, 27)
        Me.Txt6.TabIndex = 4
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label28.Location = New System.Drawing.Point(10, -8)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(210, 28)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = "6) Other Information"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(14, 93)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(159, 20)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "* His/ Her character:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(14, 42)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(502, 20)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "*  Whether The Applicant Has Been Convicted By A Court Of Low:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(638, 314)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(0, 20)
        Me.Label21.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label23)
        Me.Panel4.Location = New System.Drawing.Point(12, 609)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(686, 108)
        Me.Panel4.TabIndex = 5
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label23.Location = New System.Drawing.Point(220, 44)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(224, 40)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Signature Of Grama Niladhari" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "     And Official Stamp"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label27)
        Me.Panel5.Controls.Add(Me.Label26)
        Me.Panel5.Controls.Add(Me.Label25)
        Me.Panel5.Controls.Add(Me.Label24)
        Me.Panel5.Location = New System.Drawing.Point(749, 580)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(755, 134)
        Me.Panel5.TabIndex = 6
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label27.Location = New System.Drawing.Point(598, 79)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(153, 20)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "Divisional Secretary"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label26.Location = New System.Drawing.Point(56, 101)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(47, 20)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Date:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label25.Location = New System.Drawing.Point(392, 45)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(143, 20)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Counter Signature:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label24.Location = New System.Drawing.Point(56, 45)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(47, 20)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Date:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Sienna
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(26, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(257, 43)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Generate Certificate"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.txtcertify2)
        Me.Panel6.Controls.Add(Me.txtcertify1)
        Me.Panel6.Controls.Add(Me.Txt7)
        Me.Panel6.Location = New System.Drawing.Point(12, 443)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(653, 160)
        Me.Panel6.TabIndex = 8
        '
        'txtcertify2
        '
        Me.txtcertify2.Location = New System.Drawing.Point(232, 83)
        Me.txtcertify2.Name = "txtcertify2"
        Me.txtcertify2.Size = New System.Drawing.Size(242, 27)
        Me.txtcertify2.TabIndex = 2
        '
        'txtcertify1
        '
        Me.txtcertify1.Location = New System.Drawing.Point(318, 51)
        Me.txtcertify1.Multiline = True
        Me.txtcertify1.Name = "txtcertify1"
        Me.txtcertify1.Size = New System.Drawing.Size(332, 26)
        Me.txtcertify1.TabIndex = 1
        '
        'Txt7
        '
        Me.Txt7.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Txt7.Location = New System.Drawing.Point(3, 3)
        Me.Txt7.Multiline = True
        Me.Txt7.Name = "Txt7"
        Me.Txt7.Size = New System.Drawing.Size(650, 154)
        Me.Txt7.TabIndex = 0
        Me.Txt7.Text = resources.GetString("Txt7.Text")
        '
        'Txtindex
        '
        Me.Txtindex.Location = New System.Drawing.Point(1248, 7)
        Me.Txtindex.Multiline = True
        Me.Txtindex.Name = "Txtindex"
        Me.Txtindex.Size = New System.Drawing.Size(265, 40)
        Me.Txtindex.TabIndex = 9
        '
        'Pdoc
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(394, 43)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(668, 40)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = resources.GetString("Label22.Text")
        '
        'charactor_certificate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1516, 874)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Txtindex)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "charactor_certificate"
        Me.Text = "charactor_certificate"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label23 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Txtdsd As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Txtdn As TextBox
    Friend WithEvents Txt6 As TextBox
    Friend WithEvents Txt8 As TextBox
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Txt7 As TextBox
    Friend WithEvents cb15 As ComboBox
    Friend WithEvents cb10 As ComboBox
    Friend WithEvents cb9 As ComboBox
    Friend WithEvents Txt17 As TextBox
    Friend WithEvents Txt16 As TextBox
    Friend WithEvents Txt13 As TextBox
    Friend WithEvents Txt12 As TextBox
    Friend WithEvents Txt11 As TextBox
    Friend WithEvents Txtindex As TextBox
    Friend WithEvents txt18 As TextBox
    Friend WithEvents cb5 As ComboBox
    Friend WithEvents cb3 As ComboBox
    Friend WithEvents Pdoc As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents Txtdate1 As TextBox
    Friend WithEvents cbcivil As ComboBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txtcertify2 As TextBox
    Friend WithEvents txtcertify1 As TextBox
End Class
