﻿Imports MySql.Data.MySqlClient
Imports System.Data.Common

Public Class Form2
    Private Sub Btn_submit_Click(sender As Object, e As EventArgs) Handles Btn_submit.Click

        Dim st_name As String
        Dim st_id, age As Integer

        st_id = Txt_ID.Text
        st_name = Txt_Name.Text
        age = Txt_Age.Text

        Try
            If dbconnection() Then

                'add student to database table

                Dim addstudent As String
                Dim result As Boolean

                addstudent = "INSERT INTO 'st_details'('st_id','st_name','age')VALUES(@STID, @STNAME,@AGE)LIMIT 1"

                Dim command As New MySqlCommand(addstudent, dbconnection)

                command.Parameters.AddWithValue("@STID", st_id)
                command.Parameters.AddWithValue("@STNAME", st_name)
                command.Parameters.AddWithValue("@AGE", age)

                'confirmation for adding the student yes or no

                Dim response, msg, style, title As String

                msg = "you're going to adding," & ControlChars.NewLine & ControlChars.NewLine & ControlChars.NewLine & "student ID:" & st_id & ControlChars.NewLine & ControlChars.NewLine & "student name:" & st_name & ControlChars.NewLine & ControlChars.NewLine & "age:" & age & "" & "do you confirm this?"

                style = vbYesNo Or vbInformation Or vbDefaultButton2

                title = "confirmation"

                response = MsgBox(msg, style, title)

                If response = vbYes Then
                    result = command.ExecuteNonQuery()

                    If result = True Then

                        MsgBox("adding the student is successful" & "_" & st_id, vbOKOnly + vbInformation, "sucessful")

                        Txt_ID.Text = ""
                        Txt_Name.Text = ""
                        Txt_Age.Text = ""

                    Else
                        MsgBox("an unknown error occured", vbOKOnly + vbExclamation, "unkonown error")

                    End If
                    command.Parameters.Clear()
                Else
                    MsgBox("the student adding was canceled", vbOKOnly + vbInformation, "cancelling")

                End If

            Else
                MsgBox("datavase not connectd", vbOKOnly + vbCritical, "connection error")


            End If

        Catch ex As Exception
            MsgBox(ex.Message, vbExclamation, "execute error")

        End Try




    End Sub
End Class