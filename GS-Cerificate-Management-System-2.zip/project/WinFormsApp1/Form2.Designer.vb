﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txt_ID = New System.Windows.Forms.TextBox()
        Me.Txt_Name = New System.Windows.Forms.TextBox()
        Me.Btn_submit = New System.Windows.Forms.Button()
        Me.Lblst_ID = New System.Windows.Forms.Label()
        Me.Lblst_Name = New System.Windows.Forms.Label()
        Me.Lbl_Age = New System.Windows.Forms.Label()
        Me.Txt_Age = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Txt_ID
        '
        Me.Txt_ID.BackColor = System.Drawing.SystemColors.Info
        Me.Txt_ID.Location = New System.Drawing.Point(289, 88)
        Me.Txt_ID.Name = "Txt_ID"
        Me.Txt_ID.Size = New System.Drawing.Size(202, 27)
        Me.Txt_ID.TabIndex = 0
        '
        'Txt_Name
        '
        Me.Txt_Name.BackColor = System.Drawing.SystemColors.Info
        Me.Txt_Name.Location = New System.Drawing.Point(289, 185)
        Me.Txt_Name.Name = "Txt_Name"
        Me.Txt_Name.Size = New System.Drawing.Size(202, 27)
        Me.Txt_Name.TabIndex = 1
        '
        'Btn_submit
        '
        Me.Btn_submit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Btn_submit.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_submit.ForeColor = System.Drawing.Color.Red
        Me.Btn_submit.Location = New System.Drawing.Point(236, 347)
        Me.Btn_submit.Name = "Btn_submit"
        Me.Btn_submit.Size = New System.Drawing.Size(283, 69)
        Me.Btn_submit.TabIndex = 2
        Me.Btn_submit.Text = "Submit"
        Me.Btn_submit.UseVisualStyleBackColor = False
        '
        'Lblst_ID
        '
        Me.Lblst_ID.AutoSize = True
        Me.Lblst_ID.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblst_ID.Location = New System.Drawing.Point(282, 48)
        Me.Lblst_ID.Name = "Lblst_ID"
        Me.Lblst_ID.Size = New System.Drawing.Size(97, 23)
        Me.Lblst_ID.TabIndex = 3
        Me.Lblst_ID.Text = "Student ID"
        '
        'Lblst_Name
        '
        Me.Lblst_Name.AutoSize = True
        Me.Lblst_Name.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lblst_Name.Location = New System.Drawing.Point(282, 136)
        Me.Lblst_Name.Name = "Lblst_Name"
        Me.Lblst_Name.Size = New System.Drawing.Size(126, 23)
        Me.Lblst_Name.TabIndex = 4
        Me.Lblst_Name.Text = "Student Name"
        '
        'Lbl_Age
        '
        Me.Lbl_Age.AutoSize = True
        Me.Lbl_Age.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_Age.Location = New System.Drawing.Point(282, 244)
        Me.Lbl_Age.Name = "Lbl_Age"
        Me.Lbl_Age.Size = New System.Drawing.Size(111, 23)
        Me.Lbl_Age.TabIndex = 5
        Me.Lbl_Age.Text = "Student Age"
        '
        'Txt_Age
        '
        Me.Txt_Age.BackColor = System.Drawing.SystemColors.Info
        Me.Txt_Age.Location = New System.Drawing.Point(289, 283)
        Me.Txt_Age.Name = "Txt_Age"
        Me.Txt_Age.Size = New System.Drawing.Size(202, 27)
        Me.Txt_Age.TabIndex = 6
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Txt_Age)
        Me.Controls.Add(Me.Lbl_Age)
        Me.Controls.Add(Me.Lblst_Name)
        Me.Controls.Add(Me.Lblst_ID)
        Me.Controls.Add(Me.Btn_submit)
        Me.Controls.Add(Me.Txt_Name)
        Me.Controls.Add(Me.Txt_ID)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txt_ID As TextBox
    Friend WithEvents Txt_Name As TextBox
    Friend WithEvents Btn_submit As Button
    Friend WithEvents Lblst_ID As Label
    Friend WithEvents Lblst_Name As Label
    Friend WithEvents Lbl_Age As Label
    Friend WithEvents Txt_Age As TextBox
End Class
