﻿Imports System.Data.Common
Imports System.Reflection
Imports MySql.Data.MySqlClient
Imports Mysqlx.XDevAPI.Common
Imports Org.BouncyCastle.Asn1.Ocsp

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Btn_register.Click

        Dim username, userpass, msg1, msg2, style1, style2, response As String
        Dim title As String
        title = dbconnection()

        username = Txt_username.Text
        userpass = Txt_password.Text

        msg1 = "db connect"
        msg2 = "db error"
        style1 = vbOKOnly Or vbInformation
        style2 = vbOKOnly Or vbCritical


        Try
            If dbconnection() = True Then
                response = MsgBox(msg1, style1, title)
            Else
                response = MsgBox(msg2, style2, title)


            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
