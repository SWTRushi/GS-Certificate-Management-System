﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Txt_username = New System.Windows.Forms.TextBox()
        Me.Txt_password = New System.Windows.Forms.TextBox()
        Me.Btn_register = New System.Windows.Forms.Button()
        Me.Lbl_username = New System.Windows.Forms.Label()
        Me.Lbl_userpass = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Txt_username
        '
        Me.Txt_username.Location = New System.Drawing.Point(238, 97)
        Me.Txt_username.Multiline = True
        Me.Txt_username.Name = "Txt_username"
        Me.Txt_username.Size = New System.Drawing.Size(281, 38)
        Me.Txt_username.TabIndex = 0
        '
        'Txt_password
        '
        Me.Txt_password.Location = New System.Drawing.Point(238, 200)
        Me.Txt_password.Multiline = True
        Me.Txt_password.Name = "Txt_password"
        Me.Txt_password.Size = New System.Drawing.Size(281, 35)
        Me.Txt_password.TabIndex = 1
        '
        'Btn_register
        '
        Me.Btn_register.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Btn_register.Font = New System.Drawing.Font("Segoe UI", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Btn_register.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Btn_register.Location = New System.Drawing.Point(296, 281)
        Me.Btn_register.Name = "Btn_register"
        Me.Btn_register.Size = New System.Drawing.Size(153, 62)
        Me.Btn_register.TabIndex = 3
        Me.Btn_register.Text = "Register"
        Me.Btn_register.UseVisualStyleBackColor = False
        '
        'Lbl_username
        '
        Me.Lbl_username.AutoSize = True
        Me.Lbl_username.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_username.Location = New System.Drawing.Point(323, 45)
        Me.Lbl_username.Name = "Lbl_username"
        Me.Lbl_username.Size = New System.Drawing.Size(105, 25)
        Me.Lbl_username.TabIndex = 4
        Me.Lbl_username.Text = "User Name"
        '
        'Lbl_userpass
        '
        Me.Lbl_userpass.AutoSize = True
        Me.Lbl_userpass.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_userpass.Location = New System.Drawing.Point(323, 158)
        Me.Lbl_userpass.Name = "Lbl_userpass"
        Me.Lbl_userpass.Size = New System.Drawing.Size(92, 25)
        Me.Lbl_userpass.TabIndex = 5
        Me.Lbl_userpass.Text = "Password"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Lbl_userpass)
        Me.Controls.Add(Me.Lbl_username)
        Me.Controls.Add(Me.Btn_register)
        Me.Controls.Add(Me.Txt_password)
        Me.Controls.Add(Me.Txt_username)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txt_username As TextBox
    Friend WithEvents Txt_password As TextBox
    Friend WithEvents Btn_register As Button
    Friend WithEvents Lbl_username As Label
    Friend WithEvents Lbl_userpass As Label
End Class
