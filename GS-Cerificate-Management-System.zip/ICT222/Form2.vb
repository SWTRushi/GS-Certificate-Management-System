﻿Public Class Form2
    Private Sub Btn_register_Click(sender As Object, e As EventArgs) Handles Btn_register.Click
        Dim FN, LN, UN As String
        Dim Password As Integer
        FN = Txt_FN.Text
        LN = Txt_LN.Text
        UN = Txt_Username.Text
        Password = Txt_Password.Text





    End Sub
End Class

