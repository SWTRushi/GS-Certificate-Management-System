﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Txt_FN = New System.Windows.Forms.TextBox()
        Me.Txt_LN = New System.Windows.Forms.TextBox()
        Me.Btn_register = New System.Windows.Forms.Button()
        Me.Lbl_Uregistration = New System.Windows.Forms.Label()
        Me.Lbl_FN = New System.Windows.Forms.Label()
        Me.Lbl_LN = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_Username = New System.Windows.Forms.TextBox()
        Me.Txt_Password = New System.Windows.Forms.TextBox()
        Me.Lbl_User = New System.Windows.Forms.Label()
        Me.Lbl_Password = New System.Windows.Forms.Label()
        Me.Cb_Showpass = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Txt_FN
        '
        Me.Txt_FN.Location = New System.Drawing.Point(244, 92)
        Me.Txt_FN.Name = "Txt_FN"
        Me.Txt_FN.Size = New System.Drawing.Size(258, 27)
        Me.Txt_FN.TabIndex = 0
        '
        'Txt_LN
        '
        Me.Txt_LN.Location = New System.Drawing.Point(244, 160)
        Me.Txt_LN.Name = "Txt_LN"
        Me.Txt_LN.Size = New System.Drawing.Size(258, 27)
        Me.Txt_LN.TabIndex = 1
        '
        'Btn_register
        '
        Me.Btn_register.BackColor = System.Drawing.Color.SteelBlue
        Me.Btn_register.Font = New System.Drawing.Font("Arial Rounded MT Bold", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Btn_register.Location = New System.Drawing.Point(244, 377)
        Me.Btn_register.Name = "Btn_register"
        Me.Btn_register.Size = New System.Drawing.Size(258, 58)
        Me.Btn_register.TabIndex = 2
        Me.Btn_register.Text = "Registration User"
        Me.Btn_register.UseVisualStyleBackColor = False
        '
        'Lbl_Uregistration
        '
        Me.Lbl_Uregistration.AutoSize = True
        Me.Lbl_Uregistration.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_Uregistration.Location = New System.Drawing.Point(286, 19)
        Me.Lbl_Uregistration.Name = "Lbl_Uregistration"
        Me.Lbl_Uregistration.Size = New System.Drawing.Size(223, 23)
        Me.Lbl_Uregistration.TabIndex = 3
        Me.Lbl_Uregistration.Text = "USER REGISTRATION"
        '
        'Lbl_FN
        '
        Me.Lbl_FN.AutoSize = True
        Me.Lbl_FN.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_FN.Location = New System.Drawing.Point(244, 69)
        Me.Lbl_FN.Name = "Lbl_FN"
        Me.Lbl_FN.Size = New System.Drawing.Size(86, 20)
        Me.Lbl_FN.TabIndex = 4
        Me.Lbl_FN.Text = "First Name"
        '
        'Lbl_LN
        '
        Me.Lbl_LN.AutoSize = True
        Me.Lbl_LN.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_LN.Location = New System.Drawing.Point(244, 137)
        Me.Lbl_LN.Name = "Lbl_LN"
        Me.Lbl_LN.Size = New System.Drawing.Size(84, 20)
        Me.Lbl_LN.TabIndex = 5
        Me.Lbl_LN.Text = "Last Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(90, 137)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 20)
        Me.Label2.TabIndex = 6
        '
        'Txt_Username
        '
        Me.Txt_Username.Location = New System.Drawing.Point(244, 241)
        Me.Txt_Username.Name = "Txt_Username"
        Me.Txt_Username.Size = New System.Drawing.Size(258, 27)
        Me.Txt_Username.TabIndex = 7
        '
        'Txt_Password
        '
        Me.Txt_Password.Location = New System.Drawing.Point(244, 318)
        Me.Txt_Password.Name = "Txt_Password"
        Me.Txt_Password.Size = New System.Drawing.Size(258, 27)
        Me.Txt_Password.TabIndex = 8
        '
        'Lbl_User
        '
        Me.Lbl_User.AutoSize = True
        Me.Lbl_User.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_User.Location = New System.Drawing.Point(244, 207)
        Me.Lbl_User.Name = "Lbl_User"
        Me.Lbl_User.Size = New System.Drawing.Size(87, 20)
        Me.Lbl_User.TabIndex = 9
        Me.Lbl_User.Text = "User Name"
        '
        'Lbl_Password
        '
        Me.Lbl_Password.AutoSize = True
        Me.Lbl_Password.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Lbl_Password.Location = New System.Drawing.Point(244, 284)
        Me.Lbl_Password.Name = "Lbl_Password"
        Me.Lbl_Password.Size = New System.Drawing.Size(76, 20)
        Me.Lbl_Password.TabIndex = 10
        Me.Lbl_Password.Text = "Password"
        '
        'Cb_Showpass
        '
        Me.Cb_Showpass.AutoSize = True
        Me.Cb_Showpass.Font = New System.Drawing.Font("Segoe UI", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Cb_Showpass.Location = New System.Drawing.Point(392, 280)
        Me.Cb_Showpass.Name = "Cb_Showpass"
        Me.Cb_Showpass.Size = New System.Drawing.Size(121, 21)
        Me.Cb_Showpass.TabIndex = 11
        Me.Cb_Showpass.Text = "Show Password"
        Me.Cb_Showpass.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 482)
        Me.Controls.Add(Me.Cb_Showpass)
        Me.Controls.Add(Me.Lbl_Password)
        Me.Controls.Add(Me.Lbl_User)
        Me.Controls.Add(Me.Txt_Password)
        Me.Controls.Add(Me.Txt_Username)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Lbl_LN)
        Me.Controls.Add(Me.Lbl_FN)
        Me.Controls.Add(Me.Lbl_Uregistration)
        Me.Controls.Add(Me.Btn_register)
        Me.Controls.Add(Me.Txt_LN)
        Me.Controls.Add(Me.Txt_FN)
        Me.Name = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txt_FN As TextBox
    Friend WithEvents Txt_LN As TextBox
    Friend WithEvents Btn_register As Button
    Friend WithEvents Lbl_Uregistration As Label
    Friend WithEvents Lbl_FN As Label
    Friend WithEvents Lbl_LN As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Txt_Username As TextBox
    Friend WithEvents Txt_Password As TextBox
    Friend WithEvents Lbl_User As Label
    Friend WithEvents Lbl_Password As Label
    Friend WithEvents Cb_Showpass As CheckBox
End Class
