﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Txt_name = New System.Windows.Forms.TextBox()
        Me.Txt_pass = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Lbl_pass = New System.Windows.Forms.Label()
        Me.Lbl_name = New System.Windows.Forms.Label()
        Me.Btn_Register = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Txt_name
        '
        Me.Txt_name.Location = New System.Drawing.Point(140, 118)
        Me.Txt_name.Name = "Txt_name"
        Me.Txt_name.Size = New System.Drawing.Size(269, 27)
        Me.Txt_name.TabIndex = 0
        '
        'Txt_pass
        '
        Me.Txt_pass.Location = New System.Drawing.Point(140, 221)
        Me.Txt_pass.Name = "Txt_pass"
        Me.Txt_pass.Size = New System.Drawing.Size(269, 27)
        Me.Txt_pass.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(140, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 20)
        Me.Label1.TabIndex = 1
        '
        'Lbl_pass
        '
        Me.Lbl_pass.AutoSize = True
        Me.Lbl_pass.Location = New System.Drawing.Point(140, 174)
        Me.Lbl_pass.Name = "Lbl_pass"
        Me.Lbl_pass.Size = New System.Drawing.Size(70, 20)
        Me.Lbl_pass.TabIndex = 1
        Me.Lbl_pass.Text = "Password"
        '
        'Lbl_name
        '
        Me.Lbl_name.AutoSize = True
        Me.Lbl_name.Location = New System.Drawing.Point(140, 86)
        Me.Lbl_name.Name = "Lbl_name"
        Me.Lbl_name.Size = New System.Drawing.Size(82, 20)
        Me.Lbl_name.TabIndex = 1
        Me.Lbl_name.Text = "User Name"
        '
        'Btn_Register
        '
        Me.Btn_Register.Location = New System.Drawing.Point(179, 281)
        Me.Btn_Register.Name = "Btn_Register"
        Me.Btn_Register.Size = New System.Drawing.Size(183, 74)
        Me.Btn_Register.TabIndex = 2
        Me.Btn_Register.Text = "Register"
        Me.Btn_Register.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 450)
        Me.Controls.Add(Me.Btn_Register)
        Me.Controls.Add(Me.Lbl_pass)
        Me.Controls.Add(Me.Lbl_name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_pass)
        Me.Controls.Add(Me.Txt_name)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Txt_name As TextBox
    Friend WithEvents Txt_pass As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Lbl_pass As Label
    Friend WithEvents Lbl_name As Label
    Friend WithEvents Btn_Register As Button
End Class
