﻿Imports MySql.Data.MySqlClient

Public Class userclass
    Public id As Integer
    Public fname As String
    Public lname As String
    Public username As String



End Class
