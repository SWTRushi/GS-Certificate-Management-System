﻿Imports System.Security.Cryptography.X509Certificates
Imports MySql.Data.MySqlClient

Public Class Allusers
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridViewusers.CellContentClick

    End Sub
    Private Sub Allusers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Dim numbers As Integer() = {1, 2, 3, 4, 5, 6}

        'For Each n In numbers

        'MsgBox(n)

        'Next

        Dim dt As New DataTable()

        dt.Columns.Add("id")
        dt.Columns.Add("first name")
        dt.Columns.Add("last name")
        dt.Columns.Add("user name")

        dt.Rows.Add("1", "tharushi", "kaushalya", "root")

        Dim userlist As List(Of userclass) = getusers()

        For Each T As userclass In userlist

            dt.Rows.Add("T.id", "T.fname", "T.lname", "T.username")

        Next

        DataGridViewusers.DataSource = dt
    End Sub
    Public Function getusers() As List(Of userclass)

        Dim user As New List(Of userclass)


        user.Add(New userclass With {.id = 100, .fname = "tharushi", .lname = "kaushalya", .username = "root"})
        user.Add(New userclass With {.id = 101, .fname = "achini", .lname = "perera", .username = "achi123"})
        user.Add(New userclass With {.id = 102, .fname = "sajith", .lname = "weherage", .username = "s123"})
        user.Add(New userclass With {.id = 103, .fname = "tharindu", .lname = "madushan", .username = "t123"})
        user.Add(New userclass With {.id = 104, .fname = "sameera", .lname = "perera", .username = "sa123"})

        'select data from user table 
        connectDB()
        Dim sql = "select id,fname,lname,uname from users"
        Dim Command = New MySqlCommand(sql, conn)
        Dim result = Command.ExecuteReader

        While result.Read
            user.Add(New userclass With {.id = result("id"), .fname = result("fname"), .lname = result("lname"), .username = result("uname")})
        End While

        Return user

    End Function

    ' Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    'Dim row_index = DataGridViewusers.CurrentRow.Index
    'MsgBox(DataGridViewusers.CurrentRow.Index)

    'Dim row As DataGridView
    'row = DataGridViewusers.Rows.(e.row_index)
    'MsgBox(row.Cells(0).value.tostring)


    ' End Sub

End Class