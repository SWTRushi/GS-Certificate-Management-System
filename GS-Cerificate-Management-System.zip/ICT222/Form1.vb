﻿Imports System.ComponentModel.DataAnnotations
Imports System.Security.Cryptography.X509Certificates
Imports MySql.Data.MySqlClient

Public Class Form1
    Public c As New MySqlCommand


    Private Sub Btn_Register_Click(sender As Object, e As EventArgs) Handles Btn_Register.Click

        Dim FN, LN As String
        'Dim min_length1, min_length2 As String
        FN = Txt_name.Text
        LN = Txt_pass.Text
        '= FN
        'min_length2 = LN
        'MsgBox(FN + " " + LN)

        'If FN.Length < 6 Then
        'MsgBox("length is not match")
        ' ElseIf LN.Length < 6 Then
        'MsgBox("length is not match")
        'Else
        'MsgBox(FN + " " + LN)
        'End If

        connectDB()

        If min_length(FN, 3) = False Then
            MsgBox("first name required at least 3 chars")
        ElseIf min_length(LN, 6) = False Then
            MsgBox("last name required at least 6 chars")
        Else
            MsgBox(FN + " " + LN)

            'quary string
            Dim q As String = "insert into users (u_name,u_pass) values(@uname,@upass)"

            c = New MySqlCommand(q, conn)

            c.Parameters.AddWithValue("@uname", FN)

            c.Parameters.AddWithValue("@upass", LN)

            Dim inserted_rows As Integer = Command()

            MsgBox(inserted_rows)

            If inserted_rows = 1 Then
                MsgBox("users registered")
            Else
                MsgBox("registered faild")

            End If

            c.Parameters.Clear()
        End If

    End Sub
End Class
