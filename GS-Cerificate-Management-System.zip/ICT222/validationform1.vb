﻿Module validationform1
    Function min_length(ByVal name As String, ByVal length As Integer) As Boolean
        Dim result As Boolean = True
        If name.Length < length Then
            result = "false"
        End If

        Return result

    End Function
End Module
